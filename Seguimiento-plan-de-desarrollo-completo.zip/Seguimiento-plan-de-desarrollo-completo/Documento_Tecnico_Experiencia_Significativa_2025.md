# Documento Técnico de Experiencia Significativa: Plataforma de Seguimiento del Plan de Desarrollo Municipal de San Jerónimo

## 1. TÍTULO Y RESUMEN EJECUTIVO
**Nombre de la experiencia:** Plataforma de Gestión e Inteligencia Territorial "San Jerónimo Progresa" (2024-2027).

**Resumen Ejecutivo (Elevator Pitch):**
Se trata de una solución integral de Gobierno Digital diseñada para la Alcaldía de San Jerónimo, Antioquia. La plataforma digitaliza y centraliza el seguimiento de los 215 indicadores del Plan de Desarrollo Municipal, integrando visualización de datos en tiempo real, gestión financiera detallada por fuentes de cofinanciación y un asistente de Inteligencia Artificial especializado. A diferencia de los reportes estáticos tradicionales, esta herramienta permite a los tomadores de decisiones y a la ciudadanía monitorear el progreso físico y financiero de manera dinámica, facilitando una gestión pública basada en evidencia y una transparencia total en la rendición de cuentas.

---

## 2. PROBLEMÁTICA Y CONTEXTO
**Problemática:**
Históricamente, el municipio de San Jerónimo enfrentaba deficiencias en el seguimiento de sus metas de gobierno. La información estaba dispersa en múltiples archivos de Excel, los reportes de avance eran tardíos y no existía una vinculación clara entre la ejecución presupuestal y el cumplimiento de metas físicas (BPIM). Esta desconexión limitaba la capacidad de respuesta de la administración ante retrasos en programas críticos y dificultaba el acceso de la ciudadanía a información clara sobre el destino de los recursos públicos.

**Beneficiarios:**
- **Alcaldía de San Jerónimo:** Alcalde, secretarios de despacho y equipos técnicos que ahora cuentan con un tablero de control unificado.
- **Ciudadanía:** Habitantes del municipio que obtienen una ventana de transparencia para auditar el cumplimiento de las promesas de gobierno.
- **Entes de Control:** Facilitación de la generación de informes requeridos por la Gobernación de Antioquia y el Gobierno Nacional.

---

## 3. DESCRIPCIÓN TÉCNICA DE LA SOLUCIÓN
**Arquitectura de la Aplicación:**
La plataforma utiliza un stack tecnológico moderno y escalable que garantiza alta disponibilidad y rendimiento:
- **Frontend:** React 18 con TypeScript y Vite. La interfaz es altamente interactiva gracias a componentes de `shadcn/ui`, `Tailwind CSS` para un diseño responsivo, y `Recharts` para la visualización dinámica de indicadores.
- **Backend:** Node.js con el framework Express.js, proporcionando una API REST robusta para la manipulación de datos.
- **Base de Datos:** PostgreSQL gestionado a través de Drizzle ORM, permitiendo una estructura de datos relacional sólida para el manejo de indicadores, historia de actualizaciones y presupuestos.
- **Inteligencia Artificial:** Integración de un chatbot avanzado mediante OpenRouter (Google Gemini 2.5 Flash Lite), configurado con el contexto específico del Plan de Desarrollo y el contexto socioeconómico del Occidente Antioqueño.

**Funcionalidad Clave:**
1. **Importación y Gestión:** El sistema permite la carga masiva de indicadores mediante archivos CSV, validando automáticamente campos críticos como códigos BPIM y sectores ODS.
2. **Dashboard de Seguimiento:** Clasifica los indicadores por líneas estratégicas y estados (A tiempo, Retrasado, Crítico) mediante semaforización visual.
3. **Distribución Presupuestal:** Permite asignar fuentes de financiación específicas a cada indicador, controlando la ejecución financiera anual y por cuatrienio.
4. **Asistente IA:** El chatbot analiza los indicadores en tiempo real, sugiriendo alternativas técnicas y alianzas estratégicas contextualizadas a la realidad territorial de San Jerónimo para desbloquear metas retrasadas.

**Innovación:**
La principal innovación radica en la **fusión de la gestión de indicadores con la Inteligencia Artificial Generativa**. Mientras que otros sistemas son meros repositorios de datos, "San Jerónimo Progresa" actúa como un consultor proactivo que interpreta los datos y ofrece recomendaciones basadas en mejores prácticas de innovación pública y contexto territorial antioqueño.

---

## 4. ALINEACIÓN CON LA CONVOCATORIA 2025
**Éxito de la Experiencia:**
La experiencia se clasifica como exitosa por su capacidad de **interoperabilidad y usabilidad**. Ha logrado reducir el tiempo de consolidación de informes de gestión en un 70%, permitiendo que el equipo de planeación se enfoque en el análisis y no en la recolección manual de datos.

**Mayor Logro:**
La democratización de la información técnica. Lograr que un indicador complejo (ej. BPIM de infraestructura rural) sea comprensible para cualquier ciudadano mediante visualizaciones intuitivas y explicaciones generadas por IA, fortaleciendo la confianza en las instituciones.

**Sostenibilidad:**
La estructura modular del código (Frontend/Backend separados) y el uso de un ORM (Drizzle) garantizan que la aplicación pueda evolucionar sin quedar obsoleta. La base de datos está diseñada para escalar año tras año, manteniendo el histórico de cumplimiento para futuros periodos de gobierno.

---

## 5. BENEFICIOS PARA EL MUNICIPIO
**Impacto en la Gestión:**
- **Eficiencia Operativa:** Eliminación de errores humanos en la transcripción de datos financieros y de avance.
- **Toma de Decisiones Proactiva:** Identificación temprana de retrasos mediante el sistema de alertas tempranas (Dashboard).
- **Transparencia Activa:** Cumplimiento con los estándares nacionales de Gobierno Abierto.

**Potencial de Replicabilidad:**
El diseño de la aplicación es **"Municipio-Agnóstico"** en su núcleo. La lógica de gestión de indicadores, líneas estratégicas y distribución presupuestal puede ser replicada en cualquier otro municipio de Colombia simplemente cargando un nuevo archivo de configuración CSV con las metas de su respectivo Plan de Desarrollo. Es una solución de bajo costo y alto impacto lista para ser escalada a nivel regional o nacional.

---
**Generado por el Asistente Técnico de Innovación Pública - San Jerónimo, 2024.**
