
# Guía Completa de Migración: Replit → GitHub → Oracle Cloud / Hostinger

## Tabla de Contenidos
1. [Preparación de la Aplicación](#preparación-de-la-aplicación)
2. [Migración a GitHub](#migración-a-github)
3. [Despliegue en Oracle Cloud](#despliegue-en-oracle-cloud)
4. [Despliegue en Hostinger](#despliegue-en-hostinger)
5. [Configuración de Base de Datos](#configuración-de-base-de-datos)
6. [Variables de Entorno](#variables-de-entorno)
7. [Solución de Problemas](#solución-de-problemas)

---

## 1. Preparación de la Aplicación

### 1.1 Revisar Dependencias y Configuración

Antes de migrar, asegúrate de que tu aplicación esté lista para producción:

1. **Verificar package.json**: Tu aplicación ya tiene los scripts necesarios:
   ```json
   {
     "scripts": {
       "dev": "NODE_ENV=development tsx server/index.ts",
       "build": "vite build && esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist",
       "start": "NODE_ENV=production node dist/index.js"
     }
   }
   ```

2. **Crear archivo .env.example**:
   ```bash
   DATABASE_URL=postgresql://usuario:contraseña@localhost:5432/nombre_db
   SESSION_SECRET=tu_session_secret_aqui
   NODE_ENV=production
   PORT=5000
   ```

3. **Actualizar .gitignore** (ya está configurado correctamente):
   ```
   node_modules
   dist
   .DS_Store
   server/public
   .env
   *.tar.gz
   ```

### 1.2 Preparar Base de Datos para Migración

1. **Exportar datos actuales** (desde Replit):
   ```sql
   -- Conectar a tu base de datos PostgreSQL en Replit
   pg_dump $DATABASE_URL > backup_database.sql
   ```

2. **Exportar solo estructura** (opcional):
   ```sql
   pg_dump --schema-only $DATABASE_URL > schema_only.sql
   ```

---

## 2. Migración a GitHub

### 2.1 Inicializar Repositorio Git

1. **En Replit Shell**, ejecuta:
   ```bash
   git init
   git add .
   git commit -m "Initial commit - Dashboard San Jerónimo"
   ```

### 2.2 Crear Repositorio en GitHub

1. Ve a [GitHub.com](https://github.com)
2. Click en "New repository"
3. Nombre: `dashboard-san-jeronimo`
4. Descripción: `Dashboard Plan de Desarrollo San Jerónimo`
5. Selecciona "Private" o "Public" según prefieras
6. NO inicialices con README, .gitignore o license (ya los tienes)
7. Click "Create repository"

### 2.3 Conectar Replit con GitHub

1. **Obtener URL del repositorio** (ejemplo):
   ```
   https://github.com/tu-usuario/dashboard-san-jeronimo.git
   ```

2. **En Replit Shell**:
   ```bash
   git remote add origin https://github.com/tu-usuario/dashboard-san-jeronimo.git
   git branch -M main
   git push -u origin main
   ```

3. **Si solicita autenticación**, usa un Personal Access Token:
   - Ve a GitHub Settings → Developer settings → Personal access tokens
   - Genera un nuevo token con permisos de "repo"
   - Usa tu username y el token como contraseña

---

## 3. Despliegue en Oracle Cloud

### 3.1 Configurar Oracle Cloud Compute Instance

1. **Crear Compute Instance**:
   - Log in a Oracle Cloud Console
   - Compute → Instances → Create Instance
   - Nombre: `dashboard-san-jeronimo`
   - Image: Ubuntu 20.04 o superior
   - Shape: VM.Standard.E2.1.Micro (Always Free tier)
   - Configure networking (permite HTTP/HTTPS traffic)
   - Añade tu SSH key

2. **Configurar Security List**:
   - Ve a Networking → Virtual Cloud Networks
   - Selecciona tu VCN → Security Lists
   - Añade reglas de ingress:
     - Port 80 (HTTP): 0.0.0.0/0
     - Port 443 (HTTPS): 0.0.0.0/0
     - Port 5000 (Node.js): 0.0.0.0/0

### 3.2 Configurar Servidor

1. **Conectar via SSH**:
   ```bash
   ssh -i tu-private-key.pem ubuntu@tu-ip-publica
   ```

2. **Instalar dependencias**:
   ```bash
   # Actualizar sistema
   sudo apt update && sudo apt upgrade -y
   
   # Instalar Node.js 20
   curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
   sudo apt-get install -y nodejs
   
   # Instalar PostgreSQL
   sudo apt install postgresql postgresql-contrib -y
   
   # Instalar PM2 para gestión de procesos
   sudo npm install -g pm2
   
   # Instalar Git
   sudo apt install git -y
   ```

3. **Configurar PostgreSQL**:
   ```bash
   # Cambiar a usuario postgres
   sudo -u postgres psql
   
   # Crear usuario y base de datos
   CREATE USER dashboard_user WITH PASSWORD 'tu_contraseña_segura';
   CREATE DATABASE dashboard_db OWNER dashboard_user;
   GRANT ALL PRIVILEGES ON DATABASE dashboard_db TO dashboard_user;
   \q
   ```

4. **Configurar firewall**:
   ```bash
   sudo ufw allow 22
   sudo ufw allow 80
   sudo ufw allow 443
   sudo ufw allow 5000
   sudo ufw enable
   ```

### 3.3 Desplegar Aplicación

1. **Clonar repositorio**:
   ```bash
   cd /home/ubuntu
   git clone https://github.com/tu-usuario/dashboard-san-jeronimo.git
   cd dashboard-san-jeronimo
   ```

2. **Configurar variables de entorno**:
   ```bash
   cp .env.example .env
   nano .env
   ```
   
   Edita el archivo:
   ```
   DATABASE_URL=postgresql://dashboard_user:tu_contraseña_segura@localhost:5432/dashboard_db
   SESSION_SECRET=genera_un_session_secret_muy_largo_y_aleatorio
   NODE_ENV=production
   PORT=5000
   ```

3. **Instalar dependencias y construir**:
   ```bash
   npm install
   npm run build
   ```

4. **Restaurar base de datos** (si tienes backup):
   ```bash
   # Subir tu backup_database.sql al servidor
   psql postgresql://dashboard_user:tu_contraseña_segura@localhost:5432/dashboard_db < backup_database.sql
   ```

5. **Configurar PM2**:
   ```bash
   # Crear archivo ecosystem
   nano ecosystem.config.js
   ```
   
   Contenido:
   ```javascript
   module.exports = {
     apps: [{
       name: 'dashboard-san-jeronimo',
       script: 'dist/index.js',
       env: {
         NODE_ENV: 'production',
         PORT: 5000
       },
       instances: 1,
       autorestart: true,
       watch: false,
       max_memory_restart: '1G'
     }]
   };
   ```

6. **Iniciar aplicación**:
   ```bash
   pm2 start ecosystem.config.js
   pm2 startup
   pm2 save
   ```

### 3.4 Configurar Nginx (Opcional pero Recomendado)

1. **Instalar Nginx**:
   ```bash
   sudo apt install nginx -y
   ```

2. **Configurar proxy reverso**:
   ```bash
   sudo nano /etc/nginx/sites-available/dashboard
   ```
   
   Contenido:
   ```nginx
   server {
       listen 80;
       server_name tu-dominio.com tu-ip-publica;
   
       location / {
           proxy_pass http://localhost:5000;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
           proxy_set_header X-Forwarded-Proto $scheme;
           proxy_cache_bypass $http_upgrade;
       }
   }
   ```

3. **Activar configuración**:
   ```bash
   sudo ln -s /etc/nginx/sites-available/dashboard /etc/nginx/sites-enabled/
   sudo nginx -t
   sudo systemctl restart nginx
   ```

---

## 4. Despliegue en Hostinger

### 4.1 Requisitos y Limitaciones

Hostinger VPS es similar a Oracle Cloud, pero con panel de control:

1. **Crear VPS en Hostinger**:
   - Panel Hostinger → VPS → Crear nuevo
   - Selecciona plan (mínimo 1GB RAM recomendado)
   - Elige Ubuntu como OS

2. **Acceder via SSH**:
   - Hostinger te proporcionará IP, usuario y contraseña
   - Conéctate: `ssh root@tu-ip-hostinger`

### 4.2 Configuración Automática con Script

Crea un script de instalación:

```bash
# Crear script de instalación
nano install.sh
```

Contenido del script:
```bash
#!/bin/bash

# Actualizar sistema
apt update && apt upgrade -y

# Instalar Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt-get install -y nodejs

# Instalar dependencias
apt install postgresql postgresql-contrib nginx git ufw -y

# Configurar firewall
ufw allow 22
ufw allow 80
ufw allow 443
ufw enable

# Instalar PM2
npm install -g pm2

# Configurar PostgreSQL
sudo -u postgres psql -c "CREATE USER dashboard_user WITH PASSWORD 'contraseña_segura_aqui';"
sudo -u postgres psql -c "CREATE DATABASE dashboard_db OWNER dashboard_user;"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE dashboard_db TO dashboard_user;"

# Clonar repositorio
cd /root
git clone https://github.com/tu-usuario/dashboard-san-jeronimo.git
cd dashboard-san-jeronimo

# Configurar .env
cp .env.example .env
sed -i 's/DATABASE_URL=.*/DATABASE_URL=postgresql:\/\/dashboard_user:contraseña_segura_aqui@localhost:5432\/dashboard_db/' .env
sed -i 's/SESSION_SECRET=.*/SESSION_SECRET=super_secret_session_key_muy_largo/' .env
sed -i 's/NODE_ENV=.*/NODE_ENV=production/' .env

# Instalar y construir
npm install
npm run build

# Configurar PM2
cat > ecosystem.config.js << EOF
module.exports = {
  apps: [{
    name: 'dashboard-san-jeronimo',
    script: 'dist/index.js',
    env: {
      NODE_ENV: 'production',
      PORT: 5000
    },
    instances: 1,
    autorestart: true,
    watch: false,
    max_memory_restart: '1G'
  }]
};
EOF

# Iniciar aplicación
pm2 start ecosystem.config.js
pm2 startup
pm2 save

echo "¡Instalación completa! Tu aplicación está corriendo en el puerto 5000"
```

Ejecutar script:
```bash
chmod +x install.sh
./install.sh
```

### 4.3 Configurar Dominio en Hostinger

1. **En el panel de Hostinger**:
   - Ve a Dominios → Gestionar
   - Añade registro A apuntando a la IP de tu VPS
   - Configura subdominios si necesario

2. **Configurar Nginx** (mismo proceso que Oracle Cloud)

---

## 5. Configuración de Base de Datos

### 5.1 Migrar Datos desde Replit

1. **Desde Replit, exportar datos**:
   ```bash
   # En Replit Shell
   pg_dump $DATABASE_URL > backup.sql
   ```

2. **Subir backup al servidor**:
   ```bash
   # Desde tu computadora local
   scp backup.sql ubuntu@tu-servidor:/tmp/
   ```

3. **Restaurar en servidor**:
   ```bash
   # En el servidor
   psql postgresql://dashboard_user:contraseña@localhost:5432/dashboard_db < /tmp/backup.sql
   ```

### 5.2 Configurar Backups Automáticos

1. **Crear script de backup**:
   ```bash
   nano /home/ubuntu/backup.sh
   ```
   
   Contenido:
   ```bash
   #!/bin/bash
   DATE=$(date +%Y%m%d_%H%M%S)
   pg_dump postgresql://dashboard_user:contraseña@localhost:5432/dashboard_db > /home/ubuntu/backups/backup_$DATE.sql
   # Mantener solo últimos 7 backups
   find /home/ubuntu/backups -name "backup_*.sql" -mtime +7 -delete
   ```

2. **Configurar cron job**:
   ```bash
   crontab -e
   # Añadir línea para backup diario a las 2 AM
   0 2 * * * /home/ubuntu/backup.sh
   ```

---

## 6. Variables de Entorno

### 6.1 Variables Críticas

Asegúrate de configurar estas variables en producción:

```bash
# Base de datos
DATABASE_URL=postgresql://usuario:contraseña@localhost:5432/nombre_db

# Sesiones
SESSION_SECRET=clave_super_secreta_y_larga_de_al_menos_64_caracteres

# Entorno
NODE_ENV=production
PORT=5000

# Opcional: Para logging
LOG_LEVEL=info
```

### 6.2 Seguridad Adicional

1. **Cambiar contraseñas por defecto**:
   ```bash
   # Cambiar contraseña de admin hardcodeada en el código
   # Editar server/routes.ts líneas donde aparece 'SanJeronimo2024'
   ```

2. **Configurar HTTPS con Let's Encrypt**:
   ```bash
   sudo apt install certbot python3-certbot-nginx
   sudo certbot --nginx -d tu-dominio.com
   ```

---

## 7. Solución de Problemas

### 7.1 Problemas Comunes

1. **Error "Cannot find module"**:
   ```bash
   npm install
   npm run build
   ```

2. **Error de conexión a base de datos**:
   ```bash
   # Verificar PostgreSQL está corriendo
   sudo systemctl status postgresql
   sudo systemctl start postgresql
   ```

3. **Error de permisos**:
   ```bash
   sudo chown -R ubuntu:ubuntu /home/ubuntu/dashboard-san-jeronimo
   ```

4. **Aplicación no accesible**:
   ```bash
   # Verificar PM2
   pm2 status
   pm2 logs dashboard-san-jeronimo
   
   # Verificar puerto
   netstat -tlnp | grep 5000
   ```

### 7.2 Logs y Monitoreo

1. **Ver logs de aplicación**:
   ```bash
   pm2 logs dashboard-san-jeronimo
   ```

2. **Ver logs de Nginx**:
   ```bash
   sudo tail -f /var/log/nginx/error.log
   ```

3. **Monitoreo con PM2**:
   ```bash
   pm2 monit
   ```

### 7.3 Actualizaciones

Para actualizar la aplicación:

```bash
# En el servidor
cd /home/ubuntu/dashboard-san-jeronimo
git pull origin main
npm install
npm run build
pm2 restart dashboard-san-jeronimo
```

---

## 8. Comandos de Referencia Rápida

### Oracle Cloud
```bash
# Conectar
ssh -i key.pem ubuntu@ip-oracle

# Ver estado
pm2 status
sudo systemctl status nginx postgresql

# Logs
pm2 logs
sudo tail -f /var/log/nginx/access.log
```

### Hostinger
```bash
# Conectar
ssh root@ip-hostinger

# Reiniciar servicios
pm2 restart all
sudo systemctl restart nginx
```

### Backup y Restauración
```bash
# Backup
pg_dump postgresql://user:pass@localhost:5432/db > backup.sql

# Restaurar
psql postgresql://user:pass@localhost:5432/db < backup.sql
```

---

## Conclusión

Esta guía cubre todos los aspectos necesarios para migrar tu aplicación Dashboard San Jerónimo desde Replit a GitHub y luego desplegarla en Oracle Cloud o Hostinger. 

**Pasos resumidos**:
1. ✅ Preparar aplicación en Replit
2. ✅ Subir a GitHub
3. ✅ Configurar servidor (Oracle/Hostinger)
4. ✅ Desplegar aplicación
5. ✅ Migrar base de datos
6. ✅ Configurar dominio y SSL

¡Tu aplicación estará lista para producción!
