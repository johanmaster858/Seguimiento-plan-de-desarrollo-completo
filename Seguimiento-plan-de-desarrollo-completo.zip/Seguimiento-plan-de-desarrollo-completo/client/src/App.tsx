import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import AdminPage from "@/pages/AdminPage";
import PublicAnalysisPage from "@/pages/PublicAnalysisPage";
import { AuthProvider, useAuth } from "./context/AuthContext";
import ChatBot from "@/components/ChatBot";
import { useEffect } from "react";

function Router() {
  const { checkAuth } = useAuth();

  useEffect(() => {
    checkAuth();
  }, [checkAuth]);

  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/admin" component={AdminPage} />
      <Route path="/auth" component={Dashboard} />
      <Route path="/analysis" component={PublicAnalysisPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function ChatBotWrapper() {
  const { user, isAuthenticated } = useAuth();
  
  if (!user && !isAuthenticated) return null;
  
  return <ChatBot />;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <ChatBotWrapper />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;