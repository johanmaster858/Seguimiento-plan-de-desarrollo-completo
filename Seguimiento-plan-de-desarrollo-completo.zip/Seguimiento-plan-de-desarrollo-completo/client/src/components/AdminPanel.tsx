import React, { useState, useEffect } from "react";
import { Indicator, UpdateIndicatorProgress, UpdateHistory, FinancingSource } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { formatDate, formatNumberWithDecimals } from "@/lib/utils";
import { parse } from "@/lib/csvUtils";
import AdvancedBudgetManager from "./AdvancedBudgetManager";
import CustomCSVExport from "./CustomCSVExport";

interface AdminPanelProps {
  indicators: Indicator[];
  isVisible: boolean;
}

type Year = "2024" | "2025" | "2026" | "2027";

const AdminPanel: React.FC<AdminPanelProps> = ({
  indicators,
  isVisible
}) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  if (!isVisible) return null;

  const [selectedIndicator, setSelectedIndicator] = useState<string>("");
  const [selectedYear, setSelectedYear] = useState<Year>("2024");
  const [currentProgress, setCurrentProgress] = useState<string>("");
  const [initialBudget, setInitialBudget] = useState<string>("");
  const [finalBudget, setFinalBudget] = useState<string>("");
  const [observations, setObservations] = useState<string>("");
  const [metaAnual, setMetaAnual] = useState<string>("");
  const [fileSelected, setFileSelected] = useState<boolean>(false);
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [showAdvancedBudget, setShowAdvancedBudget] = useState<boolean>(false);

  // Filtros adicionales
  const [filterProgram, setFilterProgram] = useState<string>("");
  const [filterResponsible, setFilterResponsible] = useState<string>("");
  const [searchTerm, setSearchTerm] = useState<string>("");

  // Lista única de programas y responsables para los filtros
  const uniquePrograms = Array.from(new Set(indicators.map(i => i.program))).sort();
  const uniqueResponsibles = Array.from(new Set(indicators.map(i => i.responsible))).sort();

  // Load update history
  const { data: updateHistory = [], isLoading: isHistoryLoading } = useQuery<UpdateHistory[]>({
    queryKey: ['/api/history'],
    enabled: isVisible
  });

  // Load financing sources
  const { data: financingSources = [], isLoading: isFinancingLoading } = useQuery<FinancingSource[]>({
    queryKey: ['/api/financing-sources'],
    enabled: isVisible
  });

  // Load indicator details when selected
  useEffect(() => {
    if (selectedIndicator) {
      const indicator = indicators.find(i => i.code === selectedIndicator);
      if (indicator) {
        let targetValue = 0;
        let progressValue = 0;
        let initialBudgetValue = 0;
        let finalBudgetValue = 0;

        switch(selectedYear) {
          case "2024":
            targetValue = indicator.target2024 ?? 0;
            progressValue = indicator.progress2024 ?? 0;
            initialBudgetValue = indicator.initialBudget2024 ?? 0;
            finalBudgetValue = indicator.finalBudget2024 ?? 0;
            break;
          case "2025":
            targetValue = indicator.target2025 ?? 0;
            progressValue = indicator.progress2025 ?? 0;
            initialBudgetValue = indicator.initialBudget2025 ?? 0;
            finalBudgetValue = indicator.finalBudget2025 ?? 0;
            break;
          case "2026":
            targetValue = indicator.target2026 ?? 0;
            progressValue = indicator.progress2026 ?? 0;
            initialBudgetValue = indicator.initialBudget2026 ?? 0;
            finalBudgetValue = indicator.finalBudget2026 ?? 0;
            break;
          case "2027":
            targetValue = indicator.target2027 ?? 0;
            progressValue = indicator.progress2027 ?? 0;
            initialBudgetValue = indicator.initialBudget2027 ?? 0;
            finalBudgetValue = indicator.finalBudget2027 ?? 0;
            break;
        }

        setMetaAnual(targetValue.toString());
        setCurrentProgress(progressValue.toString());
        setInitialBudget(initialBudgetValue.toString());
        setFinalBudget(finalBudgetValue.toString());
      }
    } else {
      setMetaAnual("");
      setCurrentProgress("");
      setInitialBudget("");
      setFinalBudget("");
    }
  }, [selectedIndicator, selectedYear, indicators]);

  // Update indicator mutation
  const updateMutation = useMutation({
    mutationFn: async (data: UpdateIndicatorProgress) => {
      const res = await apiRequest('PATCH', `/api/indicators/${data.code}/progress`, data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Indicador actualizado",
        description: "El progreso del indicador ha sido actualizado correctamente.",
      });

      // Invalidate indicators and history queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/indicators'] });
      queryClient.invalidateQueries({ queryKey: ['/api/history'] });

      // Reset form
      setObservations("");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo actualizar el indicador. Intente de nuevo.",
        variant: "destructive",
      });
    }
  });

  // Import data mutation
  const importMutation = useMutation({
    mutationFn: async (data: any[]) => {
      const res = await apiRequest('POST', '/api/import/indicators', data);
      return res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Importación completada",
        description: `${data.indicators.length} indicadores importados correctamente.`,
      });

      // Invalidate indicators query to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/indicators'] });

      // Reset file
      setCsvFile(null);
      setFileSelected(false);
    },
    onError: (error: any) => {
      toast({
        title: "Error de importación",
        description: error.message || "No se pudieron importar los indicadores. Verifique el formato del archivo.",
        variant: "destructive",
      });
    }
  });

  // Mutación SEGURA para importar datos predefinidos
  const importPredefinedDataMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/import/predefined-data", {});
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Importación exitosa",
        description: data.message || "Datos predefinidos importados correctamente",
      });

      // Invalidate indicators query to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/indicators'] });
      queryClient.invalidateQueries({ queryKey: ['/api/history'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error de importación",
        description: error.message || "No se pudieron importar los datos predefinidos.",
        variant: "destructive",
      });
    }
  });

  // Update financing source mutation
  const updateFinancingSourceMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: Partial<FinancingSource> }) => {
      const res = await apiRequest('PATCH', `/api/financing-sources/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Fuente actualizada",
        description: "La fuente de financiación ha sido actualizada correctamente.",
      });

      // Invalidate financing sources query to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/financing-sources'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo actualizar la fuente de financiación.",
        variant: "destructive",
      });
    }
  });

  // Handle form submission
  const handleUpdateIndicator = () => {
    if (!selectedIndicator) {
      toast({
        title: "Error",
        description: "Seleccione un indicador para actualizar.",
        variant: "destructive",
      });
      return;
    }

    if (currentProgress === "") {
      toast({
        title: "Error",
        description: "Ingrese el valor de avance actual.",
        variant: "destructive",
      });
      return;
    }

    const progress = parseFloat(currentProgress);
    if (isNaN(progress)) {
      toast({
        title: "Error",
        description: "El valor de avance debe ser un número válido.",
        variant: "destructive",
      });
      return;
    }

    // Validar presupuestos si han sido ingresados
    let initialBudgetValue = undefined;
    let finalBudgetValue = undefined;

    if (initialBudget !== "") {
      initialBudgetValue = parseFloat(initialBudget);
      if (isNaN(initialBudgetValue)) {
        toast({
          title: "Error",
          description: "El presupuesto inicial debe ser un número válido.",
          variant: "destructive",
        });
        return;
      }
    }

    if (finalBudget !== "") {
      finalBudgetValue = parseFloat(finalBudget);
      if (isNaN(finalBudgetValue)) {
        toast({
          title: "Error",
          description: "El presupuesto definitivo debe ser un número válido.",
          variant: "destructive",
        });
        return;
      }
    }

    const updateData: UpdateIndicatorProgress = {
      code: selectedIndicator,
      year: selectedYear,
      progress,
      initialBudget: initialBudgetValue,
      finalBudget: finalBudgetValue,
      observations
    };

    updateMutation.mutate(updateData);
  };

  // Handle file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setCsvFile(e.target.files[0]);
      setFileSelected(true);
    }
  };

  // Handle file import
  const handleImportData = async () => {
    if (!csvFile) {
      toast({
        title: "Error",
        description: "Seleccione un archivo CSV para importar.",
        variant: "destructive",
      });
      return;
    }

    try {
      const text = await csvFile.text();
      const indicators = parse(text);

      if (indicators.length === 0) {
        toast({
          title: "Error",
          description: "El archivo no contiene datos válidos o está vacío.",
          variant: "destructive",
        });
        return;
      }

      importMutation.mutate(indicators);
    } catch (error) {
      toast({
        title: "Error de formato",
        description: (error as Error).message || "El archivo CSV no tiene el formato correcto.",
        variant: "destructive",
      });
    }
  };

  // Download template
  const handleDownloadTemplate = async () => {
    try {
      const res = await fetch('/api/export/template');
      if (!res.ok) {
        throw new Error('Error al descargar la plantilla');
      }

      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.setAttribute("href", url);
      link.setAttribute("download", "plantilla_indicadores.csv");
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      toast({
        title: "Error",
        description: (error as Error).message || "No se pudo descargar la plantilla.",
        variant: "destructive",
      });
    }
  };

  // Handle financing source toggle
  const handleToggleFinancingSource = (id: number, active: boolean) => {
    updateFinancingSourceMutation.mutate({
      id,
      data: { active }
    });
  };

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-8 bg-white dark:bg-gray-900 min-h-screen">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 mb-6">
        <h2 className="text-xl font-bold font-roboto mb-4 flex items-center text-gray-800 dark:text-white">
          <span className="material-icons mr-2 text-blue-600 dark:text-blue-400">admin_panel_settings</span>
          Panel de Administración
        </h2>

        <div className="mb-6">
          <h3 className="text-lg font-medium font-roboto mb-3 text-gray-800 dark:text-gray-100">Actualizar Indicadores</h3>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Individual Update Form */}
            <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 bg-white dark:bg-gray-800">
              <h4 className="text-md font-medium mb-3 text-gray-800 dark:text-gray-100">Actualización Individual</h4>

              {/* Filtros adicionales */}
              <div className="mb-4 bg-gray-50 dark:bg-gray-900 p-3 rounded-md border border-gray-200 dark:border-gray-700">
                <h5 className="text-sm font-medium mb-2 text-gray-700 dark:text-gray-300 flex items-center">
                  <span className="material-icons text-sm mr-1">filter_list</span>
                  Filtros
                </h5>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {/* Filtro por programa */}
                  <div>
                    <label className="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Programa</label>
                    <select
                      className="w-full rounded-md border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 dark:text-gray-100 py-1 px-2 text-sm"
                      value={filterProgram}
                      onChange={(e) => setFilterProgram(e.target.value)}
                      data-testid="select-filter-program"
                    >
                      <option value="">Todos los programas</option>
                      {uniquePrograms.map(program => (
                        <option key={program} value={program}>{program}</option>
                      ))}
                    </select>
                  </div>

                  {/* Filtro por responsable */}
                  <div>
                    <label className="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Responsable</label>
                    <select
                      className="w-full rounded-md border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 dark:text-gray-100 py-1 px-2 text-sm"
                      value={filterResponsible}
                      onChange={(e) => setFilterResponsible(e.target.value)}
                      data-testid="select-filter-responsible"
                    >
                      <option value="">Todos los responsables</option>
                      {uniqueResponsibles.map(responsible => (
                        <option key={responsible} value={responsible}>{responsible}</option>
                      ))}
                    </select>
                  </div>

                  {/* Búsqueda por texto */}
                  <div>
                    <label className="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Buscar</label>
                    <input
                      type="text"
                      placeholder="Buscar por nombre o código"
                      className="w-full rounded-md border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 dark:text-gray-100 py-1 px-2 text-sm"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      data-testid="input-search-term"
                    />
                  </div>
                </div>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Código del Indicador</label>
                <div className="flex">
                  <select
                    className="w-full rounded-md border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 dark:text-gray-100 py-2 px-3 text-sm"
                    value={selectedIndicator}
                    onChange={(e) => setSelectedIndicator(e.target.value)}
                    data-testid="select-indicator"
                  >
                    <option value="">Seleccionar código...</option>
                    {indicators
                      .filter(indicator =>
                        (!filterProgram || indicator.program === filterProgram) &&
                        (!filterResponsible || indicator.responsible === filterResponsible) &&
                        (!searchTerm ||
                          indicator.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          indicator.name.toLowerCase().includes(searchTerm.toLowerCase())
                        )
                      )
                      .map(indicator => (
                        <option key={indicator.code} value={indicator.code}>
                          {indicator.code} - {indicator.name}
                        </option>
                      ))
                    }
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Año</label>
                  <select
                    className="w-full rounded-md border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 dark:text-gray-100 py-2 px-3 text-sm"
                    value={selectedYear}
                    onChange={(e) => setSelectedYear(e.target.value as Year)}
                    data-testid="select-year"
                  >
                    <option value="2024">2024</option>
                    <option value="2025">2025</option>
                    <option value="2026">2026</option>
                    <option value="2027">2027</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Meta Anual</label>
                  <input
                    type="text"
                    className="w-full rounded-md border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 dark:text-gray-100 py-2 px-3 text-sm"
                    placeholder="Meta para el año seleccionado"
                    value={metaAnual}
                    readOnly
                    data-testid="input-meta-anual"
                  />
                </div>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Avance Actual</label>
                <input
                  type="number"
                  className="w-full rounded-md border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 dark:text-gray-100 py-2 px-3 text-sm"
                  placeholder="Ingrese el avance actual"
                  value={currentProgress}
                  onChange={(e) => setCurrentProgress(e.target.value)}
                  data-testid="input-progress"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Presupuesto Inicial</label>
                  <input
                    type="number"
                    className="w-full rounded-md border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 dark:text-gray-100 py-2 px-3 text-sm"
                    placeholder="Presupuesto inicial (opcional)"
                    value={initialBudget}
                    onChange={(e) => setInitialBudget(e.target.value)}
                    data-testid="input-budget-initial"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Presupuesto Definitivo</label>
                  <input
                    type="number"
                    className="w-full rounded-md border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 dark:text-gray-100 py-2 px-3 text-sm"
                    placeholder="Presupuesto definitivo (opcional)"
                    value={finalBudget}
                    onChange={(e) => setFinalBudget(e.target.value)}
                    data-testid="input-budget-final"
                  />
                </div>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Observaciones</label>
                <textarea
                  className="w-full rounded-md border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 dark:text-gray-100 py-2 px-3 text-sm"
                  rows={3}
                  placeholder="Agregar observaciones sobre el avance"
                  value={observations}
                  onChange={(e) => setObservations(e.target.value)}
                  data-testid="textarea-observations"
                ></textarea>
              </div>

              <button
                className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition flex items-center justify-center"
                onClick={handleUpdateIndicator}
                disabled={updateMutation.isPending}
                data-testid="button-save-changes"
              >
                {updateMutation.isPending ? (
                  <>
                    <div className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-solid border-current border-r-transparent mr-1"></div>
                    Actualizando...
                  </>
                ) : (
                  <>
                    <span className="material-icons text-sm mr-1">save</span>
                    Guardar Cambios
                  </>
                )}
              </button>
            </div>

            {/* Batch Update Form */}
            <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 bg-white dark:bg-gray-800">
              <h4 className="text-md font-medium mb-3 text-gray-800 dark:text-gray-100">Actualización Masiva</h4>

              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Importar desde archivo CSV</label>
                <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 dark:border-gray-700 border-dashed rounded-md dark:bg-gray-800">
                  <div className="space-y-1 text-center">
                    <span className="material-icons text-gray-400 dark:text-gray-500 text-3xl">upload_file</span>
                    <div className="flex text-sm text-gray-600 dark:text-gray-400">
                      <label htmlFor="file-upload" className="relative cursor-pointer rounded-md font-medium text-blue-600 hover:text-blue-500 dark:text-blue-400 dark:hover:text-blue-300">
                        <span>Seleccionar archivo</span>
                        <input
                          id="file-upload"
                          name="file-upload"
                          type="file"
                          className="sr-only"
                          accept=".csv"
                          onChange={handleFileChange}
                        />
                      </label>
                      <p className="pl-1">o arrastre aquí</p>
                    </div>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Solo archivos CSV, máximo 10MB
                    </p>
                    {fileSelected && (
                      <p className="text-xs text-green-600 dark:text-green-400 mt-1">
                        <span className="material-icons text-sm mr-1">check_circle</span>
                        Archivo seleccionado: {csvFile?.name}
                      </p>
                    )}
                  </div>
                </div>
              </div>

              <button
                className="w-full bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700 transition flex items-center justify-center mb-4"
                onClick={handleImportData}
                disabled={!fileSelected || importMutation.isPending}
                data-testid="button-import-csv"
              >
                {importMutation.isPending ? (
                  <>
                    <div className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-solid border-current border-r-transparent mr-1"></div>
                    Importando...
                  </>
                ) : (
                  <>
                    <span className="material-icons text-sm mr-1">file_upload</span>
                    Importar Datos
                  </>
                )}
              </button>

              <button
                className="w-full bg-gray-600 text-white py-2 px-4 rounded-md hover:bg-gray-700 transition flex items-center justify-center"
                onClick={handleDownloadTemplate}
                data-testid="button-download-template"
              >
                <span className="material-icons text-sm mr-1">file_download</span>
                Descargar Plantilla CSV
              </button>
            </div>
          </div>
        </div>

        {/* Exportación CSV Personalizada */}
        <div className="mb-6">
          <CustomCSVExport indicators={indicators} year={selectedYear} />
        </div>

        {/* Importación de datos predefinidos */}
        <div className="mb-6 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900 dark:to-pink-900 p-4 rounded-lg border-l-4 border-purple-500">
          <div className="flex items-center mb-2">
            <span className="material-icons text-purple-600 dark:text-purple-400 mr-2">data_usage</span>
            <h4 className="text-lg font-medium text-purple-900 dark:text-purple-200">Importación de Datos Predefinidos</h4>
          </div>
          <p className="text-sm text-purple-700 dark:text-purple-300 mb-3">
            Esta función importa los datos de ejemplo predefinidos para testing del sistema.
            <strong className="text-purple-900 dark:text-purple-100"> Solo usar en desarrollo.</strong>
          </p>
          <button
            onClick={() => importPredefinedDataMutation.mutate()}
            disabled={importPredefinedDataMutation.isPending}
            className="bg-purple-600 hover:bg-purple-700 disabled:bg-purple-400 text-white px-4 py-2 rounded-md transition flex items-center text-sm font-medium"
            data-testid="button-import-predefined"
          >
            {importPredefinedDataMutation.isPending ? (
              <>
                <div className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-solid border-current border-r-transparent mr-2"></div>
                Importando datos...
              </>
            ) : (
              <>
                <span className="material-icons text-sm mr-2">psychology</span>
                Importar Datos de Prueba
              </>
            )}
          </button>
        </div>

        {/* Gestión Avanzada de Presupuesto por Fuentes de Financiación */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold font-roboto text-gray-800 dark:text-gray-100 flex items-center">
              <span className="material-icons mr-3 text-purple-600 dark:text-purple-400">account_balance</span>
              Gestión de Presupuesto por Fuentes de Financiación
            </h3>
            {selectedIndicator && (
              <button
                onClick={() => setShowAdvancedBudget(!showAdvancedBudget)}
                className="bg-purple-600 text-white px-4 py-2 rounded-md text-sm hover:bg-purple-700 transition flex items-center shadow-sm"
              >
                <span className="material-icons text-sm mr-2">
                  {showAdvancedBudget ? 'expand_less' : 'expand_more'}
                </span>
                {showAdvancedBudget ? 'Ocultar Panel' : 'Mostrar Panel'}
              </button>
            )}
          </div>

          {!selectedIndicator ? (
            <div className="text-center py-8 text-gray-500 dark:text-gray-400">
              <span className="material-icons text-4xl mb-3 block opacity-50">account_balance_wallet</span>
              <p className="text-sm">Seleccione un indicador para gestionar su presupuesto por fuentes de financiación</p>
            </div>
          ) : (
            showAdvancedBudget && (
              <div className="space-y-6">
                <div className="bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900 dark:to-blue-900 p-4 rounded-lg border-l-4 border-purple-500">
                  <h4 className="font-medium text-purple-900 dark:text-purple-200 mb-2">
                    📊 Distribución Presupuestal Avanzada
                  </h4>
                  <p className="text-sm text-purple-700 dark:text-purple-300">
                    Configure la distribución detallada del presupuesto por fuentes de financiación para el indicador <strong>{selectedIndicator}</strong>.
                    Puede asignar múltiples fuentes y ajustar porcentajes para cada año del cuatrienio.
                  </p>
                </div>

                {/* Panel de Gestión por Año Seleccionado */}
                <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h5 className="text-lg font-semibold text-gray-800 dark:text-gray-200 flex items-center">
                      <span className="material-icons mr-2 text-blue-600">calendar_today</span>
                      Año {selectedYear} - Presupuesto Inicial
                    </h5>
                    <AdvancedBudgetManager
                      indicator={indicators.find(i => i.code === selectedIndicator)!}
                      year={selectedYear}
                      budgetType="initial"
                      isVisible={true}
                    />
                  </div>

                  <div className="space-y-4">
                    <h5 className="text-lg font-semibold text-gray-800 dark:text-gray-200 flex items-center">
                      <span className="material-icons mr-2 text-green-600">account_balance_wallet</span>
                      Año {selectedYear} - Presupuesto Definitivo
                    </h5>
                    <AdvancedBudgetManager
                      indicator={indicators.find(i => i.code === selectedIndicator)!}
                      year={selectedYear}
                      budgetType="final"
                      isVisible={true}
                    />
                  </div>
                </div>

                {/* Vista Consolidada del Cuatrienio */}
                <div className="mt-8 p-6 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900 dark:to-indigo-900 rounded-lg border">
                  <h4 className="text-lg font-semibold text-blue-800 dark:text-blue-200 mb-4 flex items-center">
                    <span className="material-icons mr-2">date_range</span>
                    Vista Consolidada del Cuatrienio (2024-2027)
                  </h4>
                  <p className="text-sm text-blue-700 dark:text-blue-300 mb-6">
                    Gestión integral del presupuesto para todo el período del plan de desarrollo.
                  </p>

                  <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h6 className="font-medium text-blue-800 dark:text-blue-200">
                        🏦 Presupuesto Inicial Total del Cuatrienio
                      </h6>
                      <AdvancedBudgetManager
                        indicator={indicators.find(i => i.code === selectedIndicator)!}
                        year="cuatrienio"
                        budgetType="initial"
                        isVisible={true}
                      />
                    </div>

                    <div className="space-y-4">
                      <h6 className="font-medium text-blue-800 dark:text-blue-200">
                        💰 Presupuesto Definitivo Total del Cuatrienio
                      </h6>
                      <AdvancedBudgetManager
                        indicator={indicators.find(i => i.code === selectedIndicator)!}
                        year="cuatrienio"
                        budgetType="final"
                        isVisible={true}
                      />
                    </div>
                  </div>
                </div>

                {/* Gestión de Fuentes de Financiación */}
                <div className="mt-8 p-6 bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900 dark:to-emerald-900 rounded-lg border">
                  <h4 className="text-lg font-semibold text-green-800 dark:text-green-200 mb-4 flex items-center">
                    <span className="material-icons mr-2">account_balance_wallet</span>
                    Administración de Fuentes de Financiación
                  </h4>

                  {isFinancingLoading ? (
                    <div className="p-8 text-center">
                      <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-current border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
                      <p className="mt-4 text-gray-600 dark:text-gray-400">Cargando fuentes de financiación...</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <p className="text-sm text-green-700 dark:text-green-300 mb-4">
                        Active o desactive las fuentes de financiación disponibles para asignar a los presupuestos de indicadores.
                      </p>

                      {financingSources.length === 0 ? (
                        <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                          <span className="material-icons text-4xl mb-3 block opacity-50">account_balance_wallet</span>
                          <p className="text-sm">No hay fuentes de financiación configuradas</p>
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                          {financingSources.map((source) => (
                            <div
                              key={source.id}
                              className="flex items-center justify-between p-4 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 shadow-sm hover:shadow-md transition"
                              data-testid={`row-financing-source-${source.id}`}
                            >
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-semibold text-gray-800 dark:text-gray-200 truncate">
                                  {source.name}
                                </p>
                                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                                  {source.description || 'Sin descripción'}
                                </p>
                              </div>

                              <div className="ml-3">
                                <label className="inline-flex items-center cursor-pointer">
                                  <input
                                    type="checkbox"
                                    className="sr-only peer"
                                    checked={source.active ?? true}
                                    onChange={(e) => handleToggleFinancingSource(source.id, e.target.checked)}
                                    disabled={updateFinancingSourceMutation.isPending}
                                    data-testid={`toggle-financing-source-${source.id}`}
                                  />
                                  <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                                  <span className="ml-2 text-xs font-medium text-gray-600 dark:text-gray-400">
                                    {source.active ? 'Activa' : 'Inactiva'}
                                  </span>
                                </label>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            )
          )}
        </div>

        {/* Historial de Actualizaciones */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 mb-6">
          <h3 className="text-lg font-medium font-roboto mb-3 text-gray-800 dark:text-gray-100">Historial de Actualizaciones</h3>

          {isHistoryLoading ? (
            <div className="p-8 text-center">
              <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-current border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
              <p className="mt-4 text-gray-600 dark:text-gray-400">Cargando historial...</p>
            </div>
          ) : updateHistory && updateHistory.length > 0 ? (
            <div className="overflow-x-auto dark:bg-gray-800 rounded-lg">
              <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead className="bg-gray-50 dark:bg-gray-700">
                  <tr>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Fecha</th>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Usuario</th>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Indicador</th>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Cambio</th>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Detalles</th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                  {updateHistory.map((item: any) => (
                    <tr key={item.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-800 dark:text-gray-200">
                        {formatDate(new Date(item.createdAt))}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-800 dark:text-gray-200">{item.username}</td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-800 dark:text-gray-200">{item.indicatorCode}</td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-800 dark:text-gray-200">
                        {formatNumberWithDecimals(item.previousValue || 0)} → {formatNumberWithDecimals(item.newValue)}
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-800 dark:text-gray-200">
                        {item.observations
                          ? item.observations
                          : `Actualización de avance para ${item.year}`}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="p-8 text-center">
              <p className="text-gray-600 dark:text-gray-400">No hay datos de historial disponibles.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;