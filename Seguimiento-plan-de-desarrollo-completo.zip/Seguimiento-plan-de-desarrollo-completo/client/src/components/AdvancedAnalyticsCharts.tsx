
import React, { useState, useMemo } from "react";
import { Indicator } from "@shared/schema";
import { SimpleBarChart, SimplePieChart } from "@/components/ui/chart";
import { getStrategicLineColor, getStrategicLineShortName, getStrategicLineClass } from "@/lib/utils";

// Mapeo de números de ODS a sus nombres internacionales
const ODS_NAMES: Record<number, string> = {
  1: "Fin de la Pobreza",
  2: "Hambre Cero",
  3: "Salud y Bienestar",
  4: "Educación de Calidad",
  5: "Igualdad de Género",
  6: "Agua Limpia y Saneamiento",
  7: "Energía Asequible y No Contaminante",
  8: "Trabajo Decente y Crecimiento Económico",
  9: "Industria, Innovación e Infraestructura",
  10: "Reducción de las Desigualdades",
  11: "Ciudades y Comunidades Sostenibles",
  12: "Producción y Consumo Responsables",
  13: "Acción por el Clima",
  14: "Vida Submarina",
  15: "Vida de Ecosistemas Terrestres",
  16: "Paz, Justicia e Instituciones Sólidas",
  17: "Alianzas para Lograr los Objetivos"
};

function getODSName(odsNumber: number): string {
  return ODS_NAMES[odsNumber] || `ODS ${odsNumber}`;
}

interface AdvancedAnalyticsChartsProps {
  indicators: Indicator[];
  year: string;
}

const AdvancedAnalyticsCharts: React.FC<AdvancedAnalyticsChartsProps> = ({
  indicators,
  year
}) => {
  const [activeTab, setActiveTab] = useState<'ods-correlation' | 'workload-distribution'>('ods-correlation');

  // Análisis de correlación ODS-Líneas Estratégicas
  const odsCorrelationData = useMemo(() => {
    if (!indicators || indicators.length === 0) {
      return {
        odsDistribution: [],
        lineOdsData: [],
        correlationMatrix: {}
      };
    }

    const correlationMatrix: Record<string, Record<number, number>> = {};
    const lineOdsCount: Record<string, Record<number, number>> = {};
    
    // Inicializar matrices
    indicators.forEach(indicator => {
      if (!correlationMatrix[indicator.strategicLine]) {
        correlationMatrix[indicator.strategicLine] = {};
        lineOdsCount[indicator.strategicLine] = {};
      }
      
      const ods = indicator.ods;
      if (ods) {
        if (!correlationMatrix[indicator.strategicLine][ods]) {
          correlationMatrix[indicator.strategicLine][ods] = 0;
          lineOdsCount[indicator.strategicLine][ods] = 0;
        }
        correlationMatrix[indicator.strategicLine][ods]++;
        lineOdsCount[indicator.strategicLine][ods]++;
      }
    });

    // Convertir a formato para gráficos
    const odsDistribution: Array<{name: string, value: number, color: string}> = [];
    const allOds = new Set<number>();
    
    Object.values(correlationMatrix).forEach(lineOds => {
      Object.keys(lineOds).forEach(ods => allOds.add(parseInt(ods)));
    });

    Array.from(allOds).sort((a, b) => a - b).forEach(ods => {
      let totalCount = 0;
      Object.values(correlationMatrix).forEach(lineOds => {
        totalCount += lineOds[ods] || 0;
      });
      
      if (totalCount > 0) {
        odsDistribution.push({
          name: getODSName(ods),
          value: totalCount,
          color: `hsl(${(ods * 25) % 360}, 70%, 60%)`
        });
      }
    });

    // Datos de correlación por línea estratégica
    const lineOdsData = Object.entries(correlationMatrix).map(([line, odsCount]) => {
      const totalIndicators = Object.values(odsCount).reduce((sum, count) => sum + count, 0);
      const primaryOds = Object.entries(odsCount).reduce((max, [ods, count]) => 
        count > max.count ? { ods: parseInt(ods), count } : max, 
        { ods: 0, count: 0 }
      );
      
      return {
        name: getStrategicLineShortName(line),
        fullName: line,
        totalIndicators,
        primaryOds: primaryOds.ods,
        primaryOdsCount: primaryOds.count,
        odsDistribution: Object.entries(odsCount).map(([ods, count]) => ({
          ods: parseInt(ods),
          count,
          percentage: (count / totalIndicators) * 100
        })),
        color: getStrategicLineColor(line)
      };
    });

    return { odsDistribution, lineOdsData, correlationMatrix };
  }, [indicators]);

  // Análisis de distribución de responsables y carga de trabajo
  const workloadData = useMemo(() => {
    if (!indicators || indicators.length === 0) {
      return {
        responsibleArray: [],
        sectorArray: []
      };
    }

    const responsibleStats: Record<string, {
      count: number,
      sectors: Record<string, number>,
      strategicLines: Record<string, number>,
      progress: number,
      target: number
    }> = {};

    const sectorStats: Record<string, {
      count: number,
      responsibles: Record<string, number>,
      strategicLines: Record<string, number>
    }> = {};

    indicators.forEach(indicator => {
      // Procesar responsables (pueden ser múltiples separados por coma)
      const responsibles = indicator.responsible.split(',').map(r => r.trim());
      
      responsibles.forEach(responsible => {
        if (!responsibleStats[responsible]) {
          responsibleStats[responsible] = {
            count: 0,
            sectors: {},
            strategicLines: {},
            progress: 0,
            target: 0
          };
        }

        responsibleStats[responsible].count++;
        
        // Contar sectores
        if (!responsibleStats[responsible].sectors[indicator.sector]) {
          responsibleStats[responsible].sectors[indicator.sector] = 0;
        }
        responsibleStats[responsible].sectors[indicator.sector]++;

        // Contar líneas estratégicas
        if (!responsibleStats[responsible].strategicLines[indicator.strategicLine]) {
          responsibleStats[responsible].strategicLines[indicator.strategicLine] = 0;
        }
        responsibleStats[responsible].strategicLines[indicator.strategicLine]++;

        // Acumular progreso según el año seleccionado
        let progress = 0;
        let target = 0;
        
        switch(year) {
          case "2024":
            progress = indicator.progress2024 || 0;
            target = indicator.target2024 || 0;
            break;
          case "2025":
            progress = indicator.progress2025 || 0;
            target = indicator.target2025 || 0;
            break;
          case "2026":
            progress = indicator.progress2026 || 0;
            target = indicator.target2026 || 0;
            break;
          case "2027":
            progress = indicator.progress2027 || 0;
            target = indicator.target2027 || 0;
            break;
          case "cuatrienio":
          default:
            progress = (indicator.progress2024 || 0) + 
                       (indicator.progress2025 || 0) + 
                       (indicator.progress2026 || 0) + 
                       (indicator.progress2027 || 0);
            target = indicator.totalTarget || 0;
            break;
        }

        responsibleStats[responsible].progress += progress;
        responsibleStats[responsible].target += target;
      });

      // Procesar sectores
      if (!sectorStats[indicator.sector]) {
        sectorStats[indicator.sector] = {
          count: 0,
          responsibles: {},
          strategicLines: {}
        };
      }

      sectorStats[indicator.sector].count++;
      
      responsibles.forEach(responsible => {
        if (!sectorStats[indicator.sector].responsibles[responsible]) {
          sectorStats[indicator.sector].responsibles[responsible] = 0;
        }
        sectorStats[indicator.sector].responsibles[responsible]++;
      });

      if (!sectorStats[indicator.sector].strategicLines[indicator.strategicLine]) {
        sectorStats[indicator.sector].strategicLines[indicator.strategicLine] = 0;
      }
      sectorStats[indicator.sector].strategicLines[indicator.strategicLine]++;
    });

    // Convertir a arrays para gráficos
    const responsibleArray = Object.entries(responsibleStats)
      .map(([name, stats]) => ({
        name,
        count: stats.count,
        sectorsCount: Object.keys(stats.sectors).length,
        mainSector: Object.entries(stats.sectors).reduce((max, [sector, count]) => 
          count > max.count ? { sector, count } : max, 
          { sector: '', count: 0 }
        ).sector,
        mainLine: Object.entries(stats.strategicLines).reduce((max, [line, count]) => 
          count > max.count ? { line, count } : max, 
          { line: '', count: 0 }
        ).line,
        progressPercentage: stats.target > 0 ? (stats.progress / stats.target) * 100 : 0,
        color: getStrategicLineColor(Object.entries(stats.strategicLines).reduce((max, [line, count]) => 
          count > max.count ? { line, count } : max, 
          { line: '', count: 0 }
        ).line)
      }))
      .sort((a, b) => b.count - a.count);

    const sectorArray = Object.entries(sectorStats)
      .map(([name, stats]) => ({
        name,
        count: stats.count,
        responsiblesCount: Object.keys(stats.responsibles).length,
        mainResponsible: Object.entries(stats.responsibles).reduce((max, [resp, count]) => 
          count > max.count ? { resp, count } : max, 
          { resp: '', count: 0 }
        ).resp,
        mainLine: Object.entries(stats.strategicLines).reduce((max, [line, count]) => 
          count > max.count ? { line, count } : max, 
          { line: '', count: 0 }
        ).line,
        color: getStrategicLineColor(Object.entries(stats.strategicLines).reduce((max, [line, count]) => 
          count > max.count ? { line, count } : max, 
          { line: '', count: 0 }
        ).line)
      }))
      .sort((a, b) => b.count - a.count);

    return { responsibleArray, sectorArray };
  }, [indicators, year]);

  // Skip if no indicators - moved after all hooks
  if (!indicators || indicators.length === 0) {
    return (
      <div className="mb-6">
        <h2 className="text-xl font-bold font-roboto mb-4 dark:text-white">Análisis Avanzados</h2>
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 text-center">
          <p className="text-gray-500 dark:text-gray-400">No hay indicadores disponibles para mostrar análisis avanzados.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="mb-6">
      <h2 className="text-xl font-bold font-roboto mb-4 dark:text-white">Análisis Avanzados</h2>
      
      {/* Tabs para diferentes análisis */}
      <div className="flex mb-4 border-b border-gray-200 dark:border-gray-700">
        <button 
          className={`py-2 px-4 font-medium text-sm ${
            activeTab === 'ods-correlation' 
              ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-600 dark:border-blue-400' 
              : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
          }`}
          onClick={() => setActiveTab('ods-correlation')}
        >
          Correlación ODS-Líneas Estratégicas
        </button>
        <button 
          className={`py-2 px-4 font-medium text-sm ${
            activeTab === 'workload-distribution' 
              ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-600 dark:border-blue-400' 
              : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
          }`}
          onClick={() => setActiveTab('workload-distribution')}
        >
          Distribución de Carga de Trabajo
        </button>
      </div>
      
      {/* Contenido según tab seleccionado */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {activeTab === 'ods-correlation' && (
          <>
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
              <h3 className="text-lg font-medium mb-3 dark:text-white">Distribución General de ODS</h3>
              <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                Cantidad total de indicadores por Objetivo de Desarrollo Sostenible.
              </div>
              <SimpleBarChart 
                data={odsCorrelationData.odsDistribution}
                height={300}
                xAxisLabel="ODS"
                yAxisLabel="Cantidad de Indicadores"
              />
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
              <h3 className="text-lg font-medium mb-3 dark:text-white">ODS Principales por Línea Estratégica</h3>
              <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                Total de indicadores por línea estratégica usando colores consistentes.
              </div>
              <SimpleBarChart 
                data={odsCorrelationData.lineOdsData.map(line => ({
                  name: line.name,
                  value: line.totalIndicators,
                  color: line.color
                }))}
                height={300}
                xAxisLabel="Línea Estratégica"
                yAxisLabel="Total Indicadores"
              />
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 col-span-1 lg:col-span-2">
              <h3 className="text-lg font-medium mb-3 dark:text-white">Matriz de Correlación Detallada</h3>
              <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                Distribución detallada de ODS por línea estratégica.
              </div>
              <div className="overflow-auto max-h-96">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                  <thead className="bg-gray-50 dark:bg-gray-700">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Línea Estratégica</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Total Indicadores</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">ODS Principal</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Distribución ODS</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                    {odsCorrelationData.lineOdsData.map(line => (
                      <tr key={line.fullName}>
                        <td className="px-4 py-2">
                          <span className={`px-2 py-1 rounded-full text-xs ${getStrategicLineClass(line.fullName)}`}>
                            {line.name}
                          </span>
                        </td>
                        <td className="px-4 py-2 text-sm text-gray-900 dark:text-gray-200">{line.totalIndicators}</td>
                        <td className="px-4 py-2 text-sm text-gray-900 dark:text-gray-200">{getODSName(line.primaryOds)} ({line.primaryOdsCount})</td>
                        <td className="px-4 py-2">
                          <div className="flex flex-wrap gap-1">
                            {line.odsDistribution.slice(0, 3).map(ods => (
                              <span key={ods.ods} className="text-xs bg-gray-100 dark:bg-gray-700 px-2 py-1 rounded" title={getODSName(ods.ods)}>
                                ODS {ods.ods}: {ods.count}
                              </span>
                            ))}
                            {line.odsDistribution.length > 3 && (
                              <span className="text-xs text-gray-500">+{line.odsDistribution.length - 3} más</span>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
        
        {activeTab === 'workload-distribution' && (
          <>
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
              <h3 className="text-lg font-medium mb-3 dark:text-white">Carga de Trabajo por Responsable</h3>
              <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                Cantidad de indicadores asignados a cada responsable.
              </div>
              <SimpleBarChart 
                data={workloadData.responsibleArray.slice(0, 10).map(resp => ({
                  name: resp.name.length > 15 ? resp.name.substring(0, 12) + '...' : resp.name,
                  value: resp.count,
                  color: resp.color
                }))}
                height={300}
                xAxisLabel="Responsable"
                yAxisLabel="Cantidad de Indicadores"
              />
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
              <h3 className="text-lg font-medium mb-3 dark:text-white">Distribución por Sector</h3>
              <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                Cantidad de indicadores por sector gubernamental.
              </div>
              <SimplePieChart 
                data={workloadData.sectorArray.slice(0, 8).map(sector => ({
                  name: sector.name.length > 20 ? sector.name.substring(0, 17) + '...' : sector.name,
                  value: sector.count,
                  color: sector.color
                }))}
                height={300}
              />
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 col-span-1 lg:col-span-2">
              <h3 className="text-lg font-medium mb-3 dark:text-white">Detalle de Responsables y Rendimiento</h3>
              <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                Análisis detallado de carga de trabajo y rendimiento por responsable.
              </div>
              <div className="overflow-auto max-h-96">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                  <thead className="bg-gray-50 dark:bg-gray-700">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Responsable</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Indicadores</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Sectores</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Sector Principal</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Avance Promedio</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                    {workloadData.responsibleArray.map(resp => (
                      <tr key={resp.name}>
                        <td className="px-4 py-2 text-sm font-medium text-gray-900 dark:text-gray-200">{resp.name}</td>
                        <td className="px-4 py-2 text-sm text-gray-900 dark:text-gray-200">{resp.count}</td>
                        <td className="px-4 py-2 text-sm text-gray-900 dark:text-gray-200">{resp.sectorsCount}</td>
                        <td className="px-4 py-2 text-sm text-gray-900 dark:text-gray-200">{resp.mainSector}</td>
                        <td className="px-4 py-2">
                          <div className="flex items-center">
                            <span className={`text-sm font-medium ${
                              resp.progressPercentage >= 90 ? 'text-green-600 dark:text-green-500' : 
                              resp.progressPercentage >= 70 ? 'text-amber-500 dark:text-amber-400' : 
                              'text-red-600 dark:text-red-400'
                            }`}>{resp.progressPercentage.toFixed(1)}%</span>
                            <div className="ml-2 w-16 h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                              <div 
                                className={`h-full rounded-full ${
                                  resp.progressPercentage >= 90 ? 'bg-green-600 dark:bg-green-500' : 
                                  resp.progressPercentage >= 70 ? 'bg-amber-500 dark:bg-amber-400' : 
                                  'bg-red-600 dark:bg-red-400'
                                }`}
                                style={{ width: `${Math.min(resp.progressPercentage, 100)}%` }}
                              ></div>
                            </div>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default AdvancedAnalyticsCharts;
