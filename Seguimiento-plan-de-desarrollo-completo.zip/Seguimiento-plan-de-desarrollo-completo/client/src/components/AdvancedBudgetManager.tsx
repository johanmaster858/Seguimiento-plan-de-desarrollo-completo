
import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { Indicator, FinancingSource } from '@shared/schema';

interface AdvancedBudgetManagerProps {
  indicator: Indicator;
  year: string;
  budgetType: 'initial' | 'final';
  isVisible: boolean;
}

interface FinancingDistribution {
  id: string;
  financingSourceId: number;
  amount: number;
  percentage: number;
}

const AdvancedBudgetManager: React.FC<AdvancedBudgetManagerProps> = ({
  indicator,
  year,
  budgetType,
  isVisible
}) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [distributions, setDistributions] = useState<FinancingDistribution[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [totalBudget, setTotalBudget] = useState(0);

  // Load financing sources
  const { data: financingSources = [] } = useQuery<FinancingSource[]>({
    queryKey: ['/api/financing-sources'],
  });

  // Load existing distributions
  const { data: existingDistributions = [] } = useQuery({
    queryKey: [`/api/indicators/${indicator.code}/budget-distribution`],
    enabled: isVisible
  });

  // Calculate current budget based on year and type
  useEffect(() => {
    if (!indicator) return;
    
    let currentBudget = 0;
    if (year === 'cuatrienio') {
      currentBudget = budgetType === 'initial' ? (indicator.totalInitialBudget || 0) : (indicator.totalFinalBudget || 0);
    } else {
      switch (year) {
        case '2024':
          currentBudget = budgetType === 'initial' ? (indicator.initialBudget2024 || 0) : (indicator.finalBudget2024 || 0);
          break;
        case '2025':
          currentBudget = budgetType === 'initial' ? (indicator.initialBudget2025 || 0) : (indicator.finalBudget2025 || 0);
          break;
        case '2026':
          currentBudget = budgetType === 'initial' ? (indicator.initialBudget2026 || 0) : (indicator.finalBudget2026 || 0);
          break;
        case '2027':
          currentBudget = budgetType === 'initial' ? (indicator.initialBudget2027 || 0) : (indicator.finalBudget2027 || 0);
          break;
        default:
          currentBudget = 0;
      }
    }
    
    setTotalBudget(currentBudget);
  }, [indicator, year, budgetType]);

  // Initialize distributions from existing data
  useEffect(() => {
    if (existingDistributions.length > 0) {
      const yearDistributions = existingDistributions.filter(
        (d: any) => d.year === year && d.budgetType === budgetType
      );
      
      if (yearDistributions.length > 0) {
        const mappedDistributions = yearDistributions.map((d: any, index: number) => ({
          id: `dist-${index}`,
          financingSourceId: d.financingSourceId,
          amount: d.amount,
          percentage: d.percentage
        }));
        setDistributions(mappedDistributions);
      } else {
        initializeDefaultDistribution();
      }
    } else {
      initializeDefaultDistribution();
    }
  }, [existingDistributions, year, budgetType, totalBudget, financingSources]);

  const initializeDefaultDistribution = () => {
    if (totalBudget > 0 && financingSources.length > 0) {
      const defaultSource = financingSources.find(s => s.active) || financingSources[0];
      if (defaultSource) {
        setDistributions([{
          id: 'dist-1',
          financingSourceId: defaultSource.id,
          amount: totalBudget,
          percentage: 100
        }]);
      }
    } else {
      setDistributions([]);
    }
  };

  // Save distributions mutation
  const saveMutation = useMutation({
    mutationFn: async (distributionData: any) => {
      const response = await fetch(`/api/indicators/${indicator.code}/budget-distribution`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(distributionData)
      });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Error saving distribution');
      }
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Distribución guardada",
        description: "La distribución del presupuesto ha sido guardada correctamente.",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/indicators/${indicator.code}/budget-distribution`] });
      queryClient.invalidateQueries({ queryKey: ['/api/indicators'] });
      setIsEditing(false);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo guardar la distribución.",
        variant: "destructive",
      });
    }
  });

  const addDistribution = () => {
    const availableSources = financingSources.filter(s => 
      s.active && !distributions.some(d => d.financingSourceId === s.id)
    );
    
    if (availableSources.length > 0) {
      const newId = `dist-${Date.now()}`;
      const newDistribution: FinancingDistribution = {
        id: newId,
        financingSourceId: availableSources[0].id,
        amount: 0,
        percentage: 0
      };
      setDistributions([...distributions, newDistribution]);
    } else {
      toast({
        title: "Sin fuentes disponibles",
        description: "No hay más fuentes de financiación disponibles para agregar.",
        variant: "destructive",
      });
    }
  };

  const removeDistribution = (id: string) => {
    const newDistributions = distributions.filter(d => d.id !== id);
    setDistributions(newDistributions);
    recalculatePercentages(newDistributions);
  };

  const updateDistribution = (id: string, field: 'amount' | 'percentage' | 'financingSourceId', value: number) => {
    const newDistributions = distributions.map(d => {
      if (d.id === id) {
        const updated = { ...d };
        if (field === 'amount') {
          updated.amount = value;
          updated.percentage = totalBudget > 0 ? (value / totalBudget) * 100 : 0;
        } else if (field === 'percentage') {
          updated.percentage = value;
          updated.amount = (value / 100) * totalBudget;
        } else if (field === 'financingSourceId') {
          updated.financingSourceId = value;
        }
        return updated;
      }
      return d;
    });
    
    setDistributions(newDistributions);
  };

  const recalculatePercentages = (newDistributions: FinancingDistribution[]) => {
    const totalAmount = newDistributions.reduce((sum, d) => sum + d.amount, 0);
    
    if (totalAmount > 0) {
      const updated = newDistributions.map(d => ({
        ...d,
        percentage: (d.amount / totalAmount) * 100
      }));
      setDistributions(updated);
    }
  };

  const distributeEqually = () => {
    if (distributions.length === 0) return;
    
    const amountPerSource = totalBudget / distributions.length;
    const percentagePerSource = 100 / distributions.length;
    
    const updated = distributions.map(d => ({
      ...d,
      amount: amountPerSource,
      percentage: percentagePerSource
    }));
    
    setDistributions(updated);
  };

  const adjustToTotal = () => {
    const currentTotal = distributions.reduce((sum, d) => sum + d.amount, 0);
    const difference = totalBudget - currentTotal;
    
    if (distributions.length > 0 && Math.abs(difference) > 0.01) {
      const updated = [...distributions];
      updated[0].amount += difference;
      updated[0].percentage = totalBudget > 0 ? (updated[0].amount / totalBudget) * 100 : 0;
      setDistributions(updated);
    }
  };

  const handleSave = () => {
    const totalAssigned = distributions.reduce((sum, d) => sum + d.amount, 0);
    
    if (Math.abs(totalAssigned - totalBudget) > 0.01) {
      toast({
        title: "Error de distribución",
        description: "La suma de las distribuciones no coincide con el presupuesto total.",
        variant: "destructive",
      });
      return;
    }

    const distributionData = {
      year,
      budgetType,
      distributions: distributions.map(d => ({
        financingSourceId: d.financingSourceId,
        amount: d.amount,
        percentage: d.percentage
      })),
      totalAmount: totalBudget
    };
    
    saveMutation.mutate(distributionData);
  };

  const totalAssigned = distributions.reduce((sum, d) => sum + d.amount, 0);
  const totalPercentage = distributions.reduce((sum, d) => sum + d.percentage, 0);
  const isBalanced = Math.abs(totalAssigned - totalBudget) < 0.01;

  if (!isVisible) return null;

  return (
    <div className="border rounded-lg p-6 bg-white dark:bg-gray-800 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <h4 className="text-lg font-semibold text-gray-800 dark:text-gray-200 flex items-center">
          <span className="material-icons mr-2 text-blue-600 dark:text-blue-400">account_balance_wallet</span>
          Gestión Avanzada de Presupuesto {budgetType === 'initial' ? 'Inicial' : 'Definitivo'} - {year}
        </h4>
        
        <div className="flex space-x-2">
          <button
            onClick={() => setIsEditing(!isEditing)}
            className="bg-gray-600 text-white px-3 py-2 rounded text-sm hover:bg-gray-700 transition flex items-center"
          >
            <span className="material-icons text-sm mr-1">
              {isEditing ? 'cancel' : 'edit'}
            </span>
            {isEditing ? 'Cancelar' : 'Editar'}
          </button>
        </div>
      </div>
      
      {/* Budget Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 p-4 bg-gray-50 dark:bg-gray-900 rounded-lg">
        <div className="text-center">
          <div className="text-sm text-gray-600 dark:text-gray-400">Presupuesto Total</div>
          <div className="text-xl font-bold text-blue-600 dark:text-blue-400">
            ${totalBudget.toLocaleString()}
          </div>
        </div>
        <div className="text-center">
          <div className="text-sm text-gray-600 dark:text-gray-400">Total Asignado</div>
          <div className={`text-xl font-bold ${isBalanced ? 'text-green-600' : 'text-red-600'}`}>
            ${totalAssigned.toLocaleString()}
          </div>
        </div>
        <div className="text-center">
          <div className="text-sm text-gray-600 dark:text-gray-400">Diferencia</div>
          <div className={`text-xl font-bold ${isBalanced ? 'text-green-600' : 'text-red-600'}`}>
            ${(totalBudget - totalAssigned).toLocaleString()}
          </div>
        </div>
      </div>

      {/* Distribution List */}
      <div className="space-y-4 mb-6">
        {distributions.map((distribution, index) => {
          const source = financingSources.find(s => s.id === distribution.financingSourceId);
          return (
            <div key={distribution.id} className="flex items-center space-x-3 p-4 bg-gray-50 dark:bg-gray-900 rounded-lg border">
              <div className="flex items-center justify-center w-8 h-8 bg-blue-100 dark:bg-blue-900 rounded-full">
                <span className="text-blue-600 dark:text-blue-400 font-bold text-sm">{index + 1}</span>
              </div>
              
              <div className="flex-1 grid grid-cols-1 md:grid-cols-4 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">
                    Fuente de Financiación
                  </label>
                  <select
                    value={distribution.financingSourceId}
                    onChange={(e) => updateDistribution(distribution.id, 'financingSourceId', parseInt(e.target.value))}
                    disabled={!isEditing}
                    className="w-full rounded border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-sm disabled:bg-gray-100 disabled:cursor-not-allowed"
                  >
                    {financingSources.filter(s => s.active).map(source => (
                      <option key={source.id} value={source.id}>{source.name}</option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">
                    Monto ($)
                  </label>
                  <input
                    type="number"
                    value={distribution.amount}
                    onChange={(e) => updateDistribution(distribution.id, 'amount', parseFloat(e.target.value) || 0)}
                    disabled={!isEditing}
                    className="w-full rounded border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-sm disabled:bg-gray-100 disabled:cursor-not-allowed"
                    step="0.01"
                  />
                </div>
                
                <div>
                  <label className="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">
                    Porcentaje (%)
                  </label>
                  <input
                    type="number"
                    value={Math.round(distribution.percentage * 100) / 100}
                    onChange={(e) => updateDistribution(distribution.id, 'percentage', parseFloat(e.target.value) || 0)}
                    disabled={!isEditing}
                    className="w-full rounded border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-sm disabled:bg-gray-100 disabled:cursor-not-allowed"
                    step="0.01"
                    max="100"
                    min="0"
                  />
                </div>
                
                <div className="flex items-end">
                  {isEditing && distributions.length > 1 && (
                    <button
                      onClick={() => removeDistribution(distribution.id)}
                      className="text-red-600 hover:text-red-800 p-2 rounded hover:bg-red-50 dark:hover:bg-red-900"
                      title="Eliminar fuente"
                    >
                      <span className="material-icons text-sm">delete</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Action Buttons */}
      {isEditing && (
        <div className="flex flex-wrap gap-3 mb-4">
          <button
            onClick={addDistribution}
            className="bg-green-600 text-white px-3 py-2 rounded text-sm hover:bg-green-700 transition flex items-center"
            disabled={distributions.length >= financingSources.filter(s => s.active).length}
          >
            <span className="material-icons text-sm mr-1">add</span>
            Agregar Fuente
          </button>
          
          <button
            onClick={distributeEqually}
            className="bg-blue-600 text-white px-3 py-2 rounded text-sm hover:bg-blue-700 transition flex items-center"
            disabled={distributions.length === 0}
          >
            <span className="material-icons text-sm mr-1">balance</span>
            Distribuir Equitativamente
          </button>
          
          <button
            onClick={adjustToTotal}
            className="bg-yellow-600 text-white px-3 py-2 rounded text-sm hover:bg-yellow-700 transition flex items-center"
            disabled={distributions.length === 0}
          >
            <span className="material-icons text-sm mr-1">tune</span>
            Ajustar al Total
          </button>
        </div>
      )}

      {/* Summary and Save */}
      <div className="flex items-center justify-between pt-4 border-t border-gray-200 dark:border-gray-700">
        <div className="text-sm text-gray-600 dark:text-gray-400">
          Total: {distributions.length} fuente(s) • 
          {Math.round(totalPercentage * 100) / 100}% asignado • 
          <span className={isBalanced ? 'text-green-600' : 'text-red-600'}>
            {isBalanced ? 'Balanceado' : 'Desbalanceado'}
          </span>
        </div>
        
        {isEditing && (
          <button
            onClick={handleSave}
            disabled={!isBalanced || saveMutation.isPending || distributions.length === 0}
            className="bg-blue-600 text-white px-4 py-2 rounded text-sm hover:bg-blue-700 disabled:bg-gray-400 transition flex items-center"
          >
            {saveMutation.isPending ? (
              <>
                <div className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-solid border-current border-r-transparent mr-1"></div>
                Guardando...
              </>
            ) : (
              <>
                <span className="material-icons text-sm mr-1">save</span>
                Guardar Distribución
              </>
            )}
          </button>
        )}
      </div>
      
      {!isBalanced && (
        <div className="mt-3 p-3 bg-red-50 dark:bg-red-900 border border-red-200 dark:border-red-700 rounded text-sm text-red-700 dark:text-red-300">
          <span className="material-icons text-sm mr-1">warning</span>
          La suma de las distribuciones no coincide con el presupuesto total. 
          Ajuste los valores antes de guardar.
        </div>
      )}
    </div>
  );
};

export default AdvancedBudgetManager;
