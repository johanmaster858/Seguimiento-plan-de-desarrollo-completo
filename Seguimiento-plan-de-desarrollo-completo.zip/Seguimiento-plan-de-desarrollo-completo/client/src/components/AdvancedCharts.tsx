import React, { useState } from "react";
import { Indicator } from "@shared/schema";
import { 
  calculateStrategicLineStats, 
  calculateYearlyProgress,
  formatNumberWithDecimals,
  getStrategicLineColor
} from "@/lib/utils";
import {
  SimpleBarChart,
  SimpleLineChart,
  SimplePieChart,
  StrategicLineBarChart,
  StatusPieChart,
  YearlyProgressLineChart
} from "@/components/ui/chart";

interface AdvancedChartsProps {
  indicators: Indicator[];
  year: string;
}

const AdvancedCharts: React.FC<AdvancedChartsProps> = ({ indicators, year }) => {
  const [activeTab, setActiveTab] = useState<'lines' | 'programs' | 'yearly'>('lines');
  
  // Skip if no indicators
  if (!indicators || indicators.length === 0) {
    return (
      <div className="mb-6">
        <h2 className="text-xl font-bold font-roboto mb-4 dark:text-white">Visualizaciones Avanzadas</h2>
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 text-center">
          <p className="text-gray-500 dark:text-gray-400">No hay indicadores disponibles para mostrar visualizaciones.</p>
        </div>
      </div>
    );
  }
  
  // Prepare data for charts
  const strategicLineStats = calculateStrategicLineStats(indicators, year);
  const yearlyProgress = calculateYearlyProgress(indicators);
  
  // Prepare data for programs chart
  const programStats = indicators.reduce((acc, indicator) => {
    const program = indicator.program;
    
    if (!acc[program]) {
      acc[program] = {
        count: 0,
        totalProgress: 0,
        indicators: []
      };
    }
    
    // Get progress for the selected year
    let progress = 0;
    let target = 0;
    
    switch(year) {
      case "2024":
        progress = indicator.progress2024 || 0;
        target = indicator.target2024 || 0;
        break;
      case "2025":
        progress = indicator.progress2025 || 0;
        target = indicator.target2025 || 0;
        break;
      case "2026":
        progress = indicator.progress2026 || 0;
        target = indicator.target2026 || 0;
        break;
      case "2027":
        progress = indicator.progress2027 || 0;
        target = indicator.target2027 || 0;
        break;
      case "cuatrienio":
      default:
        progress = indicator.totalProgress || 0;
        target = indicator.totalTarget || 0;
        break;
    }
    
    // Calculate percentage
    const percentage = target > 0 ? (progress / target) * 100 : 0;
    
    // Add to accumulator
    acc[program].count += 1;
    acc[program].totalProgress += percentage;
    acc[program].indicators.push(indicator);
    
    return acc;
  }, {} as Record<string, { count: number, totalProgress: number, indicators: Indicator[] }>);
  
  // Convert to array and calculate average
  const programStatsArray = Object.entries(programStats)
    .map(([name, { count, totalProgress }]) => ({
      name,
      percentage: count > 0 ? totalProgress / count : 0
    }))
    .sort((a, b) => b.percentage - a.percentage);
  
  // Status counts for pie chart
  const statusCounts = indicators.reduce(
    (acc, indicator) => {
      let progress = 0;
      let target = 0;
      
      switch(year) {
        case "2024":
          progress = indicator.progress2024 || 0;
          target = indicator.target2024 || 0;
          break;
        case "2025":
          progress = indicator.progress2025 || 0;
          target = indicator.target2025 || 0;
          break;
        case "2026":
          progress = indicator.progress2026 || 0;
          target = indicator.target2026 || 0;
          break;
        case "2027":
          progress = indicator.progress2027 || 0;
          target = indicator.target2027 || 0;
          break;
        case "cuatrienio":
        default:
          progress = indicator.totalProgress || 0;
          target = indicator.totalTarget || 0;
          break;
      }
      
      const percentage = target > 0 ? (progress / target) * 100 : 0;
      
      if (percentage >= 100) {
        acc.exceeding += 1;
      } else if (percentage >= 90) {
        acc.advanced += 1;
      } else if (percentage >= 70) {
        acc.onTime += 1;
      } else {
        acc.delayed += 1;
      }
      
      return acc;
    },
    { advanced: 0, onTime: 0, delayed: 0, exceeding: 0 }
  );
  
  const statusPieData = [
    { name: "Avanzados", value: statusCounts.advanced, color: "#4CAF50" },
    { name: "En tiempo", value: statusCounts.onTime, color: "#FFC107" },
    { name: "Retrasados", value: statusCounts.delayed, color: "#F44336" },
    { name: "Superan 100%", value: statusCounts.exceeding, color: "#2196F3" }
  ];
  
  return (
    <div className="mb-6">
      <h2 className="text-xl font-bold font-roboto mb-4 dark:text-white">Visualizaciones Avanzadas</h2>
      
      {/* Tabs for different visualizations */}
      <div className="flex mb-4 border-b border-gray-200 dark:border-gray-700">
        <button 
          className={`py-2 px-4 font-medium text-sm ${
            activeTab === 'lines' 
              ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-600 dark:border-blue-400' 
              : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
          }`}
          onClick={() => setActiveTab('lines')}
        >
          Por Líneas Estratégicas
        </button>
        <button 
          className={`py-2 px-4 font-medium text-sm ${
            activeTab === 'programs' 
              ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-600 dark:border-blue-400' 
              : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
          }`}
          onClick={() => setActiveTab('programs')}
        >
          Por Programas
        </button>
        <button 
          className={`py-2 px-4 font-medium text-sm ${
            activeTab === 'yearly' 
              ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-600 dark:border-blue-400' 
              : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
          }`}
          onClick={() => setActiveTab('yearly')}
        >
          Progreso Anual
        </button>
      </div>
      
      {/* Content based on selected tab */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {activeTab === 'lines' && (
          <>
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
              <h3 className="text-lg font-medium mb-3 dark:text-white">Avance por Línea Estratégica</h3>
              <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                Porcentaje de avance promedio para cada línea estratégica en el período seleccionado.
              </div>
              <StrategicLineBarChart 
                data={strategicLineStats.map(stat => ({
                  name: stat.name,
                  percentage: stat.percentage
                }))} 
                height={300}
              />
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
              <h3 className="text-lg font-medium mb-3 dark:text-white">Distribución de Indicadores</h3>
              <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                Distribución por línea estratégica según el número de indicadores.
              </div>
              <SimplePieChart 
                data={strategicLineStats.map(stat => ({
                  name: stat.name,
                  value: stat.count,
                  color: getStrategicLineColor(stat.name)
                }))} 
                height={300}
              />
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
              <h3 className="text-lg font-medium mb-3 dark:text-white">Estado de Indicadores</h3>
              <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                Distribución por estado de avance actual.
              </div>
              <StatusPieChart 
                data={statusPieData} 
                height={300}
              />
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
              <h3 className="text-lg font-medium mb-3 dark:text-white">Indicadores por Línea</h3>
              <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                Cantidad de indicadores por línea estratégica.
              </div>
              <SimpleBarChart 
                data={strategicLineStats.map(stat => ({
                  name: stat.name,
                  value: stat.count,
                  color: getStrategicLineColor(stat.name)
                }))} 
                xAxisLabel="Línea Estratégica"
                yAxisLabel="Cantidad"
                height={300}
              />
            </div>
          </>
        )}
        
        {activeTab === 'programs' && (
          <>
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
              <h3 className="text-lg font-medium mb-3 dark:text-white">Avance por Programa</h3>
              <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                Porcentaje de avance promedio para los programas con mayor progreso.
              </div>
              <SimpleBarChart 
                data={programStatsArray.slice(0, 10).map(stat => ({
                  name: stat.name.length > 20 ? stat.name.substring(0, 20) + '...' : stat.name,
                  value: stat.percentage,
                  color: "#3B82F6"
                }))} 
                xAxisLabel="Programa"
                yAxisLabel="% Avance"
                height={300}
              />
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
              <h3 className="text-lg font-medium mb-3 dark:text-white">Programas con Mayor Rezago</h3>
              <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                Porcentaje de avance para los programas con menor progreso.
              </div>
              <SimpleBarChart 
                data={[...programStatsArray].reverse().slice(0, 10).map(stat => ({
                  name: stat.name.length > 20 ? stat.name.substring(0, 20) + '...' : stat.name,
                  value: stat.percentage,
                  color: "#EF4444"
                }))} 
                xAxisLabel="Programa"
                yAxisLabel="% Avance"
                height={300}
              />
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 col-span-1 lg:col-span-2">
              <h3 className="text-lg font-medium mb-3 dark:text-white">Tabla de Programas</h3>
              <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                Detalle de avance por programa ordenado por porcentaje.
              </div>
              <div className="overflow-auto max-h-96">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                  <thead className="bg-gray-50 dark:bg-gray-700">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Programa</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Indicadores</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Avance Promedio</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                    {programStatsArray.map(program => (
                      <tr key={program.name}>
                        <td className="px-4 py-2 text-sm text-gray-900 dark:text-gray-200">{program.name}</td>
                        <td className="px-4 py-2 text-sm text-gray-900 dark:text-gray-200">{programStats[program.name].count}</td>
                        <td className="px-4 py-2">
                          <div className="flex items-center">
                            <span className={`text-sm font-medium ${
                              program.percentage >= 90 ? 'text-green-600 dark:text-green-500' : 
                              program.percentage >= 70 ? 'text-amber-500 dark:text-amber-400' : 
                              'text-red-600 dark:text-red-400'
                            }`}>{formatNumberWithDecimals(program.percentage)}%</span>
                            <div className="ml-2 w-24 h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                              <div 
                                className={`h-full rounded-full ${
                                  program.percentage >= 90 ? 'bg-green-600 dark:bg-green-500' : 
                                  program.percentage >= 70 ? 'bg-amber-500 dark:bg-amber-400' : 
                                  'bg-red-600 dark:bg-red-400'
                                }`}
                                style={{ width: `${Math.min(program.percentage, 100)}%` }}
                              ></div>
                            </div>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
        
        {activeTab === 'yearly' && (
          <>
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 col-span-1 lg:col-span-2">
              <h3 className="text-lg font-medium mb-3 dark:text-white">Progreso a lo Largo del Cuatrienio</h3>
              <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                Evolución del avance general en cada año del periodo.
              </div>
              <YearlyProgressLineChart 
                data={yearlyProgress} 
                height={300}
              />
            </div>
            
            {strategicLineStats.map((line, index) => (
              <div key={line.name} className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
                <h3 className="text-lg font-medium mb-3 dark:text-white">Progreso Anual: {line.name}</h3>
                <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                  Evolución del avance en la línea estratégica.
                </div>
                <SimpleLineChart 
                  data={[
                    { name: "2024", actual: line.progress2024, target: line.target2024 },
                    { name: "2025", actual: line.progress2025, target: line.target2025 },
                    { name: "2026", actual: line.progress2026, target: line.target2026 },
                    { name: "2027", actual: line.progress2027, target: line.target2027 }
                  ]}
                  xAxisLabel="Año"
                  yAxisLabel="Avance %"
                  height={250}
                />
              </div>
            ))}
          </>
        )}
      </div>
    </div>
  );
};

export default AdvancedCharts;