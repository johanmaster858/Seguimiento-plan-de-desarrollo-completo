import React from 'react';
import { motion } from 'framer-motion';

interface AnimatedButtonProps {
  onClick: () => void;
  icon: string;
  text: string;
  className?: string;
}

const AnimatedButton: React.FC<AnimatedButtonProps> = ({ 
  onClick, 
  icon, 
  text, 
  className = "bg-green-50 text-green-700 border border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-800"
}) => {
  return (
    <motion.button
      onClick={onClick}
      className={`flex items-center space-x-2 px-4 py-2 rounded-md ${className} focus:outline-none`}
      whileHover={{ scale: 1.03 }}
      whileTap={{ scale: 0.97 }}
      transition={{ duration: 0.2 }}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <motion.span 
        className="material-icons text-sm"
        initial={{ rotate: 0 }}
        animate={{ rotate: [0, -10, 10, -10, 10, 0] }}
        transition={{ duration: 0.6, repeat: Infinity, repeatDelay: 3 }}
      >
        {icon}
      </motion.span>
      <span>{text}</span>
    </motion.button>
  );
};

export default AnimatedButton;