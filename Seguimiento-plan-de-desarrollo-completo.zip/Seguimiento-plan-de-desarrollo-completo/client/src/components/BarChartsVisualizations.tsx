import React, { useMemo, useState } from "react";
import { Indicator } from "@shared/schema";
import { SimpleBarChart } from "@/components/ui/chart";
import { getStrategicLineColor, getProgressPercentage, getStrategicLineClass } from "@/lib/utils";

interface BarChartsVisualizationsProps {
  indicators: Indicator[];
  year: string;
}

// Función para obtener indicadores con 0% de avance
function getZeroProgressIndicators(indicators: Indicator[], year: string): Indicator[] {
  return indicators.filter(indicator => {
    // Determinar el progreso y meta según el año
    let progress = 0;
    let target = 0;

    switch(year) {
      case "2024":
        progress = indicator.progress2024 || 0;
        target = indicator.target2024 || 0;
        break;
      case "2025":
        progress = indicator.progress2025 || 0;
        target = indicator.target2025 || 0;
        break;
      case "2026":
        progress = indicator.progress2026 || 0;
        target = indicator.target2026 || 0;
        break;
      case "2027":
        progress = indicator.progress2027 || 0;
        target = indicator.target2027 || 0;
        break;
      case "cuatrienio":
      default:
        progress = indicator.totalProgress || 0;
        target = indicator.totalTarget || 0;
        break;
    }

    // Retornar solo indicadores con meta > 0 y avance = 0
    return target > 0 && progress === 0;
  });
}

// Componente para mostrar indicadores con 0% de avance
const ZeroProgressIndicators: React.FC<{
  indicators: Indicator[];
  year: string;
}> = ({ indicators, year }) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [isExpanded, setIsExpanded] = useState(false);
  const itemsPerPage = 5;

  // Calcular índices para la página actual
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentIndicators = indicators.slice(startIndex, endIndex);

  if (indicators.length === 0) {
    return <p className="text-gray-500 dark:text-gray-400 text-center my-4">No se encontraron indicadores sin avance para este periodo.</p>;
  }

  return (
    <div>
      {/* Encabezado plegable */}
      <div 
        className="flex justify-between items-center p-2 bg-gray-100 dark:bg-gray-700 rounded-md cursor-pointer mb-2"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="font-medium flex items-center text-gray-700 dark:text-gray-100">
          <span className="material-icons text-sm mr-1">{isExpanded ? 'expand_more' : 'chevron_right'}</span>
          <span>{indicators.length} indicadores sin avance ({year === "cuatrienio" ? "Cuatrienio" : `Año ${year}`})</span>
        </div>
        <div className="text-sm text-gray-500 dark:text-gray-400">
          Haga clic para {isExpanded ? 'colapsar' : 'expandir'}
        </div>
      </div>

      {/* Contenido plegable */}
      {isExpanded && (
        <div className="overflow-x-auto mt-3">
          <table className="min-w-full bg-white dark:bg-gray-800 border-collapse">
            <thead>
              <tr className="bg-gray-100 dark:bg-gray-700">
                <th className="px-4 py-2 text-left text-xs uppercase font-medium text-gray-600 dark:text-gray-200">Código</th>
                <th className="px-4 py-2 text-left text-xs uppercase font-medium text-gray-600 dark:text-gray-200">Nombre</th>
                <th className="px-4 py-2 text-left text-xs uppercase font-medium text-gray-600 dark:text-gray-200">Línea Estratégica</th>
                <th className="px-4 py-2 text-left text-xs uppercase font-medium text-gray-600 dark:text-gray-200">Programa</th>
                <th className="px-4 py-2 text-left text-xs uppercase font-medium text-gray-600 dark:text-gray-200">Meta {year === "cuatrienio" ? "Total" : year}</th>
              </tr>
            </thead>
            <tbody>
              {currentIndicators.map((indicator) => {
                // Determinar la meta según el año
                let target = 0;
                switch(year) {
                  case "2024": target = indicator.target2024 || 0; break;
                  case "2025": target = indicator.target2025 || 0; break;
                  case "2026": target = indicator.target2026 || 0; break;
                  case "2027": target = indicator.target2027 || 0; break;
                  case "cuatrienio": default: target = indicator.totalTarget || 0; break;
                }

                const lineClass = getStrategicLineClass(indicator.strategicLine);

                return (
                  <tr key={indicator.code} className="border-t border-gray-200 dark:border-gray-700">
                    <td className="px-4 py-3 whitespace-nowrap">{indicator.code}</td>
                    <td className="px-4 py-3">{indicator.name}</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-full text-xs ${lineClass}`}>
                        {indicator.strategicLine.length > 20 
                          ? indicator.strategicLine.substring(0, 17) + '...' 
                          : indicator.strategicLine}
                      </span>
                    </td>
                    <td className="px-4 py-3">{indicator.program}</td>
                    <td className="px-4 py-3 whitespace-nowrap">{target} {indicator.unit}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {/* Paginación */}
          {indicators.length > itemsPerPage && (
            <div className="flex justify-between items-center mt-4 text-sm">
              <div>
                Mostrando {startIndex + 1}-{Math.min(endIndex, indicators.length)} de {indicators.length} indicadores sin avance
              </div>
              <div className="flex space-x-1">
                <button 
                  className="px-3 py-1 rounded border border-gray-300 text-sm disabled:opacity-50"
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage(currentPage - 1)}
                >
                  Anterior
                </button>
                <button 
                  className="px-3 py-1 rounded border border-gray-300 text-sm disabled:opacity-50"
                  disabled={endIndex >= indicators.length}
                  onClick={() => setCurrentPage(currentPage + 1)}
                >
                  Siguiente
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

// Componente para gráfica de barras horizontal
const HorizontalBarChart: React.FC<{
  data: Array<{
    name: string;
    value: number;
    color: string;
  }>;
  height?: number;
}> = ({ data, height = 400 }) => {
  // Formatear nombres largos
  const formattedData = data.map(item => ({
    ...item,
    displayName: item.name.length > 30 ? item.name.substring(0, 27) + '...' : item.name
  }));

  return (
    <div className="w-full" style={{ height }}>
      {formattedData.map((item, index) => (
        <div key={index} className="flex items-center mb-3">
          <div className="w-1/3 pr-4 text-sm">
            <div title={item.name}>{item.displayName}</div>
          </div>
          <div className="w-2/3 flex items-center">
            <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-4">
              <div 
                className="h-4 rounded-full" 
                style={{ 
                  width: `${Math.min(item.value, 100)}%`,
                  backgroundColor: item.color 
                }}
              ></div>
            </div>
            <div className="ml-2 text-sm font-medium">
              {item.value.toFixed(1)}%
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

const BarChartsVisualizations: React.FC<BarChartsVisualizationsProps> = ({
  indicators,
  year
}) => {
  // Skip if no indicators
  if (!indicators || indicators.length === 0) {
    return (
      <div className="mb-6">
        <h2 className="text-xl font-bold font-roboto mb-4 dark:text-white">Avances por línea y programa</h2>
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 text-center">
          <p className="text-gray-500 dark:text-gray-400">No hay indicadores disponibles para mostrar visualizaciones.</p>
        </div>
      </div>
    );
  }

  // Preparar datos para las gráficas de barras
  const { strategicLineData, programsData } = useMemo(() => {
    // 1. Avance por línea estratégica
    const lineStats = indicators.reduce((acc, indicator) => {
      const line = indicator.strategicLine;

      if (!acc[line]) {
        acc[line] = {
          name: line,
          totalValue: 0,
          count: 0
        };
      }

      // Obtener progreso para el año seleccionado
      let progress = 0;
      let target = 0;

      switch(year) {
        case "2024":
          progress = indicator.progress2024 || 0;
          target = indicator.target2024 || 0;
          break;
        case "2025":
          progress = indicator.progress2025 || 0;
          target = indicator.target2025 || 0;
          break;
        case "2026":
          progress = indicator.progress2026 || 0;
          target = indicator.target2026 || 0;
          break;
        case "2027":
          progress = indicator.progress2027 || 0;
          target = indicator.target2027 || 0;
          break;
        case "cuatrienio":
        default:
          progress = indicator.totalProgress || 0;
          target = indicator.totalTarget || 0;
          break;
      }

      // Calcular porcentaje y agregarlo al acumulador
      if (target > 0) {
        const percentage = getProgressPercentage(progress, target);
        acc[line].totalValue += percentage;
        acc[line].count += 1;
      }

      return acc;
    }, {} as Record<string, { name: string; totalValue: number; count: number }>);

    // Convertir a array y calcular promedio
    const strategicLineData = Object.values(lineStats).map(({ name, totalValue, count }) => ({
      name,
      value: count > 0 ? totalValue / count : 0,
      color: getStrategicLineColor(name)
    }));

    // 2. Avance por programa
    const programStats = indicators.reduce((acc, indicator) => {
      const program = indicator.program;

      if (!acc[program]) {
        acc[program] = {
          name: program,
          totalValue: 0,
          count: 0,
          strategicLine: indicator.strategicLine
        };
      }

      // Obtener progreso para el año seleccionado
      let progress = 0;
      let target = 0;

      switch(year) {
        case "2024":
          progress = indicator.progress2024 || 0;
          target = indicator.target2024 || 0;
          break;
        case "2025":
          progress = indicator.progress2025 || 0;
          target = indicator.target2025 || 0;
          break;
        case "2026":
          progress = indicator.progress2026 || 0;
          target = indicator.target2026 || 0;
          break;
        case "2027":
          progress = indicator.progress2027 || 0;
          target = indicator.target2027 || 0;
          break;
        case "cuatrienio":
        default:
          progress = indicator.totalProgress || 0;
          target = indicator.totalTarget || 0;
          break;
      }

      // Calcular porcentaje y agregarlo al acumulador
      if (target > 0) {
        const percentage = getProgressPercentage(progress, target);
        acc[program].totalValue += percentage;
        acc[program].count += 1;
      }

      return acc;
    }, {} as Record<string, { name: string; totalValue: number; count: number; strategicLine: string }>);

    // Convertir a array, calcular promedio y ordenar de mayor a menor
    const programsData = Object.values(programStats)
      .map(({ name, totalValue, count, strategicLine }) => ({
        name,
        value: count > 0 ? totalValue / count : 0,
        color: getStrategicLineColor(strategicLine)
      }))
      .sort((a, b) => b.value - a.value); // Ordenar de mayor a menor

    return { strategicLineData, programsData };
  }, [indicators, year]);

  return (
    <div className="mb-6 grid grid-cols-1 gap-6">
      {/* Gráfica de barras verticales - Avance por línea estratégica */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
        <h3 className="text-lg font-medium mb-3 dark:text-white">Avance Promedio por Línea Estratégica</h3>
        <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
          Porcentaje de avance promedio para cada línea estratégica en el periodo {year === "cuatrienio" ? "del cuatrienio" : year}.
        </div>
        <SimpleBarChart 
          data={strategicLineData}
          xAxisLabel="Línea Estratégica"
          yAxisLabel="Avance (%)"
          height={350}
        />
      </div>

      {/* Gráfica de barras horizontales - Programas por avance */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
        <h3 className="text-lg font-medium mb-3 dark:text-white">Programas por Avance</h3>
        <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
          Porcentaje de avance por programa ordenado de mayor a menor para el periodo {year === "cuatrienio" ? "del cuatrienio" : year}.
          Mostrando {programsData.length} programas.
        </div>
        <div className="overflow-y-auto max-h-[800px] pr-2">
          <HorizontalBarChart 
            data={programsData.map(stat => ({
              name: stat.name.length > 30 ? stat.name.substring(0, 27) + '...' : stat.name,
              value: stat.value,
              color: stat.color
            }))}
            height={Math.max(600, programsData.length * 40)}
          />
        </div>
      </div>

      {/* Nueva sección: Indicadores con 0% de avance */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
        <h3 className="text-lg font-medium mb-3 dark:text-white">Indicadores sin Avance (0%)</h3>
        <div className="text-sm text-gray-500 dark:text-gray-400 mb-4">
          Indicadores que no reportan avance para el periodo {year === "cuatrienio" ? "del cuatrienio" : year}.
        </div>
        <ZeroProgressIndicators 
          indicators={getZeroProgressIndicators(indicators, year)}
          year={year}
        />
      </div>
    </div>
  );
};

export default BarChartsVisualizations;