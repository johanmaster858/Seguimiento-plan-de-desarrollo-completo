
import React, { useMemo } from "react";
import { Indicator } from "@shared/schema";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, PieChart, Pie, Cell } from "recharts";
import { getStrategicLineColor } from "@/lib/utils";

interface BudgetAnalysisChartsProps {
  indicators: Indicator[];
  year: string;
}

const BudgetAnalysisCharts: React.FC<BudgetAnalysisChartsProps> = ({ indicators, year }) => {
  const budgetData = useMemo(() => {
    const linesBudget: Record<string, { initial: number; final: number }> = {};

    indicators.forEach(indicator => {
      if (!linesBudget[indicator.strategicLine]) {
        linesBudget[indicator.strategicLine] = { initial: 0, final: 0 };
      }

      let initial = 0;
      let final = 0;

      if (year === "cuatrienio") {
        initial = indicator.totalInitialBudget || 0;
        final = indicator.totalFinalBudget || 0;
      } else {
        const yearNum = parseInt(year);
        switch (yearNum) {
          case 2024:
            initial = indicator.initialBudget2024 || 0;
            final = indicator.finalBudget2024 || 0;
            break;
          case 2025:
            initial = indicator.initialBudget2025 || 0;
            final = indicator.finalBudget2025 || 0;
            break;
          case 2026:
            initial = indicator.initialBudget2026 || 0;
            final = indicator.finalBudget2026 || 0;
            break;
          case 2027:
            initial = indicator.initialBudget2027 || 0;
            final = indicator.finalBudget2027 || 0;
            break;
        }
      }

      linesBudget[indicator.strategicLine].initial += initial;
      linesBudget[indicator.strategicLine].final += final;
    });

    return Object.entries(linesBudget).map(([name, budget]) => ({
      name: name.length > 20 ? name.substring(0, 17) + "..." : name,
      fullName: name,
      initial: budget.initial,
      final: budget.final,
      color: getStrategicLineColor(name)
    }));
  }, [indicators, year]);

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white dark:bg-gray-800 p-3 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg">
          <p className="font-semibold text-gray-900 dark:text-white mb-2">{payload[0].payload.fullName}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} style={{ color: entry.color }} className="text-sm">
              {entry.name}: ${entry.value.toLocaleString()}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  const formatYAxis = (value: number) => {
    if (value >= 1000000000) return `$${(value / 1000000000).toFixed(1)}B`;
    if (value >= 1000000) return `$${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `$${(value / 1000).toFixed(0)}K`;
    return `$${value}`;
  };

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <h3 className="text-lg font-bold mb-4 text-gray-800 dark:text-white">
          Presupuesto por Línea Estratégica - {year === "cuatrienio" ? "Cuatrienio" : year}
        </h3>
        <ResponsiveContainer width="100%" height={400}>
          <BarChart data={budgetData} margin={{ top: 20, right: 30, left: 80, bottom: 80 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
            <XAxis 
              dataKey="name" 
              angle={-45}
              textAnchor="end"
              height={100}
              interval={0}
              tick={{ fontSize: 11, fill: "#6B7280" }}
            />
            <YAxis 
              tickFormatter={formatYAxis}
              tick={{ fontSize: 12, fill: "#6B7280" }}
              width={80}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend 
              wrapperStyle={{ paddingTop: "20px" }}
              iconType="rect"
            />
            <Bar dataKey="initial" name="Presupuesto Inicial" fill="#93C5FD" radius={[4, 4, 0, 0]} />
            <Bar dataKey="final" name="Presupuesto Final" fill="#3B82F6" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <h3 className="text-lg font-bold mb-4 text-gray-800 dark:text-white">
          Distribución Presupuesto Final
        </h3>
        <ResponsiveContainer width="100%" height={350}>
          <PieChart>
            <Pie
              data={budgetData}
              cx="50%"
              cy="50%"
              labelLine={true}
              label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(1)}%`}
              outerRadius={100}
              fill="#8884d8"
              dataKey="final"
            >
              {budgetData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip content={<CustomTooltip />} />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default BudgetAnalysisCharts;
