
import React, { useMemo, useState } from "react";
import { Indicator } from "@shared/schema";
import { formatNumberWithDecimals } from "@/lib/utils";
import { SimpleBarChart } from "@/components/ui/chart";

interface BudgetAnalysisViewProps {
  indicators: Indicator[];
}

const BudgetAnalysisView: React.FC<BudgetAnalysisViewProps> = ({ indicators }) => {
  const [selectedYear, setSelectedYear] = useState<string>("cuatrienio");

  const budgetData = useMemo(() => {
    if (!indicators || indicators.length === 0) {
      return {
        totalInitialBudget: 0,
        totalFinalBudget: 0,
        executionRate: 0,
        budgetByStrategicLine: [],
        budgetByProgram: [],
        budgetByYear: [],
        budgetByODS: [],
        budgetBySector: [],
        budgetByFinancingSource: []
      };
    }

    let totalInitial = 0;
    let totalFinal = 0;
    const linesBudget: Record<string, { initial: number; final: number }> = {};
    const programsBudget: Record<string, { initial: number; final: number }> = {};
    const odsBudget: Record<string, { initial: number; final: number }> = {};
    const sectorBudget: Record<string, { initial: number; final: number }> = {};
    const yearsBudget = [
      { year: "2024", initial: 0, final: 0 },
      { year: "2025", initial: 0, final: 0 },
      { year: "2026", initial: 0, final: 0 },
      { year: "2027", initial: 0, final: 0 }
    ];

    indicators.forEach(indicator => {
      // Calcular por año específico o cuatrienio
      let initialBudget = 0;
      let finalBudget = 0;

      if (selectedYear === "cuatrienio") {
        initialBudget = (indicator.initialBudget2024 || 0) + (indicator.initialBudget2025 || 0) + 
                      (indicator.initialBudget2026 || 0) + (indicator.initialBudget2027 || 0);
        finalBudget = indicator.totalFinalBudget || 0;
      } else {
        switch (selectedYear) {
          case "2024":
            initialBudget = indicator.initialBudget2024 || 0;
            finalBudget = indicator.finalBudget2024 || 0;
            break;
          case "2025":
            initialBudget = indicator.initialBudget2025 || 0;
            finalBudget = indicator.finalBudget2025 || 0;
            break;
          case "2026":
            initialBudget = indicator.initialBudget2026 || 0;
            finalBudget = indicator.finalBudget2026 || 0;
            break;
          case "2027":
            initialBudget = indicator.initialBudget2027 || 0;
            finalBudget = indicator.finalBudget2027 || 0;
            break;
        }
      }

      totalInitial += initialBudget;
      totalFinal += finalBudget;

      // Agrupar por línea estratégica
      if (!linesBudget[indicator.strategicLine]) {
        linesBudget[indicator.strategicLine] = { initial: 0, final: 0 };
      }
      linesBudget[indicator.strategicLine].initial += initialBudget;
      linesBudget[indicator.strategicLine].final += finalBudget;

      // Agrupar por programa
      if (!programsBudget[indicator.program]) {
        programsBudget[indicator.program] = { initial: 0, final: 0 };
      }
      programsBudget[indicator.program].initial += initialBudget;
      programsBudget[indicator.program].final += finalBudget;

      // Agrupar por ODS
      if (indicator.ods) {
        const odsKey = `ODS ${indicator.ods}`;
        if (!odsBudget[odsKey]) {
          odsBudget[odsKey] = { initial: 0, final: 0 };
        }
        odsBudget[odsKey].initial += initialBudget;
        odsBudget[odsKey].final += finalBudget;
      }

      // Agrupar por Sector
      if (indicator.sector) {
        if (!sectorBudget[indicator.sector]) {
          sectorBudget[indicator.sector] = { initial: 0, final: 0 };
        }
        sectorBudget[indicator.sector].initial += initialBudget;
        sectorBudget[indicator.sector].final += finalBudget;
      }

      // Presupuesto por año
      yearsBudget[0].initial += indicator.initialBudget2024 || 0;
      yearsBudget[0].final += indicator.finalBudget2024 || 0;
      yearsBudget[1].initial += indicator.initialBudget2025 || 0;
      yearsBudget[1].final += indicator.finalBudget2025 || 0;
      yearsBudget[2].initial += indicator.initialBudget2026 || 0;
      yearsBudget[2].final += indicator.finalBudget2026 || 0;
      yearsBudget[3].initial += indicator.initialBudget2027 || 0;
      yearsBudget[3].final += indicator.finalBudget2027 || 0;
    });

    // Convertir a arrays para gráficas
    const budgetByStrategicLine = Object.entries(linesBudget).map(([line, budget]) => ({
      name: line,
      initial: budget.initial,
      final: budget.final,
      execution: budget.initial > 0 ? (budget.final / budget.initial) * 100 : 0
    }));

    const budgetByProgram = Object.entries(programsBudget)
      .map(([program, budget]) => ({
        name: program,
        initial: budget.initial,
        final: budget.final,
        execution: budget.initial > 0 ? (budget.final / budget.initial) * 100 : 0
      }))
      .sort((a, b) => b.final - a.final)
      .slice(0, 10); // Top 10 programas

    const budgetByODS = Object.entries(odsBudget)
      .map(([ods, budget]) => ({
        name: ods,
        initial: budget.initial,
        final: budget.final,
        execution: budget.initial > 0 ? (budget.final / budget.initial) * 100 : 0
      }))
      .sort((a, b) => b.final - a.final);

    const budgetBySector = Object.entries(sectorBudget)
      .map(([sector, budget]) => ({
        name: sector,
        initial: budget.initial,
        final: budget.final,
        execution: budget.initial > 0 ? (budget.final / budget.initial) * 100 : 0
      }))
      .sort((a, b) => b.final - a.final);

    return {
      totalInitialBudget: totalInitial,
      totalFinalBudget: totalFinal,
      executionRate: totalInitial > 0 ? (totalFinal / totalInitial) * 100 : 0,
      budgetByStrategicLine,
      budgetByProgram,
      budgetByYear: yearsBudget,
      budgetByODS,
      budgetBySector,
      budgetByFinancingSource: [] // Se llenará cuando implementemos las fuentes de financiación
    };
  }, [indicators, selectedYear]);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white">
          Análisis Presupuestal
        </h2>
        <select
          value={selectedYear}
          onChange={(e) => setSelectedYear(e.target.value)}
          className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800 dark:text-white"
        >
          <option value="cuatrienio">Cuatrienio Completo</option>
          <option value="2024">2024</option>
          <option value="2025">2025</option>
          <option value="2026">2026</option>
          <option value="2027">2027</option>
        </select>
      </div>

      {/* Tarjetas de resumen */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-r from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 rounded-lg p-6">
          <h3 className="text-lg font-medium text-blue-800 dark:text-blue-200 mb-2">
            Presupuesto Inicial
          </h3>
          <p className="text-3xl font-bold text-blue-600 dark:text-blue-400">
            ${budgetData.totalInitialBudget.toLocaleString('es-CO')}
          </p>
        </div>
        
        <div className="bg-gradient-to-r from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20 rounded-lg p-6">
          <h3 className="text-lg font-medium text-green-800 dark:text-green-200 mb-2">
            Presupuesto Ejecutado
          </h3>
          <p className="text-3xl font-bold text-green-600 dark:text-green-400">
            ${budgetData.totalFinalBudget.toLocaleString('es-CO')}
          </p>
        </div>
        
        <div className="bg-gradient-to-r from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20 rounded-lg p-6">
          <h3 className="text-lg font-medium text-purple-800 dark:text-purple-200 mb-2">
            Tasa de Ejecución
          </h3>
          <p className="text-3xl font-bold text-purple-600 dark:text-purple-400">
            {formatNumberWithDecimals(budgetData.executionRate)}%
          </p>
        </div>
      </div>

      {/* Gráfica por línea estratégica */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <h3 className="text-xl font-bold mb-4 dark:text-white">
          Presupuesto por Línea Estratégica
        </h3>
        <SimpleBarChart
          data={budgetData.budgetByStrategicLine.map(item => ({
            name: item.name.length > 20 ? item.name.substring(0, 17) + '...' : item.name,
            value: item.final,
            color: '#3B82F6'
          }))}
          height={400}
          xAxisLabel="Línea Estratégica"
          yAxisLabel="Presupuesto Final"
        />
      </div>

      {/* Gráfica por programa (Top 10) */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <h3 className="text-xl font-bold mb-4 dark:text-white">
          Top 10 Programas por Presupuesto
        </h3>
        <SimpleBarChart
          data={budgetData.budgetByProgram.map(item => ({
            name: item.name.length > 25 ? item.name.substring(0, 22) + '...' : item.name,
            value: item.final,
            color: '#10B981'
          }))}
          height={500}
          xAxisLabel="Programa"
          yAxisLabel="Presupuesto Final"
        />
      </div>

      {/* Presupuesto por año */}
      {selectedYear === "cuatrienio" && (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <h3 className="text-xl font-bold mb-4 dark:text-white">
            Evolución Presupuestal por Año
          </h3>
          <SimpleBarChart
            data={budgetData.budgetByYear.map(item => ({
              name: item.year,
              value: item.final,
              color: '#8B5CF6'
            }))}
            height={350}
            xAxisLabel="Año"
            yAxisLabel="Presupuesto Ejecutado"
          />
        </div>
      )}

      {/* Análisis por ODS */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <h3 className="text-xl font-bold mb-4 dark:text-white">
          Presupuesto por Objetivos de Desarrollo Sostenible (ODS)
        </h3>
        <SimpleBarChart
          data={budgetData.budgetByODS.map(item => ({
            name: item.name,
            value: item.final,
            color: '#F59E0B'
          }))}
          height={400}
          xAxisLabel="ODS"
          yAxisLabel="Presupuesto Final"
        />
      </div>

      {/* Análisis por Sector */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <h3 className="text-xl font-bold mb-4 dark:text-white">
          Presupuesto por Sector
        </h3>
        <SimpleBarChart
          data={budgetData.budgetBySector.map(item => ({
            name: item.name,
            value: item.final,
            color: '#EF4444'
          }))}
          height={400}
          xAxisLabel="Sector"
          yAxisLabel="Presupuesto Final"
        />
      </div>

      {/* Análisis por Fuentes de Financiación */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <h3 className="text-xl font-bold mb-4 dark:text-white">
          Presupuesto por Fuente de Financiación
        </h3>
        <SimpleBarChart
          data={budgetData.budgetByFinancingSource.map(item => ({
            name: item.name,
            value: item.amount,
            color: '#06B6D4'
          }))}
          height={400}
          xAxisLabel="Fuente de Financiación"
          yAxisLabel="Monto Asignado"
        />
      </div>
    </div>
  );
};

export default BudgetAnalysisView;
