
import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { Indicator, FinancingSource } from '@shared/schema';

interface BudgetFinancingManagerProps {
  indicator: Indicator;
  year: string;
  budgetType: 'initial' | 'final';
  isVisible: boolean;
}

interface BudgetDistribution {
  financingSourceId: number;
  amount: number;
  percentage: number;
}

const BudgetFinancingManager: React.FC<BudgetFinancingManagerProps> = ({
  indicator,
  year,
  budgetType,
  isVisible
}) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [distributions, setDistributions] = useState<BudgetDistribution[]>([]);
  const [totalBudget, setTotalBudget] = useState(0);
  const [isEditing, setIsEditing] = useState(false);

  // Load financing sources
  const { data: financingSources = [] } = useQuery<FinancingSource[]>({
    queryKey: ['/api/financing-sources'],
  });

  // Load existing distribution
  const { data: existingDistribution = [] } = useQuery({
    queryKey: [`/api/indicators/${indicator.code}/budget-distribution`],
    enabled: isVisible
  });

  // Calculate total budget based on year and type
  useEffect(() => {
    if (!indicator) return;
    
    let budget = 0;
    if (year === 'cuatrienio') {
      budget = budgetType === 'initial' ? (indicator.totalInitialBudget || 0) : (indicator.totalFinalBudget || 0);
    } else {
      switch (year) {
        case '2024':
          budget = budgetType === 'initial' ? (indicator.initialBudget2024 || 0) : (indicator.finalBudget2024 || 0);
          break;
        case '2025':
          budget = budgetType === 'initial' ? (indicator.initialBudget2025 || 0) : (indicator.finalBudget2025 || 0);
          break;
        case '2026':
          budget = budgetType === 'initial' ? (indicator.initialBudget2026 || 0) : (indicator.finalBudget2026 || 0);
          break;
        case '2027':
          budget = budgetType === 'initial' ? (indicator.initialBudget2027 || 0) : (indicator.finalBudget2027 || 0);
          break;
        default:
          budget = 0;
      }
    }
    
    setTotalBudget(budget);
  }, [indicator, year, budgetType]);

  // Initialize distributions
  useEffect(() => {
    if (existingDistribution.length > 0) {
      const yearDistributions = existingDistribution.filter(
        (d: any) => d.year === year && d.budgetType === budgetType
      );
      setDistributions(yearDistributions.map((d: any) => ({
        financingSourceId: d.financingSourceId,
        amount: d.amount,
        percentage: d.percentage
      })));
    } else if (totalBudget > 0) {
      // Default: assign full budget to first financing source
      const defaultSource = financingSources.find(s => s.active);
      if (defaultSource) {
        setDistributions([{
          financingSourceId: defaultSource.id,
          amount: totalBudget,
          percentage: 100
        }]);
      }
    }
  }, [existingDistribution, totalBudget, financingSources, year, budgetType]);

  // Save distribution mutation
  const saveMutation = useMutation({
    mutationFn: async (distributionData: any) => {
      const response = await fetch(`/api/indicators/${indicator.code}/budget-distribution`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(distributionData)
      });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Error saving distribution');
      }
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Distribución guardada",
        description: "La distribución del presupuesto ha sido guardada correctamente.",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/indicators/${indicator.code}/budget-distribution`] });
      setIsEditing(false);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo guardar la distribución.",
        variant: "destructive",
      });
    }
  });

  const addDistribution = () => {
    const availableSources = financingSources.filter(s => 
      s.active && !distributions.some(d => d.financingSourceId === s.id)
    );
    
    if (availableSources.length > 0) {
      setDistributions([...distributions, {
        financingSourceId: availableSources[0].id,
        amount: 0,
        percentage: 0
      }]);
    }
  };

  const removeDistribution = (index: number) => {
    const newDistributions = distributions.filter((_, i) => i !== index);
    setDistributions(newDistributions);
    redistributeAmounts(newDistributions);
  };

  const updateDistribution = (index: number, field: 'amount' | 'percentage', value: number) => {
    const newDistributions = [...distributions];
    newDistributions[index][field] = value;
    
    if (field === 'amount') {
      newDistributions[index].percentage = totalBudget > 0 ? (value / totalBudget) * 100 : 0;
    } else {
      newDistributions[index].amount = (value / 100) * totalBudget;
    }
    
    setDistributions(newDistributions);
  };

  const redistributeAmounts = (newDistributions: BudgetDistribution[]) => {
    if (newDistributions.length === 0) return;
    
    const amountPerSource = totalBudget / newDistributions.length;
    const updated = newDistributions.map(d => ({
      ...d,
      amount: amountPerSource,
      percentage: 100 / newDistributions.length
    }));
    
    setDistributions(updated);
  };

  const handleSave = () => {
    const distributionData = {
      year,
      budgetType,
      distributions: distributions.filter(d => d.amount > 0),
      totalAmount: totalBudget
    };
    
    saveMutation.mutate(distributionData);
  };

  const totalAssigned = distributions.reduce((sum, d) => sum + d.amount, 0);
  const isBalanced = Math.abs(totalAssigned - totalBudget) < 0.01;

  if (!isVisible) return null;

  return (
    <div className="border rounded-lg p-4 bg-gray-50 dark:bg-gray-900">
      <h4 className="font-medium mb-3 text-gray-800 dark:text-gray-200">
        Distribución de Fuentes - {budgetType === 'initial' ? 'Inicial' : 'Final'} {year}
      </h4>
      
      <div className="mb-4">
        <div className="text-sm text-gray-600 dark:text-gray-400">
          Presupuesto Total: <span className="font-semibold">${totalBudget.toLocaleString()}</span>
        </div>
        <div className="text-sm text-gray-600 dark:text-gray-400">
          Total Asignado: <span className={`font-semibold ${isBalanced ? 'text-green-600' : 'text-red-600'}`}>
            ${totalAssigned.toLocaleString()}
          </span>
        </div>
      </div>

      <div className="space-y-3">
        {distributions.map((distribution, index) => {
          const source = financingSources.find(s => s.id === distribution.financingSourceId);
          return (
            <div key={index} className="flex items-center space-x-2 bg-white dark:bg-gray-800 p-3 rounded border">
              <select
                value={distribution.financingSourceId}
                onChange={(e) => {
                  const newDistributions = [...distributions];
                  newDistributions[index].financingSourceId = parseInt(e.target.value);
                  setDistributions(newDistributions);
                }}
                disabled={!isEditing}
                className="flex-1 rounded border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-sm disabled:bg-gray-100 disabled:cursor-not-allowed"
              >
                {financingSources.filter(s => s.active).map(source => (
                  <option key={source.id} value={source.id}>{source.name}</option>
                ))}
              </select>
              
              <input
                type="number"
                value={distribution.amount}
                onChange={(e) => updateDistribution(index, 'amount', parseFloat(e.target.value) || 0)}
                placeholder="Monto"
                disabled={!isEditing}
                className="w-24 rounded border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-sm disabled:bg-gray-100 disabled:cursor-not-allowed"
              />
              
              <input
                type="number"
                value={Math.round(distribution.percentage * 100) / 100}
                onChange={(e) => updateDistribution(index, 'percentage', parseFloat(e.target.value) || 0)}
                placeholder="%"
                disabled={!isEditing}
                className="w-16 rounded border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-sm disabled:bg-gray-100 disabled:cursor-not-allowed"
                max="100"
                min="0"
                step="0.01"
              />
              
              {isEditing && (
                <button
                  onClick={() => removeDistribution(index)}
                  className="text-red-600 hover:text-red-800 p-1"
                  disabled={distributions.length <= 1}
                >
                  <span className="material-icons text-sm">delete</span>
                </button>
              )}
            </div>
          );
        })}
      </div>

      <div className="flex justify-between mt-4">
        <div className="flex space-x-2">
          <button
            onClick={() => setIsEditing(!isEditing)}
            className="bg-gray-600 text-white px-3 py-2 rounded text-sm hover:bg-gray-700"
          >
            {isEditing ? 'Cancelar Edición' : 'Editar Distribución'}
          </button>
          
          {isEditing && (
            <button
              onClick={addDistribution}
              className="text-blue-600 hover:text-blue-800 text-sm flex items-center"
              disabled={distributions.length >= financingSources.filter(s => s.active).length}
            >
              <span className="material-icons text-sm mr-1">add</span>
              Agregar Fuente
            </button>
          )}
        </div>
        
        {isEditing && (
          <button
            onClick={handleSave}
            disabled={!isBalanced || saveMutation.isPending}
            className="bg-blue-600 text-white px-4 py-2 rounded text-sm hover:bg-blue-700 disabled:bg-gray-400"
          >
            {saveMutation.isPending ? 'Guardando...' : 'Guardar Distribución'}
          </button>
        )}
      </div>
      
      {!isBalanced && (
        <div className="mt-2 text-sm text-red-600">
          La suma de las fuentes no coincide con el presupuesto total
        </div>
      )}
    </div>
  );
};

export default BudgetFinancingManager;
