
import React, { useState } from "react";
import { Indicator } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";

interface CustomCSVExportProps {
  indicators: Indicator[];
  year: string;
}

const CustomCSVExport: React.FC<CustomCSVExportProps> = ({ indicators, year }) => {
  const { toast } = useToast();
  const [selectedColumns, setSelectedColumns] = useState<string[]>([
    "code",
    "name",
    "strategicLine",
    "program"
  ]);
  const [includeFinancingDetail, setIncludeFinancingDetail] = useState(false);

  const availableColumns = [
    { id: "code", label: "Código" },
    { id: "bpim", label: "BPIM" },
    { id: "responsible", label: "Responsable" },
    { id: "strategicLine", label: "Línea Estratégica" },
    { id: "program", label: "Programa" },
    { id: "sector", label: "Sector" },
    { id: "ods", label: "ODS" },
    { id: "name", label: "Nombre del Indicador" },
    { id: "description", label: "Descripción" },
    { id: "unit", label: "Unidad" },
    { id: "totalTarget", label: "Meta Total Cuatrienio" },
    { id: "totalProgress", label: "Avance Total Cuatrienio" },
    { id: "target2024", label: "Meta 2024" },
    { id: "progress2024", label: "Avance 2024" },
    { id: "target2025", label: "Meta 2025" },
    { id: "progress2025", label: "Avance 2025" },
    { id: "target2026", label: "Meta 2026" },
    { id: "progress2026", label: "Avance 2026" },
    { id: "target2027", label: "Meta 2027" },
    { id: "progress2027", label: "Avance 2027" },
    { id: "initialBudget2024", label: "Presupuesto Inicial 2024" },
    { id: "finalBudget2024", label: "Presupuesto Final 2024" },
    { id: "initialBudget2025", label: "Presupuesto Inicial 2025" },
    { id: "finalBudget2025", label: "Presupuesto Final 2025" },
    { id: "initialBudget2026", label: "Presupuesto Inicial 2026" },
    { id: "finalBudget2026", label: "Presupuesto Final 2026" },
    { id: "initialBudget2027", label: "Presupuesto Inicial 2027" },
    { id: "finalBudget2027", label: "Presupuesto Final 2027" },
    { id: "totalInitialBudget", label: "Presupuesto Inicial Total" },
    { id: "totalFinalBudget", label: "Presupuesto Final Total" }
  ];

  const toggleColumn = (columnId: string) => {
    if (selectedColumns.includes(columnId)) {
      setSelectedColumns(selectedColumns.filter(id => id !== columnId));
    } else {
      setSelectedColumns([...selectedColumns, columnId]);
    }
  };

  const selectAllColumns = () => {
    setSelectedColumns(availableColumns.map(col => col.id));
  };

  const deselectAllColumns = () => {
    setSelectedColumns([]);
  };

  const exportCSV = async () => {
    if (selectedColumns.length === 0) {
      toast({
        title: "Error",
        description: "Seleccione al menos una columna para exportar.",
        variant: "destructive",
      });
      return;
    }

    try {
      const response = await fetch("/api/export/custom-csv", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          indicators: indicators.map(ind => ind.code),
          columns: selectedColumns,
          includeFinancingDetail,
          year
        }),
      });

      if (!response.ok) {
        throw new Error("Error al generar el CSV");
      }

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.setAttribute("href", url);
      link.setAttribute("download", `reporte_personalizado_${new Date().toISOString().split('T')[0]}.csv`);
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      toast({
        title: "Exportación exitosa",
        description: "El archivo CSV se ha descargado correctamente.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo generar el archivo CSV.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
      <h3 className="text-lg font-bold mb-4 text-gray-800 dark:text-white flex items-center">
        <span className="material-icons mr-2 text-green-600">file_download</span>
        Exportación CSV Personalizada
      </h3>

      <div className="mb-4">
        <div className="flex gap-2 mb-3">
          <Button onClick={selectAllColumns} variant="outline" size="sm">
            Seleccionar Todo
          </Button>
          <Button onClick={deselectAllColumns} variant="outline" size="sm">
            Deseleccionar Todo
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-96 overflow-y-auto border border-gray-200 dark:border-gray-700 rounded-lg p-4">
          {availableColumns.map(column => (
            <div key={column.id} className="flex items-center space-x-2">
              <Checkbox
                id={column.id}
                checked={selectedColumns.includes(column.id)}
                onCheckedChange={() => toggleColumn(column.id)}
              />
              <label
                htmlFor={column.id}
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
              >
                {column.label}
              </label>
            </div>
          ))}
        </div>
      </div>

      <div className="mb-4 flex items-center space-x-2 p-3 bg-blue-50 dark:bg-blue-900 rounded-lg">
        <Checkbox
          id="financing-detail"
          checked={includeFinancingDetail}
          onCheckedChange={(checked) => setIncludeFinancingDetail(checked as boolean)}
        />
        <label
          htmlFor="financing-detail"
          className="text-sm font-medium cursor-pointer"
        >
          Incluir detalle de fuentes de financiación por indicador
        </label>
      </div>

      <div className="flex justify-between items-center">
        <p className="text-sm text-gray-600 dark:text-gray-400">
          {selectedColumns.length} columnas seleccionadas • {indicators.length} indicadores
        </p>
        <Button onClick={exportCSV} className="bg-green-600 hover:bg-green-700">
          <span className="material-icons mr-2 text-sm">download</span>
          Exportar CSV
        </Button>
      </div>
    </div>
  );
};

export default CustomCSVExport;
