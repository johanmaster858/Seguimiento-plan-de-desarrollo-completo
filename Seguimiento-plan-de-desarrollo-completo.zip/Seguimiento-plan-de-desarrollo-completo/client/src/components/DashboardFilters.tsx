import React, { useState, useEffect, useCallback, useMemo } from "react";
import { useSearch } from "wouter";
import { STRATEGIC_LINES, STATUS_COLORS } from "@/lib/utils";
import ExportPDFButton from "./ExportPDFButton";
import { Indicator } from "@shared/schema";
import { useIsMobile } from "@/hooks/use-mobile";

interface DashboardFiltersProps {
  onFilterChange: (filters: any) => void;
  responsibles: string[];
  programs: string[];
  indicators: Indicator[];
}

const DashboardFilters: React.FC<DashboardFiltersProps> = ({ 
  onFilterChange,
  responsibles,
  programs,
  indicators
}) => {
  const isMobile = useIsMobile();
  const searchString = useSearch();

  // Parse search parameters from URL
  const searchParams = useMemo(() => {
    return new URLSearchParams(searchString);
  }, [searchString]);

  // Navigate function from wouter (as replacement for setSearchParams)
  const navigate = useCallback((newSearch: string) => {
    const pathname = window.location.pathname;
    window.history.pushState(null, "", pathname + (newSearch ? `?${newSearch}` : ""));
  }, []);

  const [filters, setFilters] = useState({
    strategicLine: searchParams.get("strategicLine") || "",
    program: searchParams.get("program") || "",
    responsible: searchParams.get("responsible") || "",
    year: searchParams.get("year") || "cuatrienio",
    status: (searchParams.get("status") || "").split(",").filter(Boolean)
  });

  // Update URL when filters change
  useEffect(() => {
    const newParams = new URLSearchParams();

    if (filters.strategicLine) newParams.set("strategicLine", filters.strategicLine);
    if (filters.program) newParams.set("program", filters.program);
    if (filters.responsible) newParams.set("responsible", filters.responsible);
    if (filters.year) newParams.set("year", filters.year);
    if (filters.status.length > 0) newParams.set("status", filters.status.join(","));

    navigate(newParams.toString());
    onFilterChange(filters);
  }, [filters, navigate, onFilterChange]);

  const handleFilterChange = (field: string, value: string | string[]) => {
    setFilters(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleStatusChange = (status: string, checked: boolean) => {
    setFilters(prev => {
      if (checked) {
        return { ...prev, status: [...prev.status, status] };
      } else {
        return { ...prev, status: prev.status.filter((s: string) => s !== status) };
      }
    });
  };

  const resetFilters = () => {
    setFilters({
      strategicLine: "",
      program: "",
      responsible: "",
      year: "cuatrienio",
      status: []
    });
  };

  const uniqueResponsibles = useMemo(() => {
    if (!Array.isArray(indicators)) return [];
    return Array.from(new Set(indicators.map((i: any) => i.responsible)))
      .filter(Boolean)
      .sort() as string[];
  }, [indicators]);

  const uniquePrograms = useMemo(() => {
    if (!Array.isArray(indicators)) return [];
    return Array.from(new Set(indicators.map((i: any) => i.program)))
      .filter(Boolean)
      .sort() as string[];
  }, [indicators]);

  const uniqueSectors = useMemo(() => {
    if (!Array.isArray(indicators)) return [];
    return Array.from(new Set(indicators.map((i: any) => i.sector)))
      .filter(Boolean)
      .sort() as string[];
  }, [indicators]);

  const uniqueODS = useMemo(() => {
    if (!Array.isArray(indicators)) return [];
    return Array.from(new Set(indicators.map((i: any) => i.ods)))
      .filter((ods) => ods !== null && ods !== undefined)
      .sort((a, b) => a - b) as number[];
  }, [indicators]);

  const uniqueBPIM = useMemo(() => {
    if (!Array.isArray(indicators)) return [];
    return Array.from(new Set(indicators.map((i: any) => i.bpim)))
      .filter((bpim) => bpim !== null && bpim !== undefined && bpim !== '')
      .sort((a, b) => {
        // Sort as strings since BPIM can be very large numbers
        const strA = String(a);
        const strB = String(b);
        return strA.localeCompare(strB);
      }) as string[];
  }, [indicators]);

  const statusOptions = [
    { value: "avanzado", label: "Avanzados", color: "green" },
    { value: "en-tiempo", label: "En tiempo", color: "amber" },
    { value: "retrasado", label: "Retrasados", color: "red" }
  ];

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 mb-6">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-4">
        <h2 className="text-lg font-medium font-roboto mb-2 lg:mb-0 dark:text-white">Filtros de Búsqueda</h2>
        <div className="flex space-x-2">
          <button 
            className="text-sm bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-200 px-3 py-1.5 rounded-md hover:bg-blue-200 dark:hover:bg-blue-800 transition"
            onClick={() => onFilterChange(filters)}
          >
            Aplicar Filtros
          </button>
          <button 
            className="text-sm bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-200 px-3 py-1.5 rounded-md hover:bg-gray-200 dark:hover:bg-gray-600 transition"
            onClick={resetFilters}
          >
            Limpiar
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">Línea Estratégica</label>
          <select 
            className="w-full rounded-md border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-700 py-2 px-3 text-sm dark:text-white"
            value={filters.strategicLine}
            onChange={(e) => handleFilterChange("strategicLine", e.target.value)}
          >
            <option value="">Todas las líneas</option>
            {Object.entries(STRATEGIC_LINES).map(([line, { color }]) => (
              <option key={line} value={line} style={{ color }}>
                {line}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">Programa</label>
          <select 
            className="w-full rounded-md border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-700 py-2 px-3 text-sm dark:text-white"
            value={filters.program}
            onChange={(e) => handleFilterChange("program", e.target.value)}
          >
            <option value="">Todos los programas</option>
            {programs.map(program => (
              <option key={program} value={program}>
                {program}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">Responsable</label>
          <select 
            className="w-full rounded-md border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-700 py-2 px-3 text-sm dark:text-white"
            value={filters.responsible}
            onChange={(e) => handleFilterChange("responsible", e.target.value)}
          >
            <option value="">Todos los responsables</option>
            {responsibles.map(responsible => (
              <option key={responsible} value={responsible}>
                {responsible}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">Año</label>
          <select 
            className="w-full rounded-md border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-700 py-2 px-3 text-sm dark:text-white"
            value={filters.year}
            onChange={(e) => handleFilterChange("year", e.target.value)}
          >
            <option value="cuatrienio">Cuatrienio completo</option>
            <option value="2024">2024</option>
            <option value="2025">2025</option>
            <option value="2026">2026</option>
            <option value="2027">2027</option>
          </select>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Sector</label>
            <select
              value={filters.sector}
              onChange={(e) => handleFilterChange("sector", e.target.value)}
              className="w-full rounded-md border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-700 py-2 px-3 text-sm dark:text-white"
            >
              <option value="">Todos los sectores</option>
              {uniqueSectors.map(sector => (
                <option key={sector} value={sector}>{sector}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">ODS</label>
            <select
              value={filters.ods}
              onChange={(e) => handleFilterChange("ods", e.target.value)}
              className="w-full rounded-md border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-700 py-2 px-3 text-sm dark:text-white"
            >
              <option value="">Todos los ODS</option>
              {uniqueODS.map(ods => (
                <option key={ods} value={ods}>ODS {ods}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">BPIM</label>
            <select
              value={filters.bpim}
              onChange={(e) => handleFilterChange("bpim", e.target.value)}
              className="w-full rounded-md border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-700 py-2 px-3 text-sm dark:text-white"
            >
              <option value="">Todos los BPIM</option>
              {uniqueBPIM.map(bpim => (
                <option key={bpim} value={bpim}>{bpim}</option>
              ))}
            </select>
          </div>

        <div className="md:col-span-2 lg:col-span-1">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Estado de Cumplimiento</label>
          <div className="space-y-2">
            {statusOptions.map((option) => (
              <label key={option.value} className="flex items-center">
                <input
                  type="checkbox"
                  checked={filters.status.includes(option.value)}
                  onChange={(e) => handleStatusChange(option.value, e.target.checked)}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">{option.label}</span>
              </label>
            ))}
          </div>
        </div>
      </div>

      {isMobile && (
        <div className="mt-4">
          <ExportPDFButton 
            indicators={indicators} 
            year={filters.year} 
            filters={{
              strategicLine: filters.strategicLine,
              program: filters.program,
              responsible: filters.responsible,
              status: filters.status
            }} 
          />
        </div>
      )}
    </div>
  );
};

export default DashboardFilters;