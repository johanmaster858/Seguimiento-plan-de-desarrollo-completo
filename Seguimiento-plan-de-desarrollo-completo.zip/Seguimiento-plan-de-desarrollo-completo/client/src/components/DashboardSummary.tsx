import React, { useState } from "react";
import { Indicator } from "@shared/schema";
import { 
  calculateSummaryStats, 
  formatNumberWithDecimals, 
  getStrategicLineClass,
  getStrategicLineShortName,
  getProgressPercentage,
  getStrategicLineColor
} from "@/lib/utils";

// Función para obtener indicadores con 0% de avance
function getZeroProgressIndicators(indicators: Indicator[], year: string): Indicator[] {
  return indicators.filter(indicator => {
    // Determinar el progreso y meta según el año
    let progress = 0;
    let target = 0;
    
    switch(year) {
      case "2024":
        progress = indicator.progress2024 || 0;
        target = indicator.target2024 || 0;
        break;
      case "2025":
        progress = indicator.progress2025 || 0;
        target = indicator.target2025 || 0;
        break;
      case "2026":
        progress = indicator.progress2026 || 0;
        target = indicator.target2026 || 0;
        break;
      case "2027":
        progress = indicator.progress2027 || 0;
        target = indicator.target2027 || 0;
        break;
      case "cuatrienio":
      default:
        progress = (indicator.progress2024 || 0) + 
                   (indicator.progress2025 || 0) + 
                   (indicator.progress2026 || 0) + 
                   (indicator.progress2027 || 0);
        target = indicator.totalTarget || 0;
        break;
    }
    
    // Retornar solo indicadores con meta > 0 y avance = 0
    return target > 0 && progress === 0;
  });
}

interface DashboardSummaryProps {
  indicators: Indicator[];
  year: string;
  lastUpdated?: Date;
}

const DashboardSummary: React.FC<DashboardSummaryProps> = ({ 
  indicators,
  year,
  lastUpdated
}) => {
  const [showExceedingList, setShowExceedingList] = useState(false);
  const [showZeroProgressList, setShowZeroProgressList] = useState(false);
  
  // Skip if no indicators
  if (!indicators || indicators.length === 0) {
    return (
      <div className="text-center py-8">
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
          <svg className="w-16 h-16 mx-auto mb-4 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.08 16.5c-.77.833.192 2.5 1.732 2.5z" />
          </svg>
          <p className="text-gray-600 font-medium">No hay indicadores disponibles para mostrar el resumen.</p>
          <p className="text-sm text-gray-500 mt-2">Ajusta los filtros para ver más datos</p>
        </div>
      </div>
    );
  }
  
  // Calculate summary statistics
  const stats = calculateSummaryStats(indicators, year);
  const hasExceedingIndicators = stats.exceedingIndicators && stats.exceedingIndicators.length > 0;
  
  // Obtener indicadores con 0% de avance
  const zeroProgressIndicators = getZeroProgressIndicators(indicators, year);
  const hasZeroProgressIndicators = zeroProgressIndicators.length > 0;
  
  // Función auxiliar para obtener el progreso, meta y presupuesto según el año
  const getYearValues = (indicator: Indicator, year: string) => {
    switch(year) {
      case "2024":
        return { 
          progress: indicator.progress2024 || 0, 
          target: indicator.target2024 || 0,
          initialBudget: indicator.initialBudget2024 || 0,
          finalBudget: indicator.finalBudget2024 || 0
        };
      case "2025":
        return { 
          progress: indicator.progress2025 || 0, 
          target: indicator.target2025 || 0,
          initialBudget: indicator.initialBudget2025 || 0,
          finalBudget: indicator.finalBudget2025 || 0
        };
      case "2026":
        return { 
          progress: indicator.progress2026 || 0, 
          target: indicator.target2026 || 0,
          initialBudget: indicator.initialBudget2026 || 0,
          finalBudget: indicator.finalBudget2026 || 0
        };
      case "2027":
        return { 
          progress: indicator.progress2027 || 0, 
          target: indicator.target2027 || 0,
          initialBudget: indicator.initialBudget2027 || 0,
          finalBudget: indicator.finalBudget2027 || 0
        };
      case "cuatrienio":
      default:
        return { 
          progress: indicator.totalProgress || 0, 
          target: indicator.totalTarget || 0,
          initialBudget: (indicator.initialBudget2024 || 0) + (indicator.initialBudget2025 || 0) + (indicator.initialBudget2026 || 0) + (indicator.initialBudget2027 || 0),
          finalBudget: indicator.totalFinalBudget || ((indicator.finalBudget2024 || 0) + (indicator.finalBudget2025 || 0) + (indicator.finalBudget2026 || 0) + (indicator.finalBudget2027 || 0))
        };
    }
  };

  // Calculate investment summary by strategic line and program
  const calculateInvestmentSummary = () => {
    const byStrategicLine: Record<string, number> = {};
    const byProgram: Record<string, number> = {};

    indicators.forEach(indicator => {
      const { finalBudget } = getYearValues(indicator, year);
      
      // Sum by strategic line
      if (!byStrategicLine[indicator.strategicLine]) {
        byStrategicLine[indicator.strategicLine] = 0;
      }
      byStrategicLine[indicator.strategicLine] += finalBudget;

      // Sum by program
      if (!byProgram[indicator.program]) {
        byProgram[indicator.program] = 0;
      }
      byProgram[indicator.program] += finalBudget;
    });

    return { byStrategicLine, byProgram };
  };

  const investmentSummary = calculateInvestmentSummary();
  
  return (
    <div className="mb-6">
      <h2 className="text-xl font-bold font-roboto mb-4 dark:text-white">Resumen de Avance</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Summary Card 1 - Total Indicators */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400 font-medium">Indicadores Totales</p>
              <p className="text-2xl font-bold mt-1 dark:text-white">{stats.indicatorsCount}</p>
            </div>
            <span className="material-icons text-gray-400 dark:text-gray-500 bg-gray-100 dark:bg-gray-700 p-1.5 rounded-full">assignment</span>
          </div>
          <div className="mt-3 flex items-center text-xs text-gray-500 dark:text-gray-400">
            <span className="material-icons text-xs mr-1">info</span>
            Todos los indicadores del plan
          </div>
        </div>
        
        {/* Summary Card 2 - Average Progress */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400 font-medium">Avance Promedio</p>
              <p className="text-2xl font-bold mt-1 text-green-600 dark:text-green-500">
                {formatNumberWithDecimals(stats.averageProgress)}%
              </p>
            </div>
            <span className="material-icons text-green-600 dark:text-green-500 bg-green-100 dark:bg-green-900/30 p-1.5 rounded-full">trending_up</span>
          </div>
          <div className="mt-2">
            <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
              <div 
                className="h-full bg-green-600 dark:bg-green-500 rounded-full" 
                style={{ width: `${Math.min(stats.averageProgress, 100)}%` }}
              ></div>
            </div>
          </div>
          <div className="mt-2 flex items-center text-xs text-gray-500 dark:text-gray-400">
            <span className="material-icons text-xs mr-1">calendar_today</span>
            Actualizado: {lastUpdated ? new Date(lastUpdated).toLocaleDateString('es-CO') : 'Fecha no disponible'}
          </div>
        </div>
        
        {/* Summary Card 3 - Indicators Status */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400 font-medium">Estado de Indicadores</p>
              <div className="flex space-x-2 mt-2">
                <div className="text-center">
                  <p className="text-lg font-bold text-green-600 dark:text-green-500">{stats.advancedCount}</p>
                  <p className="text-xs dark:text-gray-300">Avanzados</p>
                </div>
                <div className="text-center">
                  <p className="text-lg font-bold text-amber-500 dark:text-amber-400">{stats.onTimeCount}</p>
                  <p className="text-xs dark:text-gray-300">En tiempo</p>
                </div>
                <div className="text-center">
                  <p className="text-lg font-bold text-red-600 dark:text-red-400">{stats.delayedCount}</p>
                  <p className="text-xs dark:text-gray-300">Retrasados</p>
                </div>
              </div>
            </div>
            <span className="material-icons text-blue-500 dark:text-blue-400 bg-blue-100 dark:bg-blue-900/30 p-1.5 rounded-full">donut_large</span>
          </div>
          <div className="mt-2 flex items-center text-xs text-gray-500 dark:text-gray-400">
            <span className="material-icons text-xs mr-1">info</span>
            Basado en metas del año {year}
          </div>
        </div>
        
        {/* Summary Card 4 - Line with Highest Progress */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-500 dark:text-gray-400 font-medium">Línea con Mayor Avance</p>
              <p className={`text-lg font-bold mt-1 ${getStrategicLineClass(stats.lineWithHighestProgress.name)}`}>
                {getStrategicLineShortName(stats.lineWithHighestProgress.name)}
              </p>
            </div>
            <span className={`material-icons ${getStrategicLineClass(stats.lineWithHighestProgress.name)} bg-yellow-100 dark:bg-yellow-900/30 p-1.5 rounded-full`}>star</span>
          </div>
          <div className="mt-2">
            <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
              <div 
                className="h-full rounded-full" 
                style={{ 
                  width: `${Math.min(stats.lineWithHighestProgress.percentage, 100)}%`,
                  backgroundColor: stats.lineWithHighestProgress.color
                }}
              ></div>
            </div>
          </div>
          <div className="mt-2 flex items-center text-xs text-gray-500 dark:text-gray-400">
            <span className="material-icons text-xs mr-1">speed</span>
            {formatNumberWithDecimals(stats.lineWithHighestProgress.percentage)}% de avance promedio
          </div>
        </div>
      </div>
      
      {/* Investment Summary Section - Moved here */}
      <div className="mb-6 bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <h3 className="text-lg font-semibold mb-4 dark:text-white flex items-center">
          <span className="material-icons text-green-600 mr-2">monetization_on</span>
          Resumen de Inversión
        </h3>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Investment by Strategic Line */}
          <div>
            <h4 className="font-medium mb-3 text-gray-700 dark:text-gray-300">Por Línea Estratégica</h4>
            <div className="space-y-2">
              {Object.entries(investmentSummary.byStrategicLine).map(([name, total], index) => (
                <div key={index} className="flex justify-between items-center p-2 bg-gray-50 dark:bg-gray-700 rounded">
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    {getStrategicLineShortName(name)}
                  </span>
                  <span className="text-sm font-mono text-green-600 dark:text-green-400">
                    ${total.toLocaleString('es-CO', { maximumFractionDigits: 0 })}
                  </span>
                </div>
              ))}
            </div>
          </div>
          
          {/* Investment by Program */}
          <div>
            <h4 className="font-medium mb-3 text-gray-700 dark:text-gray-300">Por Programa (Top 10)</h4>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {Object.entries(investmentSummary.byProgram)
                .sort(([,a], [,b]) => b - a)
                .slice(0, 10)
                .map(([name, total], index) => (
                <div key={index} className="flex justify-between items-center p-2 bg-gray-50 dark:bg-gray-700 rounded">
                  <span className="text-sm text-gray-700 dark:text-gray-300 truncate mr-2">
                    {name}
                  </span>
                  <span className="text-sm font-mono text-green-600 dark:text-green-400 whitespace-nowrap">
                    ${total.toLocaleString('es-CO', { maximumFractionDigits: 0 })}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-600">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="text-center">
              <div className="text-sm text-gray-600 dark:text-gray-400 mb-1">Total por Línea Estratégica</div>
              <div className="text-xl font-bold text-green-600">
                ${Object.values(investmentSummary.byStrategicLine).reduce((sum, total) => sum + total, 0).toLocaleString('es-CO', { maximumFractionDigits: 0 })}
              </div>
            </div>
            <div className="text-center">
              <div className="text-sm text-gray-600 dark:text-gray-400 mb-1">Total por Programa</div>
              <div className="text-xl font-bold text-blue-600">
                ${Object.values(investmentSummary.byProgram).reduce((sum, total) => sum + total, 0).toLocaleString('es-CO', { maximumFractionDigits: 0 })}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Indicadores que exceden el 100% */}
      {hasExceedingIndicators && (
        <div className="mt-6 bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center">
              <span className="material-icons text-blue-500 dark:text-blue-400 mr-2">trending_up</span>
              <h3 className="text-lg font-medium dark:text-white">
                Indicadores que exceden el 100% ({stats.exceedingIndicators.length})
              </h3>
            </div>
            <button 
              onClick={() => setShowExceedingList(!showExceedingList)}
              className="text-sm bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-200 px-3 py-1.5 rounded-md hover:bg-blue-200 dark:hover:bg-blue-800 transition"
            >
              {showExceedingList ? "Ocultar" : "Mostrar"}
            </button>
          </div>
          
          {showExceedingList && (
            <div className="overflow-auto max-h-64">
              <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead className="bg-gray-50 dark:bg-gray-700">
                  <tr>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Código</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Nombre</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Avance</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Meta</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Porcentaje</th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                  {stats.exceedingIndicators.map(indicator => {
                    const { progress, target } = getYearValues(indicator, year);
                    const percentage = getProgressPercentage(progress, target);
                    
                    return (
                      <tr key={indicator.code}>
                        <td className="px-4 py-2 text-sm text-gray-900 dark:text-gray-200">{indicator.code}</td>
                        <td className="px-4 py-2 text-sm text-gray-900 dark:text-gray-200">{indicator.name}</td>
                        <td className="px-4 py-2 text-sm text-gray-900 dark:text-gray-200">{formatNumberWithDecimals(progress)} {indicator.unit}</td>
                        <td className="px-4 py-2 text-sm text-gray-900 dark:text-gray-200">{formatNumberWithDecimals(target)} {indicator.unit}</td>
                        <td className="px-4 py-2 text-sm font-medium text-green-600 dark:text-green-500">{formatNumberWithDecimals(percentage)}%</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
      
      {/* Indicadores sin avance (0% de progreso) */}
      {hasZeroProgressIndicators && (
        <div className="mt-4 bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center">
              <span className="material-icons text-amber-500 dark:text-amber-400 mr-2">error_outline</span>
              <h3 className="text-lg font-medium dark:text-white">
                Indicadores sin avance ({zeroProgressIndicators.length})
              </h3>
            </div>
            <button 
              onClick={() => setShowZeroProgressList(!showZeroProgressList)}
              className="text-sm bg-amber-100 dark:bg-amber-900 text-amber-700 dark:text-amber-200 px-3 py-1.5 rounded-md hover:bg-amber-200 dark:hover:bg-amber-800 transition"
            >
              {showZeroProgressList ? "Ocultar" : "Mostrar"}
            </button>
          </div>
          
          {showZeroProgressList && (
            <div className="overflow-auto max-h-64">
              <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead className="bg-gray-50 dark:bg-gray-700">
                  <tr>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Código</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Nombre</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Meta</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Responsable</th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                  {zeroProgressIndicators.map(indicator => {
                    const { target } = getYearValues(indicator, year);
                    
                    return (
                      <tr key={indicator.code}>
                        <td className="px-4 py-2 text-sm text-gray-900 dark:text-gray-200">{indicator.code}</td>
                        <td className="px-4 py-2 text-sm text-gray-900 dark:text-gray-200">{indicator.name}</td>
                        <td className="px-4 py-2 text-sm text-gray-900 dark:text-gray-200">{formatNumberWithDecimals(target)} {indicator.unit}</td>
                        <td className="px-4 py-2 text-sm text-gray-900 dark:text-gray-200">{indicator.responsible}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default DashboardSummary;
