import React, { useRef } from 'react';
import { Indicator } from '@shared/schema';
import { formatNumberWithDecimals, getStatusForIndicator, getProgressPercentage } from '@/lib/utils';
import AnimatedButton from './AnimatedButton';
import html2canvas from 'html2canvas';

interface ExportPDFButtonProps {
  indicators: Indicator[];
  year: string;
  filters: {
    strategicLine?: string;
    program?: string;
    responsible?: string;
    status?: string[];
  };
}

const ExportPDFButton: React.FC<ExportPDFButtonProps> = ({ indicators, year, filters }) => {
  const formatDate = (date: Date): string => {
    return date.toLocaleDateString('es-CO', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  const handleExport = async () => {
    try {
      // Crear un elemento contenedor para nuestro informe
      const reportContainer = document.createElement('div');
      reportContainer.style.width = '900px';
      reportContainer.style.padding = '40px';
      reportContainer.style.backgroundColor = 'white';
      reportContainer.style.position = 'absolute';
      reportContainer.style.left = '-9999px';
      reportContainer.style.top = '0';
      document.body.appendChild(reportContainer);
      
      // Crear encabezado
      const header = document.createElement('div');
      header.style.textAlign = 'center';
      header.style.marginBottom = '20px';
      header.style.borderBottom = '2px solid #2E8B57';
      header.style.paddingBottom = '15px';
      
      const title = document.createElement('h1');
      title.style.color = '#2E8B57';
      title.style.fontSize = '24px';
      title.style.fontWeight = 'bold';
      title.style.marginBottom = '10px';
      title.textContent = 'Plan de Desarrollo San Jerónimo';
      
      const subtitle = document.createElement('h2');
      subtitle.style.color = '#444';
      subtitle.style.fontSize = '18px';
      subtitle.textContent = 'Informe de Indicadores';
      
      header.appendChild(title);
      header.appendChild(subtitle);
      reportContainer.appendChild(header);
      
      // Metadatos (año y fecha)
      const metaSection = document.createElement('div');
      metaSection.style.display = 'flex';
      metaSection.style.justifyContent = 'space-between';
      metaSection.style.marginBottom = '20px';
      
      const yearInfo = document.createElement('div');
      yearInfo.style.fontWeight = 'bold';
      yearInfo.style.fontSize = '16px';
      yearInfo.textContent = `Año: ${year === 'cuatrienio' ? 'Cuatrienio completo' : year}`;
      
      const dateInfo = document.createElement('div');
      dateInfo.style.fontSize = '14px';
      dateInfo.style.color = '#666';
      dateInfo.textContent = `Fecha de generación: ${formatDate(new Date())}`;
      
      metaSection.appendChild(yearInfo);
      metaSection.appendChild(dateInfo);
      reportContainer.appendChild(metaSection);
      
      // Filtros aplicados
      const filterInfo = document.createElement('div');
      filterInfo.style.fontSize = '14px';
      filterInfo.style.color = '#666';
      filterInfo.style.marginBottom = '20px';
      
      let filterText = "Filtros aplicados:";
      if (filters.strategicLine) filterText += ` | Línea estratégica: ${filters.strategicLine}`;
      if (filters.program) filterText += ` | Programa: ${filters.program}`;
      if (filters.responsible) filterText += ` | Responsable: ${filters.responsible}`;
      if (filters.status && filters.status.length > 0) filterText += ` | Estado: ${filters.status.join(', ')}`;
      
      filterInfo.textContent = filterText;
      reportContainer.appendChild(filterInfo);
      
      // Estadísticas
      const totalIndicators = indicators.length;
      let advancedCount = 0;
      let onTimeCount = 0;
      let delayedCount = 0;
      let totalProgress = 0;
      
      indicators.forEach(indicator => {
        let progress = 0;
        let target = 0;
        
        switch(year) {
          case "2024":
            progress = indicator.progress2024 || 0;
            target = indicator.target2024 || 0;
            break;
          case "2025":
            progress = indicator.progress2025 || 0;
            target = indicator.target2025 || 0;
            break;
          case "2026":
            progress = indicator.progress2026 || 0;
            target = indicator.target2026 || 0;
            break;
          case "2027":
            progress = indicator.progress2027 || 0;
            target = indicator.target2027 || 0;
            break;
          case "cuatrienio":
          default:
            progress = indicator.totalProgress || 0;
            target = indicator.totalTarget || 0;
            break;
        }
        
        const percentage = target > 0 ? (progress / target) * 100 : 0;
        totalProgress += percentage;
        
        const status = getStatusForIndicator(indicator, year);
        if (status === 'avanzado') advancedCount++;
        else if (status === 'en-tiempo') onTimeCount++;
        else delayedCount++;
      });
      
      const averageProgress = totalIndicators > 0 ? totalProgress / totalIndicators : 0;
      
      // Sección de resumen
      const summaryTitle = document.createElement('h3');
      summaryTitle.style.color = '#444';
      summaryTitle.style.fontSize = '18px';
      summaryTitle.style.marginBottom = '10px';
      summaryTitle.style.borderBottom = '1px solid #ddd';
      summaryTitle.style.paddingBottom = '5px';
      summaryTitle.textContent = 'Resumen del informe';
      reportContainer.appendChild(summaryTitle);
      
      // Tabla de resumen
      const summaryTable = document.createElement('table');
      summaryTable.style.width = '100%';
      summaryTable.style.borderCollapse = 'collapse';
      summaryTable.style.marginBottom = '30px';
      
      // Encabezado de la tabla
      const summaryTHead = document.createElement('thead');
      const summaryHeaderRow = document.createElement('tr');
      
      const metricHeader = document.createElement('th');
      metricHeader.style.backgroundColor = '#2E8B57';
      metricHeader.style.color = 'white';
      metricHeader.style.padding = '8px';
      metricHeader.style.textAlign = 'left';
      metricHeader.textContent = 'Métrica';
      
      const valueHeader = document.createElement('th');
      valueHeader.style.backgroundColor = '#2E8B57';
      valueHeader.style.color = 'white';
      valueHeader.style.padding = '8px';
      valueHeader.style.textAlign = 'right';
      valueHeader.textContent = 'Valor';
      
      summaryHeaderRow.appendChild(metricHeader);
      summaryHeaderRow.appendChild(valueHeader);
      summaryTHead.appendChild(summaryHeaderRow);
      summaryTable.appendChild(summaryTHead);
      
      // Cuerpo de la tabla
      const summaryTBody = document.createElement('tbody');
      
      // Filas de datos
      const createRow = (label: string, value: string, isEven: boolean) => {
        const row = document.createElement('tr');
        row.style.backgroundColor = isEven ? '#f2f2f2' : 'white';
        
        const labelCell = document.createElement('td');
        labelCell.style.padding = '8px';
        labelCell.style.borderBottom = '1px solid #ddd';
        labelCell.textContent = label;
        
        const valueCell = document.createElement('td');
        valueCell.style.padding = '8px';
        valueCell.style.borderBottom = '1px solid #ddd';
        valueCell.style.textAlign = 'right';
        valueCell.textContent = value;
        
        row.appendChild(labelCell);
        row.appendChild(valueCell);
        return row;
      };
      
      summaryTBody.appendChild(createRow('Total de indicadores', totalIndicators.toString(), true));
      summaryTBody.appendChild(createRow('Avance promedio', `${formatNumberWithDecimals(averageProgress)}%`, false));
      summaryTBody.appendChild(createRow('Indicadores avanzados', advancedCount.toString(), true));
      summaryTBody.appendChild(createRow('Indicadores en tiempo', onTimeCount.toString(), false));
      summaryTBody.appendChild(createRow('Indicadores retrasados', delayedCount.toString(), true));
      
      summaryTable.appendChild(summaryTBody);
      reportContainer.appendChild(summaryTable);
      
      // Listado de indicadores
      const listTitle = document.createElement('h3');
      listTitle.style.color = '#444';
      listTitle.style.fontSize = '18px';
      listTitle.style.marginBottom = '10px';
      listTitle.style.borderBottom = '1px solid #ddd';
      listTitle.style.paddingBottom = '5px';
      listTitle.textContent = 'Listado de Indicadores';
      reportContainer.appendChild(listTitle);
      
      // Tabla de indicadores
      const indicatorsTable = document.createElement('table');
      indicatorsTable.style.width = '100%';
      indicatorsTable.style.borderCollapse = 'collapse';
      indicatorsTable.style.fontSize = '12px';
      
      // Encabezado de la tabla
      const indicatorsTHead = document.createElement('thead');
      const indicatorsHeaderRow = document.createElement('tr');
      
      const headers = ['Código', 'Nombre', 'Programa', 'Responsable', 'Avance', 'Meta', 'Porcentaje', 'Estado'];
      headers.forEach(headerText => {
        const th = document.createElement('th');
        th.style.backgroundColor = '#2E8B57';
        th.style.color = 'white';
        th.style.padding = '8px';
        th.style.textAlign = headerText === 'Nombre' || headerText === 'Programa' || headerText === 'Responsable' ? 'left' : 'center';
        th.textContent = headerText;
        indicatorsHeaderRow.appendChild(th);
      });
      
      indicatorsTHead.appendChild(indicatorsHeaderRow);
      indicatorsTable.appendChild(indicatorsTHead);
      
      // Cuerpo de la tabla
      const indicatorsTBody = document.createElement('tbody');
      
      // Llenar tabla con indicadores
      indicators.forEach((indicator, index) => {
        let progress = 0;
        let target = 0;
        
        switch(year) {
          case "2024":
            progress = indicator.progress2024 || 0;
            target = indicator.target2024 || 0;
            break;
          case "2025":
            progress = indicator.progress2025 || 0;
            target = indicator.target2025 || 0;
            break;
          case "2026":
            progress = indicator.progress2026 || 0;
            target = indicator.target2026 || 0;
            break;
          case "2027":
            progress = indicator.progress2027 || 0;
            target = indicator.target2027 || 0;
            break;
          case "cuatrienio":
          default:
            progress = indicator.totalProgress || 0;
            target = indicator.totalTarget || 0;
            break;
        }
        
        const percentage = getProgressPercentage(progress, target);
        const status = getStatusForIndicator(indicator, year);
        const statusText = status === 'avanzado' ? 'Avanzado' : status === 'en-tiempo' ? 'En tiempo' : 'Retrasado';
        
        const row = document.createElement('tr');
        row.style.backgroundColor = index % 2 === 0 ? '#f2f2f2' : 'white';
        
        // Código
        const codeCell = document.createElement('td');
        codeCell.style.padding = '8px';
        codeCell.style.borderBottom = '1px solid #ddd';
        codeCell.textContent = indicator.code;
        row.appendChild(codeCell);
        
        // Nombre
        const nameCell = document.createElement('td');
        nameCell.style.padding = '8px';
        nameCell.style.borderBottom = '1px solid #ddd';
        nameCell.textContent = indicator.name;
        row.appendChild(nameCell);
        
        // Programa
        const programCell = document.createElement('td');
        programCell.style.padding = '8px';
        programCell.style.borderBottom = '1px solid #ddd';
        programCell.textContent = indicator.program;
        row.appendChild(programCell);
        
        // Responsable
        const responsibleCell = document.createElement('td');
        responsibleCell.style.padding = '8px';
        responsibleCell.style.borderBottom = '1px solid #ddd';
        responsibleCell.textContent = indicator.responsible;
        row.appendChild(responsibleCell);
        
        // Avance
        const progressCell = document.createElement('td');
        progressCell.style.padding = '8px';
        progressCell.style.borderBottom = '1px solid #ddd';
        progressCell.style.textAlign = 'center';
        progressCell.textContent = `${formatNumberWithDecimals(progress)} ${indicator.unit}`;
        row.appendChild(progressCell);
        
        // Meta
        const targetCell = document.createElement('td');
        targetCell.style.padding = '8px';
        targetCell.style.borderBottom = '1px solid #ddd';
        targetCell.style.textAlign = 'center';
        targetCell.textContent = `${formatNumberWithDecimals(target)} ${indicator.unit}`;
        row.appendChild(targetCell);
        
        // Porcentaje
        const percentageCell = document.createElement('td');
        percentageCell.style.padding = '8px';
        percentageCell.style.borderBottom = '1px solid #ddd';
        percentageCell.style.textAlign = 'center';
        percentageCell.textContent = `${formatNumberWithDecimals(percentage)}%`;
        row.appendChild(percentageCell);
        
        // Estado
        const statusCell = document.createElement('td');
        statusCell.style.padding = '8px';
        statusCell.style.borderBottom = '1px solid #ddd';
        statusCell.style.textAlign = 'center';
        statusCell.textContent = statusText;
        
        // Color de fondo según estado
        if (statusText === 'Avanzado') {
          statusCell.style.backgroundColor = '#E8F5E9';
          statusCell.style.color = '#4CAF50';
        } else if (statusText === 'En tiempo') {
          statusCell.style.backgroundColor = '#FFF8E1';
          statusCell.style.color = '#FFC107';
        } else {
          statusCell.style.backgroundColor = '#FFEBEE';
          statusCell.style.color = '#F44336';
        }
        
        row.appendChild(statusCell);
        indicatorsTBody.appendChild(row);
      });
      
      indicatorsTable.appendChild(indicatorsTBody);
      reportContainer.appendChild(indicatorsTable);
      
      // Footer
      const footer = document.createElement('div');
      footer.style.marginTop = '30px';
      footer.style.borderTop = '1px solid #ddd';
      footer.style.paddingTop = '10px';
      footer.style.fontSize = '12px';
      footer.style.color = '#888';
      footer.style.textAlign = 'center';
      footer.textContent = 'Elaborado por Johan Grisales';
      reportContainer.appendChild(footer);
      
      // Capturar el contenedor con HTML2Canvas
      const canvas = await html2canvas(reportContainer, {
        scale: 1.5, // Mayor calidad
        useCORS: true,
        logging: false,
        backgroundColor: 'white'
      });
      
      // Crear un enlace para descargar la imagen
      const link = document.createElement('a');
      link.download = `indicadores-san-jeronimo-${year}-${new Date().getTime()}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
      
      // Limpieza
      document.body.removeChild(reportContainer);
      
    } catch (error) {
      console.error('Error generando PDF:', error);
      let errorMsg = 'Ha ocurrido un error generando el informe PDF.';
      
      if (error instanceof Error) {
        console.error('Detalles del error:', error.message);
        errorMsg += ' Detalles: ' + error.message;
      }
      
      alert(errorMsg + ' Por favor, intente nuevamente.');
    }
  };
  
  return (
    <AnimatedButton 
      onClick={handleExport}
      icon="image"
      text="Exportar informe como imagen"
      className="bg-green-50 hover:bg-green-100 text-green-700 border border-green-200 hover:border-green-300 dark:bg-green-900/20 dark:hover:bg-green-900/30 dark:text-green-400 dark:border-green-800"
    />
  );
};

export default ExportPDFButton;