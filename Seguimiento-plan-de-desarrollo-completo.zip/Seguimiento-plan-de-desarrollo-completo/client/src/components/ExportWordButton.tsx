import React from "react";
import { Indicator } from "@shared/schema";
import {
  AlignmentType,
  Document,
  Packer,
  Paragraph,
  Table,
  TableCell,
  TableRow,
  HeadingLevel,
  BorderStyle,
  TextRun,
  WidthType,
  ImageRun,
  VerticalAlign,
  convertInchesToTwip, // MEJORA: Importado para manejar el tamaño de la imagen
} from "docx";
import { saveAs } from "file-saver";
import { Button } from "@/components/ui/button";
import { formatDate, formatNumberWithDecimals, getStatusForIndicator, getProgressPercentage } from "@/lib/utils";
import logo from "@assets/logo san jeronimo.jpeg"; // Asegúrate de que esta ruta sea correcta

interface ExportWordButtonProps {
  indicators: Indicator[];
  year: string;
  filters: {
    strategicLine?: string;
    program?: string;
    responsible?: string;
    status?: string[];
  };
}

// MEJORA: Función auxiliar para obtener el progreso y la meta según el año, eliminando la duplicación de código.
const getYearlyData = (indicator: Indicator, year: string) => {
  switch (year) {
    case '2024':
      return { 
        progress: indicator.progress2024 || 0, 
        target: indicator.target2024 || 0,
        initialBudget: indicator.initialBudget2024 || 0,
        finalBudget: indicator.finalBudget2024 || 0
      };
    case '2025':
      return { 
        progress: indicator.progress2025 || 0, 
        target: indicator.target2025 || 0,
        initialBudget: indicator.initialBudget2025 || 0,
        finalBudget: indicator.finalBudget2025 || 0
      };
    case '2026':
      return { 
        progress: indicator.progress2026 || 0, 
        target: indicator.target2026 || 0,
        initialBudget: indicator.initialBudget2026 || 0,
        finalBudget: indicator.finalBudget2026 || 0
      };
    case '2027':
      return { 
        progress: indicator.progress2027 || 0, 
        target: indicator.target2027 || 0,
        initialBudget: indicator.initialBudget2027 || 0,
        finalBudget: indicator.finalBudget2027 || 0
      };
    case 'cuatrienio':
      return { 
        progress: indicator.totalProgress || 0, 
        target: indicator.totalTarget || 0,
        initialBudget: (indicator.initialBudget2024 || 0) + (indicator.initialBudget2025 || 0) + 
                      (indicator.initialBudget2026 || 0) + (indicator.initialBudget2027 || 0),
        finalBudget: indicator.totalFinalBudget || 0
      };
    default:
      return { progress: 0, target: 0, initialBudget: 0, finalBudget: 0 };
  }
};

// MEJORA: Función para cargar la imagen como un buffer, necesario para docx.
const getImageBuffer = async (url: string) => {
  const response = await fetch(url);
  const buffer = await response.arrayBuffer();
  return buffer;
};


const ExportWordButton: React.FC<ExportWordButtonProps> = ({
  indicators,
  year,
  filters
}) => {
  const getFilteredIndicators = () => {
    return indicators.filter(indicator => {
      if (filters.strategicLine && indicator.strategicLine !== filters.strategicLine) return false;
      if (filters.program && indicator.program !== filters.program) return false;
      if (filters.responsible && indicator.responsible !== filters.responsible) return false;
      if (filters.status && filters.status.length > 0) {
        const status = getStatusForIndicator(indicator, year);
        if (!filters.status.includes(status)) return false;
      }
      return true;
    });
  };

  const exportToWord = async () => {
    try {
      console.log('Iniciando exportación a Word...');
      const filteredIndicators = getFilteredIndicators();

      if (filteredIndicators.length === 0) {
        alert("No hay indicadores que cumplan con los filtros seleccionados.");
        return;
      }

      // MEJORA: Cargamos el logo para usarlo en el encabezado
      const logoBuffer = await getImageBuffer(logo);

      // MEJORA: Se usa la función auxiliar getYearlyData para simplificar el código.
      const countIndicatorsOver100 = filteredIndicators.filter(indicator => {
        const { progress, target } = getYearlyData(indicator, year);
        return target > 0 && (progress / target) > 1;
      }).length;

      const countIndicatorsWithZeroProgress = filteredIndicators.filter(indicator => {
        const { progress } = getYearlyData(indicator, year);
        return progress === 0;
      }).length;

      // MEJORA: Párrafos de filtros creados de forma más limpia.
      const filterParagraphs = [
        filters.strategicLine && new Paragraph({ text: `Línea estratégica: ${filters.strategicLine}` }),
        filters.program && new Paragraph({ text: `Programa: ${filters.program}` }),
        filters.responsible && new Paragraph({ text: `Responsable: ${filters.responsible}` }),
        filters.status && filters.status.length > 0 && new Paragraph({ text: `Estados: ${filters.status.join(", ")}` }),
      ].filter(Boolean) as Paragraph[]; // Filtra los elementos nulos/falsos

      const doc = new Document({
        // MEJORA: Estilos ajustados para mejor legibilidad y optimización de espacio.
        styles: {
          paragraphStyles: [
            {
              id: "headerTitle",
              name: "Header Title",
              run: { size: 28, bold: true, color: "1E472B" }, // Verde oscuro corporativo
              paragraph: { alignment: AlignmentType.RIGHT, spacing: { after: 100 } },
            },
            {
              id: "headerSubtitle",
              name: "Header Subtitle",
              run: { size: 24, color: "333333" },
              paragraph: { alignment: AlignmentType.RIGHT },
            },
            {
              id: "mainTitle",
              name: "Main Title",
              basedOn: "Heading1",
              run: { size: 32, bold: true, color: "1E472B" },
              paragraph: { alignment: AlignmentType.CENTER, spacing: { before: 400, after: 300 } },
            },
            {
              id: "h1",
              name: "Heading 1",
              basedOn: "Heading1",
              run: { size: 28, bold: true, color: "2E74B5" }, // Azul corporativo
              paragraph: { spacing: { before: 300, after: 150 } },
            },
          ],
        },
        sections: [
          {
            properties: {},
            children: [
              // MEJORA: Encabezado profesional con logo y título usando una tabla sin bordes.
              new Table({
                width: { size: 100, type: WidthType.PERCENTAGE },
                borders: { top: { style: BorderStyle.NONE }, bottom: { style: BorderStyle.NONE }, left: { style: BorderStyle.NONE }, right: { style: BorderStyle.NONE }, insideHorizontal: { style: BorderStyle.NONE }, insideVertical: { style: BorderStyle.NONE } },
                rows: [
                  new TableRow({
                    children: [
                      new TableCell({
                        children: [new Paragraph({
                          children: [new ImageRun({
                            data: logoBuffer,
                            transformation: {
                              width: 100,
                              height: 100,
                            },
                          })],
                        })],
                        width: { size: 20, type: WidthType.PERCENTAGE },
                        verticalAlign: VerticalAlign.CENTER,
                      }),
                      new TableCell({
                        children: [
                          new Paragraph({ style: "headerTitle", text: "ALCALDÍA DE SAN JERÓNIMO" }),
                          new Paragraph({ style: "headerSubtitle", text: "INFORME DE PLAN DE DESARROLLO" }),
                          new Paragraph({ style: "headerSubtitle", text: `AÑO ${year}` }),
                        ],
                        verticalAlign: VerticalAlign.CENTER,
                      }),
                    ],
                  }),
                ],
              }),

              new Paragraph({ text: "", spacing: { after: 400 } }), // Espacio

              new Paragraph({ heading: HeadingLevel.HEADING_1, style: "h1", text: "Filtros Aplicados" }),
              new Paragraph({ text: `Fecha del informe: ${formatDate(new Date())}` }),
              ...filterParagraphs, // MEJORA: Inserción limpia de los párrafos de filtro.

              new Paragraph({ text: "", spacing: { after: 200 } }), // Espacio

              new Paragraph({ heading: HeadingLevel.HEADING_1, style: "h1", text: "Resumen General" }),
              new Paragraph({ text: `Total de indicadores evaluados: ${filteredIndicators.length}` }),
              new Paragraph({ children: [ new TextRun({ text: `Indicadores que superan el 100%: ${countIndicatorsOver100}`, bold: true, color: "008000" }) ]}),
              new Paragraph({ children: [ new TextRun({ text: `Indicadores sin avance (0%): ${countIndicatorsWithZeroProgress}`, bold: true, color: "FF0000" }) ]}),

              new Paragraph({ text: "", spacing: { after: 400 } }), // Espacio

              new Paragraph({ heading: HeadingLevel.HEADING_1, style: "h1", text: "Resumen por Línea Estratégica" }),
              createStrategicLinesTable(filteredIndicators, year),

              new Paragraph({ text: "", spacing: { after: 400 } }), // Espacio

              new Paragraph({ heading: HeadingLevel.HEADING_1, style: "h1", text: "Detalle de Indicadores" }),
              createIndicatorsTable(filteredIndicators, year),
            ],
          },
        ],
      });

      Packer.toBlob(doc).then(blob => {
        let fileName = `informe_pdm_sanjeronimo_${year}`;
        if (filters.strategicLine) fileName += `_${filters.strategicLine.substring(0, 10).replace(/\s/g, "_")}`;
        if (filters.program) fileName += `_${filters.program.substring(0, 10).replace(/\s/g, "_")}`;
        saveAs(blob, `${fileName}.docx`);
      });
    } catch (error) {
      console.error("Error al exportar a Word:", error);
      console.error("Stack trace:", error instanceof Error ? error.stack : 'No stack trace available');
      alert(`Ocurrió un error al generar el archivo Word: ${error instanceof Error ? error.message : 'Error desconocido'}`);
    }
  };

  const createStrategicLinesTable = (indicators: Indicator[], year: string) => {
    const lineGroups = indicators.reduce((groups, indicator) => {
      const line = indicator.strategicLine;
      if (!groups[line]) groups[line] = [];
      groups[line].push(indicator);
      return groups;
    }, {} as Record<string, Indicator[]>);

    const lineStats = Object.entries(lineGroups).map(([line, inds]) => {
      const yearlyData = inds.map(ind => getYearlyData(ind, year));
      const totalProgress = yearlyData.reduce((sum, data) => sum + data.progress, 0);
      const totalTarget = yearlyData.reduce((sum, data) => sum + data.target, 0);
      const averagePercentage = totalTarget > 0 ? (totalProgress / totalTarget) * 100 : 0;

      return { line, count: inds.length, progress: totalProgress, target: totalTarget, percentage: averagePercentage };
    });

    const header = new TableRow({
      tableHeader: true,
      children: [
        new TableCell({ children: [new Paragraph("Línea Estratégica")], shading: { fill: "D9E2F3" } }),
        new TableCell({ children: [new Paragraph({ text: "Indicadores", alignment: AlignmentType.CENTER })], shading: { fill: "D9E2F3" } }),
        new TableCell({ children: [new Paragraph({ text: "Avance", alignment: AlignmentType.CENTER })], shading: { fill: "D9E2F3" } }),
        new TableCell({ children: [new Paragraph({ text: "Meta", alignment: AlignmentType.CENTER })], shading: { fill: "D9E2F3" } }),
        new TableCell({ children: [new Paragraph({ text: "% Cumplimiento", alignment: AlignmentType.CENTER })], shading: { fill: "D9E2F3" } }),
      ],
    });

    const rows = lineStats.map(stat => new TableRow({
      children: [
        new TableCell({ children: [new Paragraph(stat.line)], verticalAlign: VerticalAlign.CENTER }),
        new TableCell({ children: [new Paragraph({ text: stat.count.toString(), alignment: AlignmentType.CENTER })], verticalAlign: VerticalAlign.CENTER }),
        new TableCell({ children: [new Paragraph({ text: formatNumberWithDecimals(stat.progress), alignment: AlignmentType.RIGHT })], verticalAlign: VerticalAlign.CENTER }),
        new TableCell({ children: [new Paragraph({ text: formatNumberWithDecimals(stat.target), alignment: AlignmentType.RIGHT })], verticalAlign: VerticalAlign.CENTER }),
        new TableCell({ children: [new Paragraph({ text: `${formatNumberWithDecimals(stat.percentage)}%`, alignment: AlignmentType.RIGHT })], verticalAlign: VerticalAlign.CENTER }),
      ],
    }));

    return new Table({
      width: { size: 100, type: WidthType.PERCENTAGE },
      // MEJORA: Anchos de columna optimizados para el espacio.
      columnWidths: [convertInchesToTwip(3.5), convertInchesToTwip(1), convertInchesToTwip(1), convertInchesToTwip(1), convertInchesToTwip(1.2)],
      rows: [header, ...rows],
    });
  };

  const createIndicatorsTable = (indicators: Indicator[], year: string) => {
    const header = new TableRow({
      tableHeader: true,
      children: [
        new TableCell({ children: [new Paragraph("Código")], shading: { fill: "D9E2F3" } }),
        new TableCell({ children: [new Paragraph("Indicador")], shading: { fill: "D9E2F3" } }),
        new TableCell({ children: [new Paragraph("Programa")], shading: { fill: "D9E2F3" } }),
        new TableCell({ children: [new Paragraph("Responsable")], shading: { fill: "D9E2F3" } }),
        new TableCell({ children: [new Paragraph("Meta")], shading: { fill: "D9E2F3" } }),
        new TableCell({ children: [new Paragraph("Avance")], shading: { fill: "D9E2F3" } }),
        new TableCell({ children: [new Paragraph("%")], shading: { fill: "D9E2F3" } }),
        new TableCell({ children: [new Paragraph("Presup. Inicial")], shading: { fill: "D9E2F3" } }),
        new TableCell({ children: [new Paragraph("Presup. Final")], shading: { fill: "D9E2F3" } }),
        new TableCell({ children: [new Paragraph("Estado")], shading: { fill: "D9E2F3" } }),
      ],
    });

    const rows = indicators.map(indicator => {
      const { target, progress, initialBudget, finalBudget } = getYearlyData(indicator, year);
      const percentage = getProgressPercentage(progress, target);
      const status = getStatusForIndicator(indicator, year);

      // Determinar el color del porcentaje basado en el valor
      let percentageColor = "000000"; // Negro por defecto
      if (percentage >= 100) {
        percentageColor = "008000"; // Verde para indicadores >= 100%
      } else if (percentage === 0) {
        percentageColor = "FF0000"; // Rojo para indicadores con 0%
      }

      return new TableRow({
        children: [
          new TableCell({ children: [new Paragraph(indicator.code)], verticalAlign: VerticalAlign.CENTER }),
          new TableCell({ children: [new Paragraph(indicator.name)], verticalAlign: VerticalAlign.CENTER }),
          new TableCell({ children: [new Paragraph(indicator.program)], verticalAlign: VerticalAlign.CENTER }),
          new TableCell({ children: [new Paragraph(indicator.responsible)], verticalAlign: VerticalAlign.CENTER }),
          new TableCell({ children: [new Paragraph({ text: `${formatNumberWithDecimals(target)} ${indicator.unit}`, alignment: AlignmentType.RIGHT })], verticalAlign: VerticalAlign.CENTER }),
          new TableCell({ children: [new Paragraph({ text: `${formatNumberWithDecimals(progress)} ${indicator.unit}`, alignment: AlignmentType.RIGHT })], verticalAlign: VerticalAlign.CENTER }),
          new TableCell({ 
            children: [new Paragraph({ 
              children: [new TextRun({ 
                text: `${formatNumberWithDecimals(percentage)}%`, 
                color: percentageColor,
                bold: percentage >= 100 || percentage === 0
              })],
              alignment: AlignmentType.RIGHT 
            })], 
            verticalAlign: VerticalAlign.CENTER 
          }),
          new TableCell({ children: [new Paragraph({ text: initialBudget > 0 ? `$${initialBudget.toLocaleString('es-CO', { maximumFractionDigits: 0 })}` : "N/A", alignment: AlignmentType.RIGHT })], verticalAlign: VerticalAlign.CENTER }),
          new TableCell({ children: [new Paragraph({ text: finalBudget > 0 ? `$${finalBudget.toLocaleString('es-CO', { maximumFractionDigits: 0 })}` : "N/A", alignment: AlignmentType.RIGHT })], verticalAlign: VerticalAlign.CENTER }),
          new TableCell({ children: [new Paragraph({ text: status === "avanzado" ? "Avanzado" : status === "en-tiempo" ? "En Tiempo" : "Retrasado", alignment: AlignmentType.CENTER })], verticalAlign: VerticalAlign.CENTER }),
        ],
      });
    });

    return new Table({
      width: { size: 100, type: WidthType.PERCENTAGE },
      // MEJORA: Anchos de columna optimizados para distribuir mejor el espacio incluyendo presupuestos.
      columnWidths: [
        convertInchesToTwip(0.6), // Código
        convertInchesToTwip(2.2), // Indicador
        convertInchesToTwip(1.2), // Programa
        convertInchesToTwip(1.2), // Responsable
        convertInchesToTwip(0.7), // Meta
        convertInchesToTwip(0.7), // Avance
        convertInchesToTwip(0.5), // %
        convertInchesToTwip(0.9), // Presup. Inicial
        convertInchesToTwip(0.9), // Presup. Final
        convertInchesToTwip(0.7), // Estado
      ],
      rows: [header, ...rows],
    });
  };

  return (
    <Button
      onClick={exportToWord}
      className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded flex items-center"
    >
      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd"/>
      </svg>
      Exportar a Word
    </Button>
  );
};

export default ExportWordButton;