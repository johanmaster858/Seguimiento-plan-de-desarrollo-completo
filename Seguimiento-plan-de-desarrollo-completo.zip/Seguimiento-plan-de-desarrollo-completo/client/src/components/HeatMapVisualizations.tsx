import React, { useMemo } from "react";
import { Indicator } from "@shared/schema";
import { getStrategicLineColor, getStrategicLineShortName } from "@/lib/utils";
import { motion } from "framer-motion";

interface HeatMapVisualizationsProps {
  indicators: Indicator[];
  year: string;
}

const HeatMapVisualizations: React.FC<HeatMapVisualizationsProps> = ({
  indicators,
  year
}) => {
  // Skip if no indicators
  if (!indicators || indicators.length === 0) {
    return (
      <div className="mb-6">
        <h2 className="text-xl font-bold font-roboto mb-4 dark:text-white">Avances PDD por programa</h2>
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 text-center">
          <p className="text-gray-500 dark:text-gray-400">No hay indicadores disponibles para mostrar visualizaciones.</p>
        </div>
      </div>
    );
  }

  // Preparar datos para el mapa de calor mejorado
  const { heatMapData, strategicLines, programs } = useMemo(() => {
    // Agrupar por línea estratégica y programa
    const groupedData = indicators.reduce((acc, indicator) => {
      const key = `${indicator.strategicLine}|${indicator.program}`;
      
      if (!acc[key]) {
        acc[key] = {
          strategicLine: indicator.strategicLine,
          program: indicator.program,
          totalProgress: 0,
          totalTarget: 0,
          count: 0,
          indicators: []
        };
      }
      
      // Obtener progreso para el año seleccionado
      let progress = 0;
      let target = 0;
      
      switch(year) {
        case "2024":
          progress = indicator.progress2024 || 0;
          target = indicator.target2024 || 0;
          break;
        case "2025":
          progress = indicator.progress2025 || 0;
          target = indicator.target2025 || 0;
          break;
        case "2026":
          progress = indicator.progress2026 || 0;
          target = indicator.target2026 || 0;
          break;
        case "2027":
          progress = indicator.progress2027 || 0;
          target = indicator.target2027 || 0;
          break;
        case "cuatrienio":
        default:
          progress = indicator.totalProgress || 0;
          target = indicator.totalTarget || 0;
          break;
      }
      
      // Acumular progreso y metas (ponderado por el peso real)
      acc[key].totalProgress += progress;
      acc[key].totalTarget += target;
      acc[key].count += 1;
      acc[key].indicators.push({
        code: indicator.code,
        name: indicator.name,
        progress,
        target,
        percentage: target > 0 ? (progress / target) * 100 : 0
      });
      
      return acc;
    }, {} as Record<string, { 
      strategicLine: string; 
      program: string; 
      totalProgress: number; 
      totalTarget: number; 
      count: number;
      indicators: Array<{code: string; name: string; progress: number; target: number; percentage: number}>;
    }>);
    
    // Obtener listas únicas
    const strategicLinesSet: Record<string, boolean> = {};
    const programsSet: Record<string, boolean> = {};
    
    indicators.forEach(indicator => {
      strategicLinesSet[indicator.strategicLine] = true;
      programsSet[indicator.program] = true;
    });
    
    const strategicLines = Object.keys(strategicLinesSet).sort();
    const programs = Object.keys(programsSet).sort();
    
    // Convertir a matriz con porcentajes ponderados reales
    const heatMapData = Object.values(groupedData).map(({ 
      strategicLine, 
      program, 
      totalProgress, 
      totalTarget, 
      count,
      indicators: inds
    }) => ({
      strategicLine,
      program,
      // Porcentaje real ponderado por el peso de cada indicador
      percentage: totalTarget > 0 ? (totalProgress / totalTarget) * 100 : 0,
      count,
      totalProgress,
      totalTarget,
      indicators: inds,
      // Información adicional para tooltips
      avgPerIndicator: count > 0 ? inds.reduce((sum, ind) => sum + ind.percentage, 0) / count : 0
    }));
    
    return { heatMapData, strategicLines, programs };
  }, [indicators, year]);

  // Función para obtener la intensidad del color basado en el porcentaje
  const getColorIntensity = (percentage: number) => {
    const normalized = Math.min(Math.max(percentage, 0), 150) / 150; // Normalizar hasta 150%
    return normalized;
  };

  // Función para obtener el color basado en el porcentaje
  const getCellColor = (percentage: number, strategicLine: string) => {
    const baseColor = getStrategicLineColor(strategicLine);
    const intensity = getColorIntensity(percentage);
    
    // Convertir hex a RGB y aplicar intensidad
    const r = parseInt(baseColor.slice(1, 3), 16);
    const g = parseInt(baseColor.slice(3, 5), 16);
    const b = parseInt(baseColor.slice(5, 7), 16);
    
    // Aplicar intensidad (más claro = menos avance, más oscuro = más avance)
    const minOpacity = 0.1;
    const opacity = minOpacity + (intensity * (0.9 - minOpacity));
    
    return `rgba(${r}, ${g}, ${b}, ${opacity})`;
  };

  return (
    <div className="mb-6">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
            Mapa de Calor: Avance por Línea y Programa
          </h2>
          <p className="text-gray-600 dark:text-gray-400 text-sm">
            Los colores más intensos representan mayor avance ponderado. Cada celda muestra el progreso real considerando el peso de los indicadores.
          </p>
        </div>

        {/* Leyenda de colores */}
        <div className="mb-6 flex flex-wrap items-center gap-4">
          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Intensidad:</span>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-gray-200 dark:bg-gray-600 rounded"></div>
            <span className="text-xs text-gray-600 dark:text-gray-400">0%</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-green-300 rounded"></div>
            <span className="text-xs text-gray-600 dark:text-gray-400">50%</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-green-600 rounded"></div>
            <span className="text-xs text-gray-600 dark:text-gray-400">100%</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-green-800 rounded"></div>
            <span className="text-xs text-gray-600 dark:text-gray-400">150%</span>
          </div>
        </div>

        {/* Mapa de calor personalizado */}
        <div className="overflow-x-auto">
          <div className="min-w-full">
            {/* Encabezados de programas */}
            <div className="grid grid-cols-1 gap-2">
              {strategicLines.map((strategicLine) => {
                const linePrograms = programs.filter(program => 
                  heatMapData.some(item => item.strategicLine === strategicLine && item.program === program)
                );
                
                return (
                  <motion.div
                    key={strategicLine}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                    className="mb-4"
                  >
                    <div className="mb-3">
                      <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-2">
                        {getStrategicLineShortName(strategicLine)}
                      </h3>
                      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
                        {linePrograms.map((program) => {
                          const cellData = heatMapData.find(
                            item => item.strategicLine === strategicLine && item.program === program
                          );
                          
                          if (!cellData) return null;
                          
                          const percentage = cellData.percentage;
                          const cellColor = getCellColor(percentage, strategicLine);
                          
                          return (
                            <motion.div
                              key={`${strategicLine}-${program}`}
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              transition={{ duration: 0.3, delay: 0.1 }}
                              whileHover={{ 
                                scale: 1.05, 
                                zIndex: 10,
                                boxShadow: "0 10px 25px rgba(0,0,0,0.15)" 
                              }}
                              className="relative group cursor-pointer"
                            >
                              <div
                                className="p-4 rounded-lg border-2 border-gray-200 dark:border-gray-600 transition-all duration-300 hover:border-gray-400 dark:hover:border-gray-400"
                                style={{ backgroundColor: cellColor }}
                              >
                                <div className="text-xs font-medium text-gray-700 dark:text-gray-300 mb-1 truncate">
                                  {program}
                                </div>
                                <div className="text-lg font-bold text-gray-900 dark:text-white">
                                  {percentage.toFixed(1)}%
                                </div>
                                <div className="text-xs text-gray-600 dark:text-gray-400">
                                  {cellData.count} indicadores
                                </div>
                                
                                {/* Tooltip mejorado */}
                                <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-20">
                                  <div className="bg-gray-900 dark:bg-gray-700 text-white text-xs rounded-lg py-2 px-3 whitespace-nowrap shadow-lg">
                                    <div className="font-semibold mb-1">{program}</div>
                                    <div>Avance ponderado: {percentage.toFixed(1)}%</div>
                                    <div>Progreso total: {cellData.totalProgress.toFixed(1)}</div>
                                    <div>Meta total: {cellData.totalTarget.toFixed(1)}</div>
                                    <div>Indicadores: {cellData.count}</div>
                                    <div>Promedio simple: {cellData.avgPerIndicator.toFixed(1)}%</div>
                                    <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-900 dark:border-t-gray-700"></div>
                                  </div>
                                </div>
                              </div>
                            </motion.div>
                          );
                        })}
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Estadísticas generales */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-600"
        >
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
              <div className="text-lg font-bold text-gray-900 dark:text-white">
                {strategicLines.length}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Líneas Estratégicas</div>
            </div>
            <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
              <div className="text-lg font-bold text-gray-900 dark:text-white">
                {programs.length}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Programas</div>
            </div>
            <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
              <div className="text-lg font-bold text-gray-900 dark:text-white">
                {heatMapData.length}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Combinaciones</div>
            </div>
            <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
              <div className="text-lg font-bold text-gray-900 dark:text-white">
                {indicators.length}
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">Indicadores</div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default HeatMapVisualizations;