// IndicatorsList.tsx

import React, { useState, useMemo, useCallback, useEffect } from "react";
import { Indicator } from "@shared/schema"; // Asumo que esta es la definición de tu tipo
import { 
  getStatusForIndicator, 
  getStatusClass, 
  getStrategicLineClass,
  getStrategicLineShortName,
  formatNumberWithDecimals,
  getProgressPercentage
} from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

// Importando componentes de UI (asumiendo que usas shadcn/ui)
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

// Importando iconos modernos de lucide-react
import { Search, Download, Columns, Loader2 } from "lucide-react";

// --- INICIO DE LÓGICA Y DEFINICIONES MEJORADAS ---

interface IndicatorsListProps {
  indicators: Indicator[];
  year: string;
  isLoading: boolean;
}

type ColumnId = 
  | "code" | "name" | "bpim" | "lineProgram" | "sector" | "ods" | "responsible" | "target" 
  | "progress" | "percentage" | "budget" | "status";

interface ColumnDef {
  id: ColumnId;
  name: string;
  visible: boolean;
  headerName?: string; // Nombre para cabecera, puede ser más corto
}

// --- FUNCIÓN HELPER PARA EXTRAER DATOS POR AÑO ---
// Centraliza la lógica para evitar repetición en el render y la exportación.
const getYearSpecificData = (indicator: Indicator, year: string) => {
  switch(year) {
    case "cuatrienio":
      return {
        target: indicator.totalTarget || 0,
        progress: (indicator.progress2024 || 0) + (indicator.progress2025 || 0) + (indicator.progress2026 || 0) + (indicator.progress2027 || 0),
        initialBudget: indicator.totalInitialBudget || 0,
        finalBudget: indicator.totalFinalBudget || 0,
      };
    case "2024":
      return {
        target: indicator.target2024 || 0,
        progress: indicator.progress2024 || 0,
        initialBudget: indicator.initialBudget2024 || 0,
        finalBudget: indicator.finalBudget2024 || 0,
      };
    case "2025":
      return {
        target: indicator.target2025 || 0,
        progress: indicator.progress2025 || 0,
        initialBudget: indicator.initialBudget2025 || 0,
        finalBudget: indicator.finalBudget2025 || 0,
      };
    case "2026":
      return {
        target: indicator.target2026 || 0,
        progress: indicator.progress2026 || 0,
        initialBudget: indicator.initialBudget2026 || 0,
        finalBudget: indicator.finalBudget2026 || 0,
      };
    case "2027":
      return {
        target: indicator.target2027 || 0,
        progress: indicator.progress2027 || 0,
        initialBudget: indicator.initialBudget2027 || 0,
        finalBudget: indicator.finalBudget2027 || 0,
      };
    default:
      return { target: 0, progress: 0, initialBudget: 0, finalBudget: 0 };
  }
};

// --- FUNCIÓN HELPER PARA ORDENAR POR CÓDIGO (REQUERIMIENTO PRINCIPAL) ---
// Implementa la lógica de ordenamiento L1 > P1 > -01
const sortIndicatorsByCode = (a: Indicator, b: Indicator): number => {
  const regex = /^L(\d+)P(\d+)-(\d+)$/;

  const matchA = a.code.match(regex);
  const matchB = b.code.match(regex);

  // Si algún código no coincide con el patrón, se va al final.
  if (!matchA) return 1;
  if (!matchB) return -1;

  const [, lA, pA, iA] = matchA.map(Number);
  const [, lB, pB, iB] = matchB.map(Number);

  if (lA !== lB) return lA - lB; // 1. Ordenar por Línea (L)
  if (pA !== pB) return pA - pB; // 2. Luego por Programa (P)
  return iA - iB;                // 3. Finalmente por el consecutivo
};

const IndicatorsList: React.FC<IndicatorsListProps> = ({ indicators, year, isLoading }) => {
  const { toast } = useToast();
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState("");
  const itemsPerPage = 10;

  const [columns, setColumns] = useState<ColumnDef[]>([
    { id: "code", name: "Código", visible: true },
    { id: "name", name: "Indicador", visible: true },
    { id: "bpim", name: "BPIM", visible: true },
    { id: "lineProgram", name: "Línea/Programa", visible: true },
    { id: "sector", name: "Sector", visible: true },
    { id: "ods", name: "ODS", visible: true },
    { id: "responsible", name: "Responsable", visible: true },
    { id: "target", name: "Meta", visible: true, headerName: `Meta ${year}` },
    { id: "progress", name: "Avance", visible: true, headerName: `Avance ${year}` },
    { id: "percentage", name: "% Progreso", visible: true },
    { id: "budget", name: "Presupuesto", visible: true, headerName: `Ppto. ${year}` },
    { id: "status", name: "Estado", visible: true }
  ]);

  useEffect(() => {
    setColumns(prev => prev.map(col => ({
      ...col,
      headerName: col.id.match(/target|progress|budget/) 
        ? `${col.name} ${year}` 
        : col.name
    })));
  }, [year]);

  const toggleColumn = (columnId: ColumnId) => {
    setColumns(prev => 
      prev.map(col => col.id === columnId ? { ...col, visible: !col.visible } : col)
    );
  };

  const visibleColumns = useMemo(() => columns.filter(col => col.visible), [columns]);

  // --- CADENA DE PROCESAMIENTO DE DATOS CON MEMOIZACIÓN ---

  // 1. Filtrar por término de búsqueda
  const filteredIndicators = useMemo(() => {
    if (!searchTerm) return indicators;
    const lowercasedFilter = searchTerm.toLowerCase();
    return indicators.filter(ind => 
      Object.values(ind).some(val => 
        String(val).toLowerCase().includes(lowercasedFilter)
      )
    );
  }, [indicators, searchTerm]);

  // 2. Ordenar los indicadores filtrados
  const sortedIndicators = useMemo(() => {
    return [...filteredIndicators].sort(sortIndicatorsByCode);
  }, [filteredIndicators]);

  // 3. Paginar los resultados ordenados
  const totalPages = useMemo(() => Math.ceil(sortedIndicators.length / itemsPerPage), [sortedIndicators, itemsPerPage]);

  const currentIndicators = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return sortedIndicators.slice(startIndex, startIndex + itemsPerPage);
  }, [sortedIndicators, currentPage, itemsPerPage]);

  const exportData = useCallback(() => {
    const headers = "Código,Indicador,BPIM,Línea,Programa,Sector,ODS,Responsable,Meta,Avance,% Progreso,Presupuesto Inicial,Presupuesto Final,Estado\n";

    const csvRows = sortedIndicators.map(indicator => {
      const { target, progress, initialBudget, finalBudget } = getYearSpecificData(indicator, year);
      const percentage = getProgressPercentage(progress, target);
      const status = getStatusForIndicator(indicator, year);

      const row = [
        indicator.code,
        `"${indicator.name.replace(/"/g, '""')}"`,
        indicator.bpim || '-',
        `"${indicator.strategicLine.replace(/"/g, '""')}"`,
        `"${indicator.program.replace(/"/g, '""')}"`,
        indicator.sector || '-',
        indicator.ods ? `ODS ${indicator.ods}` : '-',
        `"${indicator.responsible.replace(/"/g, '""')}"`,
        target,
        progress,
        `${percentage.toFixed(1)}%`,
        initialBudget,
        finalBudget,
        status === "avanzado" ? "Avanzado" : status === "en-tiempo" ? "En Tiempo" : "Retrasado"
      ].join(",");
      return row;
    });

    const csv = headers + csvRows.join("\n");
    const blob = new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `indicadores_${year}_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    toast({
      title: "Exportación completada",
      description: `Se han exportado ${sortedIndicators.length} indicadores.`,
    });
  }, [sortedIndicators, year, toast]);

  const goToPage = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  // --- CSS EMBEBIDO PARA RESPONSIVIDAD ---
  // Mantiene todo en un solo archivo.
  const responsiveStyles = `
    @media (max-width: 767px) {
      .responsive-table .table-header-group {
        display: none;
      }
      .responsive-table .table-row {
        display: block;
        margin-bottom: 1rem;
        border: 1px solid #e5e7eb;
        border-radius: 0.5rem;
        box-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
        padding: 0.5rem;
      }
      .dark .responsive-table .table-row {
        border-color: #374151;
        background-color: #1f2937;
      }
      .responsive-table .table-cell {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0.75rem 0.5rem;
        text-align: right;
        border-bottom: 1px solid #f3f4f6;
      }
      .dark .responsive-table .table-cell {
        border-bottom-color: #374151;
      }
      .responsive-table .table-cell:last-child {
        border-bottom: none;
      }
      .responsive-table .table-cell[data-label]::before {
        content: attr(data-label);
        font-weight: 600;
        margin-right: 0.5rem;
        text-align: left;
        color: #4b5563;
      }
      .dark .responsive-table .table-cell[data-label]::before {
        color: #9ca3af;
      }
      .responsive-table .table-cell[data-label="Indicador"],
      .responsive-table .table-cell[data-label="Línea/Programa"],
      .responsive-table .table-cell[data-label^="Presupuesto"] {
        display: block;
        text-align: left;
      }
      .responsive-table .table-cell[data-label="Indicador"]::before,
      .responsive-table .table-cell[data-label="Línea/Programa"]::before,
      .responsive-table .table-cell[data-label^="Presupuesto"]::before {
        margin-bottom: 0.25rem;
        display: block;
      }
      .responsive-table .table-cell[data-label="BPIM"],
      .responsive-table .table-cell[data-label="Sector"],
      .responsive-table .table-cell[data-label="ODS"] {
        display: block;
        text-align: left;
      }
    }
  `;

  // --- COMPONENTES DE ESTADO (LOADING, EMPTY) ---

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64 bg-white rounded-lg shadow-md p-4">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
        <p className="ml-4 text-gray-600">Cargando indicadores...</p>
      </div>
    );
  }

  if (indicators.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-md p-8 text-center">
        <h2 className="text-xl font-bold font-roboto mb-4">Listado de Indicadores</h2>
        <p className="text-gray-600">No se encontraron indicadores para mostrar.</p>
      </div>
    );
  }

  // --- RENDERIZADO PRINCIPAL ---

  return (
    <>
      <style>{responsiveStyles}</style>
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 sm:p-6 mb-6 font-sans">
        <div className="flex flex-col sm:flex-row justify-between items-center mb-4 gap-4">
          <h2 className="text-xl font-bold text-gray-800 dark:text-white self-start sm:self-center">Listado de Indicadores</h2>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <div className="relative flex-grow">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input 
                type="text" 
                placeholder="Buscar..." 
                className="pl-9 w-full"
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setCurrentPage(1); // Reset page on new search
                }}
              />
            </div>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" size="sm" className="flex-shrink-0">
                  <Columns className="h-4 w-4 mr-2" /> Columnas
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-60 p-2">
                <div className="p-2 font-medium text-sm text-gray-800">Mostrar/Ocultar Columnas</div>
                <div className="space-y-1">
                  {columns.map((col) => (
                    <Label key={col.id} className="flex items-center gap-2 p-2 rounded-md hover:bg-gray-100 cursor-pointer">
                      <Checkbox
                        id={`col-${col.id}`}
                        checked={col.visible}
                        onCheckedChange={() => toggleColumn(col.id)}
                      />
                      <span>{col.name}</span>
                    </Label>
                  ))}
                </div>
              </PopoverContent>
            </Popover>
            <Button variant="outline" size="sm" onClick={exportData} className="flex-shrink-0">
              <Download className="h-4 w-4 mr-2" /> Exportar
            </Button>
          </div>
        </div>

        <div className="overflow-x-auto responsive-table">
          <Table className="min-w-full">
            <TableHeader className="table-header-group">
              <TableRow>
                {visibleColumns.map(col => <TableHead key={col.id}>{col.headerName}</TableHead>)}
              </TableRow>
            </TableHeader>
            <TableBody className="table-row-group">
              {currentIndicators.length > 0 ? currentIndicators.map(indicator => {
                const { target, progress, initialBudget, finalBudget } = getYearSpecificData(indicator, year);
                const percentage = getProgressPercentage(progress, target);
                const status = getStatusForIndicator(indicator, year);
                const progressColorClass = status === "avanzado" ? "bg-green-500" : status === "en-tiempo" ? "bg-amber-500" : "bg-red-500";

                return (
                  <TableRow key={indicator.code} className="table-row">
                    {columns.find(c => c.id === 'code' && c.visible) && (
                      <TableCell data-label="Código">
                        <Badge variant="secondary">{indicator.code}</Badge>
                      </TableCell>
                    )}
                    {columns.find(c => c.id === 'name' && c.visible) && (
                      <TableCell data-label="Indicador">
                        <p className="font-semibold text-gray-800 dark:text-gray-100">{indicator.name}</p>
                        {indicator.description && <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{indicator.description}</p>}
                      </TableCell>
                    )}
                    {columns.find(c => c.id === 'bpim' && c.visible) && (
                      <TableCell data-label="BPIM" className="dark:text-gray-200">
                        {indicator.bpim || '-'}
                      </TableCell>
                    )}
                    {columns.find(c => c.id === 'lineProgram' && c.visible) && (
                      <TableCell data-label="Línea/Programa">
                         <div className="flex flex-col gap-1">
                          <span className={`font-medium ${getStrategicLineClass(indicator.strategicLine)}`}>
                            {getStrategicLineShortName(indicator.strategicLine)}
                          </span>
                          <span className="text-xs text-gray-500 dark:text-gray-400">{indicator.program}</span>
                        </div>
                      </TableCell>
                    )}
                    {columns.find(c => c.id === 'sector' && c.visible) && (
                      <TableCell data-label="Sector" className="dark:text-gray-200">
                        {indicator.sector || '-'}
                      </TableCell>
                    )}
                    {columns.find(c => c.id === 'ods' && c.visible) && (
                      <TableCell data-label="ODS">
                        {indicator.ods ? `ODS ${indicator.ods}` : '-'}
                      </TableCell>
                    )}
                    {columns.find(c => c.id === 'responsible' && c.visible) && (
                      <TableCell data-label="Responsable" className="dark:text-gray-200">{indicator.responsible}</TableCell>
                    )}
                    {columns.find(c => c.id === 'target' && c.visible) && (
                      <TableCell data-label={`Meta ${year}`}>
                        <span className="dark:text-gray-200">{formatNumberWithDecimals(target)}</span> <span className="text-gray-500 dark:text-gray-400 text-xs">{indicator.unit}</span>
                      </TableCell>
                    )}
                    {columns.find(c => c.id === 'progress' && c.visible) && (
                      <TableCell data-label={`Avance ${year}`}>
                        <span className="dark:text-gray-200">{formatNumberWithDecimals(progress)}</span> <span className="text-gray-500 dark:text-gray-400 text-xs">{indicator.unit}</span>
                      </TableCell>
                    )}
                    {columns.find(c => c.id === 'percentage' && c.visible) && (
                      <TableCell data-label="% Progreso">
                        <div className="flex items-center gap-2 justify-end md:justify-start">
                          <Progress value={percentage} className="w-20 h-2" indicatorClassName={progressColorClass} />
                          <span className="font-medium text-sm text-gray-700 dark:text-gray-200 w-12 text-left">{percentage.toFixed(1)}%</span>
                        </div>
                      </TableCell>
                    )}
                     {columns.find(c => c.id === 'budget' && c.visible) && (
                      <TableCell data-label={`Presupuesto ${year}`}>
                        <div className="text-sm space-y-1">
                          <div className="text-blue-600 dark:text-blue-400 text-xs">
                            Inicial: ${(initialBudget || 0).toLocaleString('es-CO', { maximumFractionDigits: 0 })}
                          </div>
                          <div className="text-green-600 dark:text-green-400 font-medium text-xs">
                            Final: ${(finalBudget || 0).toLocaleString('es-CO', { maximumFractionDigits: 0 })}
                          </div>
                          {initialBudget === 0 && finalBudget === 0 && (
                            <span className="text-gray-400 dark:text-gray-500 text-xs">Sin presupuesto</span>
                          )}
                        </div>
                      </TableCell>
                    )}
                    {columns.find(c => c.id === 'status' && c.visible) && (
                      <TableCell data-label="Estado">
                        <Badge className={`${getStatusClass(status)}`}>
                          {status === "avanzado" ? "Avanzado" : status === "en-tiempo" ? "En Tiempo" : "Retrasado"}
                        </Badge>
                      </TableCell>
                    )}
                  </TableRow>
                );
              }) : (
                <TableRow>
                  <TableCell colSpan={visibleColumns.length} className="h-24 text-center">
                    No se encontraron resultados para "{searchTerm}".
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>

        {totalPages > 1 && (
          <div className="mt-6 flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="text-sm text-gray-600 dark:text-gray-400">
              Mostrando {Math.min((currentPage - 1) * itemsPerPage + 1, sortedIndicators.length)} a {Math.min(currentPage * itemsPerPage, sortedIndicators.length)} de {sortedIndicators.length}
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={() => goToPage(currentPage - 1)} disabled={currentPage === 1}>Anterior</Button>
              <span className="text-sm text-gray-700 dark:text-gray-300 px-2">Página {currentPage} de {totalPages}</span>
              <Button variant="outline" size="sm" onClick={() => goToPage(currentPage + 1)} disabled={currentPage === totalPages}>Siguiente</Button>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default IndicatorsList;