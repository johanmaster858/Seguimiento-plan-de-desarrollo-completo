import React, { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import LoginModal from "./LoginModal";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import ScrollToTop from "./ScrollToTop";
import logoSanJeronimo from "../assets/logo-san-jeronimo.jpeg";
import { useIsMobile } from "@/hooks/use-mobile";
import { Button } from "@/components/ui/button";

interface MainLayoutProps {
  children: React.ReactNode;
}

const MainLayout: React.FC<MainLayoutProps> = ({ children }) => {
  const { isAuthenticated, isAdmin, logout } = useAuth();
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const isMobile = useIsMobile();

  const handleLogout = async () => {
    await logout();
    setIsMobileMenuOpen(false);
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-md sticky top-0 z-30">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          {/* Logo y título */}
          <div className="flex items-center space-x-3">
            <div className="h-10 w-10 md:h-14 md:w-14 rounded-md flex items-center justify-center">
              <img src={logoSanJeronimo} alt="Logo San Jerónimo" className="h-10 md:h-14 object-cover rounded-md" />
            </div>
            <div>
              <h1 className="text-lg md:text-xl font-bold text-gray-900 dark:text-gray-100 font-roboto">
                {isMobile ? "PDD San Jerónimo" : "Plan de Desarrollo San Jerónimo"}
              </h1>
              <p className="text-xs md:text-sm text-gray-600 dark:text-gray-400 font-['Open_Sans']">
                Dashboard 2024-2027
              </p>
            </div>
          </div>
          
          {/* Botones de navegación escritorio */}
          {!isMobile && (
            <div className="flex items-center space-x-3">
              <ThemeToggle />
              
              {isAuthenticated && isAdmin && (
                <>
                  <a 
                    href="/admin"
                    className="bg-purple-600 text-white dark:bg-purple-700 dark:hover:bg-purple-800 px-4 py-2 rounded-md hover:bg-purple-700 transition flex items-center space-x-1 text-sm font-medium"
                  >
                    <span className="material-icons text-sm">dashboard</span>
                    <span>Panel Admin</span>
                  </a>
                  <a 
                    href="/"
                    className="bg-blue-600 text-white dark:bg-blue-700 dark:hover:bg-blue-800 px-4 py-2 rounded-md hover:bg-blue-700 transition flex items-center space-x-1 text-sm font-medium"
                  >
                    <span className="material-icons text-sm">visibility</span>
                    <span>Vista Pública</span>
                  </a>
                </>
              )}
              
              {isAuthenticated ? (
                <button 
                  onClick={handleLogout}
                  className="bg-green-600 text-white dark:bg-green-700 dark:hover:bg-green-800 px-4 py-2 rounded-md hover:bg-green-700 transition flex items-center space-x-1 text-sm font-medium"
                >
                  <span className="material-icons text-sm">person</span>
                  <span>Cerrar Sesión</span>
                </button>
              ) : (
                <button 
                  onClick={() => setIsLoginModalOpen(true)}
                  className="bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600 px-4 py-2 rounded-md hover:bg-gray-300 transition flex items-center space-x-1 text-sm font-medium"
                >
                  <span className="material-icons text-sm">lock</span>
                  <span>Admin</span>
                </button>
              )}
            </div>
          )}
          
          {/* Botón menú hamburguesa para móvil */}
          {isMobile && (
            <div className="flex items-center gap-2">
              <ThemeToggle />
              <Button 
                variant="ghost" 
                className="p-2" 
                onClick={toggleMobileMenu}
                aria-label="Menú"
              >
                <span className="material-icons text-xl">
                  {isMobileMenuOpen ? 'close' : 'menu'}
                </span>
              </Button>
            </div>
          )}
        </div>
        
        {/* Menú móvil desplegable */}
        {isMobile && isMobileMenuOpen && (
          <div className="container mx-auto px-4 py-2 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700">
            <div className="flex flex-col space-y-2">
              {isAuthenticated && isAdmin && (
                <>
                  <a 
                    href="/admin"
                    className="bg-purple-600 text-white dark:bg-purple-700 dark:hover:bg-purple-800 px-4 py-2 rounded-md hover:bg-purple-700 transition flex items-center space-x-2"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <span className="material-icons">dashboard</span>
                    <span>Panel Admin</span>
                  </a>
                  <a 
                    href="/"
                    className="bg-blue-600 text-white dark:bg-blue-700 dark:hover:bg-blue-800 px-4 py-2 rounded-md hover:bg-blue-700 transition flex items-center space-x-2"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <span className="material-icons">visibility</span>
                    <span>Vista Pública</span>
                  </a>
                </>
              )}
              
              {isAuthenticated ? (
                <button 
                  onClick={handleLogout}
                  className="bg-green-600 text-white dark:bg-green-700 dark:hover:bg-green-800 px-4 py-2 rounded-md hover:bg-green-700 transition flex items-center space-x-2"
                >
                  <span className="material-icons">person</span>
                  <span>Cerrar Sesión</span>
                </button>
              ) : (
                <button 
                  onClick={() => {
                    setIsLoginModalOpen(true);
                    setIsMobileMenuOpen(false);
                  }}
                  className="bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600 px-4 py-2 rounded-md hover:bg-gray-300 transition flex items-center space-x-2"
                >
                  <span className="material-icons">lock</span>
                  <span>Admin</span>
                </button>
              )}
            </div>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-grow container mx-auto px-2 sm:px-4 py-4 sm:py-6">
        {children}
      </main>

      {/* Footer simplificado */}
      <footer className="bg-gray-900 dark:bg-gray-950 text-white py-3 sm:py-4">
        <div className="container mx-auto px-4 text-center">
          <p className="text-xs sm:text-sm text-gray-400 dark:text-gray-500 font-['Open_Sans']">
            &copy; {new Date().getFullYear()} - Elaborado por Johan Grisales
          </p>
        </div>
      </footer>

      {/* Login Modal */}
      <LoginModal isOpen={isLoginModalOpen} onClose={() => setIsLoginModalOpen(false)} />
      
      {/* Scroll to top button */}
      <ScrollToTop />
    </div>
  );
};

export default MainLayout;
