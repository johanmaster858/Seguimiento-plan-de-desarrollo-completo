import React, { useState } from "react";
import { Indicator } from "@shared/schema";
import { calculateSummaryStats, getStrategicLineColor, getStrategicLineShortName } from "@/lib/utils";
import { motion } from "framer-motion";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, Area, AreaChart } from "recharts";

interface PerformanceChartsProps {
  indicators: Indicator[];
  year: string;
}

const PerformanceCharts: React.FC<PerformanceChartsProps> = ({
  indicators,
  year
}) => {
  const [activeChart, setActiveChart] = useState<'bar' | 'pie' | 'area'>('bar');
  const [hoveredLine, setHoveredLine] = useState<string | null>(null);

  // Skip if no indicators
  if (!indicators || indicators.length === 0) {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 text-center">
          <h3 className="text-lg font-medium mb-3 text-gray-900 dark:text-white">Avance por Línea Estratégica</h3>
          <p className="text-gray-500 dark:text-gray-400">No hay datos disponibles para mostrar el gráfico.</p>
        </div>
      </div>
    );
  }

  // Calculate data for charts
  const stats = calculateSummaryStats(indicators, year);
  
  // Preparar datos para gráficos mejorados
  const strategicLineData = stats.lineStatsArray.map(line => ({
    name: getStrategicLineShortName(line.name),
    fullName: line.name,
    percentage: line.percentage,
    progress: line.progress,
    target: line.target,
    count: line.count,
    color: getStrategicLineColor(line.name)
  }));

  // Datos para gráfico de comparación anual
  const yearlyData = [
    { year: '2024', progress: 45, target: 25, actual: indicators.reduce((sum, ind) => sum + (ind.progress2024 || 0), 0) },
    { year: '2025', progress: stats.averageProgress, target: 50, actual: indicators.reduce((sum, ind) => sum + (ind.progress2025 || 0), 0) },
    { year: '2026', progress: 75, target: 75, actual: indicators.reduce((sum, ind) => sum + (ind.progress2026 || 0), 0) },
    { year: '2027', progress: 95, target: 100, actual: indicators.reduce((sum, ind) => sum + (ind.progress2027 || 0), 0) }
  ];

  // Datos para gráfico de estados
  const statusData = [
    { name: 'Avanzado', value: stats.advancedCount, color: '#4CAF50' },
    { name: 'A tiempo', value: stats.onTimeCount, color: '#FFC107' },
    { name: 'Retrasado', value: stats.delayedCount, color: '#F44336' },
    { name: 'Sin datos', value: stats.noDataCount, color: '#9E9E9E' }
  ].filter(item => item.value > 0);

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white dark:bg-gray-800 p-3 border border-gray-200 dark:border-gray-600 rounded-lg shadow-lg">
          <p className="font-semibold text-gray-900 dark:text-white">{`${label}`}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} style={{ color: entry.color }}>
              {`${entry.dataKey}: ${entry.value.toFixed(1)}${entry.dataKey.includes('percentage') ? '%' : ''}`}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      {/* Gráfico principal de líneas estratégicas */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6"
      >
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4 sm:mb-0">
            Avance por Línea Estratégica
          </h3>
          <div className="flex gap-2">
            {(['bar', 'pie', 'area'] as const).map((chartType) => (
              <motion.button
                key={chartType}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setActiveChart(chartType)}
                className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                  activeChart === chartType
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-600'
                }`}
              >
                {chartType === 'bar' ? 'Barras' : chartType === 'pie' ? 'Circular' : 'Área'}
              </motion.button>
            ))}
          </div>
        </div>

        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            {activeChart === 'bar' && (
              <BarChart data={strategicLineData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                <XAxis 
                  dataKey="name" 
                  stroke="#6B7280"
                  fontSize={12}
                />
                <YAxis 
                  stroke="#6B7280"
                  fontSize={12}
                />
                <Tooltip content={<CustomTooltip />} />
                <Bar 
                  dataKey="percentage" 
                  fill="#8884d8"
                  radius={[4, 4, 0, 0]}
                >
                  {strategicLineData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            )}
            
            {activeChart === 'pie' && (
              <PieChart>
                <Pie
                  data={strategicLineData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={120}
                  paddingAngle={5}
                  dataKey="percentage"
                >
                  {strategicLineData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            )}
            
            {activeChart === 'area' && (
              <AreaChart data={strategicLineData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                <XAxis 
                  dataKey="name" 
                  stroke="#6B7280"
                  fontSize={12}
                />
                <YAxis 
                  stroke="#6B7280"
                  fontSize={12}
                />
                <Tooltip content={<CustomTooltip />} />
                <Area 
                  type="monotone" 
                  dataKey="percentage" 
                  stroke="#8884d8" 
                  fill="#8884d8" 
                  fillOpacity={0.6}
                />
              </AreaChart>
            )}
          </ResponsiveContainer>
        </div>

        {/* Leyenda interactiva */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 mt-4">
          {strategicLineData.map((line, index) => (
            <motion.div
              key={line.name}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              whileHover={{ scale: 1.05 }}
              onMouseEnter={() => setHoveredLine(line.fullName)}
              onMouseLeave={() => setHoveredLine(null)}
              className={`p-3 rounded-lg border transition-all cursor-pointer ${
                hoveredLine === line.fullName
                  ? 'border-gray-400 dark:border-gray-500 shadow-md'
                  : 'border-gray-200 dark:border-gray-600'
              } bg-gray-50 dark:bg-gray-700`}
            >
              <div className="flex items-center mb-2">
                <span 
                  className="w-3 h-3 rounded-full mr-2" 
                  style={{ backgroundColor: line.color }}
                ></span>
                <span className="text-sm font-medium text-gray-900 dark:text-white truncate">
                  {line.name}
                </span>
              </div>
              <div className="text-lg font-bold text-gray-900 dark:text-white">
                {line.percentage.toFixed(1)}%
              </div>
              <div className="text-xs text-gray-600 dark:text-gray-400">
                {line.count} indicadores
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Gráficos secundarios */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Comparativa anual */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6"
        >
          <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">
            Progreso Anual
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={yearlyData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                <XAxis dataKey="year" stroke="#6B7280" />
                <YAxis stroke="#6B7280" />
                <Tooltip content={<CustomTooltip />} />
                <Line 
                  type="monotone" 
                  dataKey="progress" 
                  stroke="#2196F3" 
                  strokeWidth={3}
                  dot={{ fill: '#2196F3', strokeWidth: 2, r: 4 }}
                  activeDot={{ r: 6, stroke: '#2196F3', strokeWidth: 2 }}
                />
                <Line 
                  type="monotone" 
                  dataKey="target" 
                  stroke="#9E9E9E" 
                  strokeDasharray="5 5"
                  strokeWidth={2}
                  dot={{ fill: '#9E9E9E', r: 3 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Estados de indicadores */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6"
        >
          <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">
            Estado de Indicadores
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={statusData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default PerformanceCharts;
