import React, { useMemo } from "react";
import { Indicator } from "@shared/schema";
import { formatNumberWithDecimals } from "@/lib/utils";

interface PerformanceMetricsProps {
  indicators: Indicator[];
  year: string;
}

interface MetricData {
  totalBudget: number;
  executedBudget: number;
  executionRate: number;
  averageProgress: number;
  topPerformers: Array<{
    code: string;
    name: string;
    progress: number;
    percentage: number;
  }>;
  underperformers: Array<{
    code: string;
    name: string;
    progress: number;
    percentage: number;
  }>;
}

const PerformanceMetrics: React.FC<PerformanceMetricsProps> = ({ indicators, year }) => {
  const metrics = useMemo<MetricData>(() => {
    if (!indicators || indicators.length === 0) {
      return {
        totalBudget: 0,
        executedBudget: 0,
        executionRate: 0,
        averageProgress: 0,
        topPerformers: [],
        underperformers: []
      };
    }

    let totalBudget = 0;
    let executedBudget = 0;
    let totalProgress = 0;
    let validProgressCount = 0;
    
    const indicatorPerformance = indicators.map(indicator => {
      let progress = 0;
      let target = 0;
      let initialBudget = 0;
      let finalBudget = 0;

      switch (year) {
        case "2024":
          progress = indicator.progress2024 || 0;
          target = indicator.target2024 || 0;
          initialBudget = indicator.initialBudget2024 || 0;
          finalBudget = indicator.finalBudget2024 || 0;
          break;
        case "2025":
          progress = indicator.progress2025 || 0;
          target = indicator.target2025 || 0;
          initialBudget = indicator.initialBudget2025 || 0;
          finalBudget = indicator.finalBudget2025 || 0;
          break;
        case "2026":
          progress = indicator.progress2026 || 0;
          target = indicator.target2026 || 0;
          initialBudget = indicator.initialBudget2026 || 0;
          finalBudget = indicator.finalBudget2026 || 0;
          break;
        case "2027":
          progress = indicator.progress2027 || 0;
          target = indicator.target2027 || 0;
          initialBudget = indicator.initialBudget2027 || 0;
          finalBudget = indicator.finalBudget2027 || 0;
          break;
        default:
          progress = indicator.totalProgress || 0;
          target = indicator.totalTarget || 0;
          initialBudget = (indicator.initialBudget2024 || 0) + (indicator.initialBudget2025 || 0) + 
                         (indicator.initialBudget2026 || 0) + (indicator.initialBudget2027 || 0);
          finalBudget = indicator.totalFinalBudget || 0;
      }

      totalBudget += initialBudget;
      executedBudget += finalBudget;
      
      const percentage = target > 0 ? (progress / target) * 100 : 0;
      
      if (target > 0) {
        totalProgress += percentage;
        validProgressCount++;
      }

      return {
        code: indicator.code,
        name: indicator.name,
        progress,
        target,
        percentage,
        finalBudget
      };
    });

    // Top performers (>80% progress)
    const topPerformers = indicatorPerformance
      .filter(i => i.percentage >= 80 && i.target > 0)
      .sort((a, b) => b.percentage - a.percentage)
      .slice(0, 5);

    // Underperformers (<30% progress)
    const underperformers = indicatorPerformance
      .filter(i => i.percentage < 30 && i.target > 0)
      .sort((a, b) => a.percentage - b.percentage)
      .slice(0, 5);

    return {
      totalBudget,
      executedBudget,
      executionRate: totalBudget > 0 ? (executedBudget / totalBudget) * 100 : 0,
      averageProgress: validProgressCount > 0 ? totalProgress / validProgressCount : 0,
      topPerformers,
      underperformers
    };
  }, [indicators, year]);

  return (
    <div className="space-y-6">
      {/* Main metrics cards */}
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {/* Budget Execution */}
        <div className="text-center p-6 bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 rounded-lg border border-blue-200 dark:border-blue-700">
          <div className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-2">
            {formatNumberWithDecimals(metrics.executionRate)}%
          </div>
          <div className="text-sm font-medium text-gray-700 dark:text-gray-300">Ejecución Presupuestal</div>
          <div className="text-xs text-gray-500 dark:text-gray-400 mt-2">
            ${metrics.executedBudget.toLocaleString('es-CO')} / ${metrics.totalBudget.toLocaleString('es-CO')}
          </div>
        </div>

        {/* Average Progress */}
        <div className="text-center p-6 bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20 rounded-lg border border-green-200 dark:border-green-700">
          <div className="text-3xl font-bold text-green-600 dark:text-green-400 mb-2">
            {formatNumberWithDecimals(metrics.averageProgress)}%
          </div>
          <div className="text-sm font-medium text-gray-700 dark:text-gray-300">Avance Promedio</div>
          <div className="text-xs text-gray-500 dark:text-gray-400 mt-2">
            Indicadores con meta definida
          </div>
        </div>

        {/* Top Performers Count */}
        <div className="text-center p-6 bg-gradient-to-br from-amber-50 to-amber-100 dark:from-amber-900/20 dark:to-amber-800/20 rounded-lg border border-amber-200 dark:border-amber-700">
          <div className="text-3xl font-bold text-amber-600 dark:text-amber-400 mb-2">
            {metrics.topPerformers.length}
          </div>
          <div className="text-sm font-medium text-gray-700 dark:text-gray-300">Alto Rendimiento</div>
          <div className="text-xs text-gray-500 dark:text-gray-400 mt-2">
            Indicadores &gt;80%
          </div>
        </div>

        {/* Underperformers Count */}
        <div className="text-center p-6 bg-gradient-to-br from-red-50 to-red-100 dark:from-red-900/20 dark:to-red-800/20 rounded-lg border border-red-200 dark:border-red-700">
          <div className="text-3xl font-bold text-red-600 dark:text-red-400 mb-2">
            {metrics.underperformers.length}
          </div>
          <div className="text-sm font-medium text-gray-700 dark:text-gray-300">Bajo Rendimiento</div>
          <div className="text-xs text-gray-500 dark:text-gray-400 mt-2">
            Indicadores &lt;30%
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Performers */}
        <div>
          <h4 className="font-medium mb-3 text-gray-700 dark:text-gray-300 flex items-center">
            <span className="material-icons text-green-600 mr-2 text-sm">trending_up</span>
            Mejores Desempeños
          </h4>
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {metrics.topPerformers.length > 0 ? (
              metrics.topPerformers.map((indicator, index) => (
                <div key={indicator.code} className="flex justify-between items-center p-2 bg-green-50 dark:bg-green-900/20 rounded text-sm">
                  <div className="flex items-center space-x-2">
                    <span className="text-green-600 dark:text-green-400 font-mono text-xs">#{index + 1}</span>
                    <span className="font-medium text-gray-700 dark:text-gray-300 truncate" title={indicator.name}>
                      {indicator.code}
                    </span>
                  </div>
                  <span className="text-green-600 dark:text-green-400 font-bold">
                    {formatNumberWithDecimals(indicator.percentage)}%
                  </span>
                </div>
              ))
            ) : (
              <div className="text-gray-500 dark:text-gray-400 text-sm text-center py-4">
                No hay indicadores con rendimiento alto
              </div>
            )}
          </div>
        </div>

        {/* Underperformers */}
        <div>
          <h4 className="font-medium mb-3 text-gray-700 dark:text-gray-300 flex items-center">
            <span className="material-icons text-red-600 mr-2 text-sm">trending_down</span>
            Requieren Atención
          </h4>
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {metrics.underperformers.length > 0 ? (
              metrics.underperformers.map((indicator, index) => (
                <div key={indicator.code} className="flex justify-between items-center p-2 bg-red-50 dark:bg-red-900/20 rounded text-sm">
                  <div className="flex items-center space-x-2">
                    <span className="text-red-600 dark:text-red-400 font-mono text-xs">#{index + 1}</span>
                    <span className="font-medium text-gray-700 dark:text-gray-300 truncate" title={indicator.name}>
                      {indicator.code}
                    </span>
                  </div>
                  <span className="text-red-600 dark:text-red-400 font-bold">
                    {formatNumberWithDecimals(indicator.percentage)}%
                  </span>
                </div>
              ))
            ) : (
              <div className="text-gray-500 dark:text-gray-400 text-sm text-center py-4">
                Todos los indicadores tienen buen rendimiento
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PerformanceMetrics;