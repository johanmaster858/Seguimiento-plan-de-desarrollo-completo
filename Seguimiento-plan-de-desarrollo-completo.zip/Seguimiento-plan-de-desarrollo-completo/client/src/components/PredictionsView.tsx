
import React, { useMemo, useState } from "react";
import { Indicator } from "@shared/schema";
import { formatNumberWithDecimals, getProgressPercentage } from "@/lib/utils";
import { SimpleBarChart } from "@/components/ui/chart";

interface PredictionsViewProps {
  indicators: Indicator[];
}

const PredictionsView: React.FC<PredictionsViewProps> = ({ indicators }) => {
  const [analysisType, setAnalysisType] = useState<string>("completion");

  const predictiveData = useMemo(() => {
    if (!indicators || indicators.length === 0) {
      return {
        completionPredictions: [],
        riskAnalysis: [],
        trendAnalysis: [],
        budgetProjections: []
      };
    }

    const completionPredictions: Array<{
      code: string;
      name: string;
      currentProgress: number;
      predictedCompletion: number;
      risk: "bajo" | "medio" | "alto";
      strategicLine: string;
    }> = [];

    const riskAnalysis: Array<{
      strategicLine: string;
      totalIndicators: number;
      atRisk: number;
      onTrack: number;
      riskPercentage: number;
    }> = {};

    const trendAnalysis: Array<{
      year: string;
      projected: number;
      actual: number;
    }> = [
      { year: "2024", projected: 0, actual: 0 },
      { year: "2025", projected: 0, actual: 0 },
      { year: "2026", projected: 0, actual: 0 },
      { year: "2027", projected: 0, actual: 0 }
    ];

    indicators.forEach(indicator => {
      // Calcular progreso actual y tendencia
      const progress2024 = getProgressPercentage(indicator.progress2024 || 0, indicator.target2024 || 0);
      const progress2025 = getProgressPercentage(indicator.progress2025 || 0, indicator.target2025 || 0);
      const currentProgress = getProgressPercentage(indicator.totalProgress || 0, indicator.totalTarget || 0);

      // Predicción de completitud basada en tendencia
      const growthRate = progress2025 > progress2024 ? (progress2025 - progress2024) : 0;
      const predictedCompletion = Math.min(currentProgress + (growthRate * 2), 150); // Proyección a 2 años

      // Clasificación de riesgo
      let risk: "bajo" | "medio" | "alto" = "bajo";
      if (currentProgress < 30) risk = "alto";
      else if (currentProgress < 70) risk = "medio";

      completionPredictions.push({
        code: indicator.code,
        name: indicator.name,
        currentProgress,
        predictedCompletion,
        risk,
        strategicLine: indicator.strategicLine
      });

      // Análisis de riesgo por línea estratégica
      if (!riskAnalysis[indicator.strategicLine]) {
        riskAnalysis[indicator.strategicLine] = {
          strategicLine: indicator.strategicLine,
          totalIndicators: 0,
          atRisk: 0,
          onTrack: 0,
          riskPercentage: 0
        };
      }
      
      riskAnalysis[indicator.strategicLine].totalIndicators++;
      if (risk === "alto") {
        riskAnalysis[indicator.strategicLine].atRisk++;
      } else {
        riskAnalysis[indicator.strategicLine].onTrack++;
      }

      // Acumular datos para análisis de tendencia
      trendAnalysis[0].actual += progress2024;
      trendAnalysis[1].actual += progress2025;
      trendAnalysis[2].projected += Math.max(progress2025 + growthRate, 0);
      trendAnalysis[3].projected += predictedCompletion;
    });

    // Calcular promedios y porcentajes de riesgo
    const indicatorCount = indicators.length;
    trendAnalysis.forEach(item => {
      item.actual = item.actual / indicatorCount;
      item.projected = item.projected / indicatorCount;
    });

    Object.keys(riskAnalysis).forEach(line => {
      const data = riskAnalysis[line];
      data.riskPercentage = (data.atRisk / data.totalIndicators) * 100;
    });

    return {
      completionPredictions: completionPredictions.sort((a, b) => a.currentProgress - b.currentProgress),
      riskAnalysis: Object.values(riskAnalysis).sort((a, b) => b.riskPercentage - a.riskPercentage),
      trendAnalysis,
      budgetProjections: [] // Placeholder for future implementation
    };
  }, [indicators]);

  const getRiskColor = (risk: "bajo" | "medio" | "alto") => {
    switch (risk) {
      case "alto": return "text-red-600 bg-red-50 dark:bg-red-900/20";
      case "medio": return "text-amber-600 bg-amber-50 dark:bg-amber-900/20";
      default: return "text-green-600 bg-green-50 dark:bg-green-900/20";
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white">
          Análisis Predictivo
        </h2>
        <select
          value={analysisType}
          onChange={(e) => setAnalysisType(e.target.value)}
          className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-800 dark:text-white"
        >
          <option value="completion">Predicción de Completitud</option>
          <option value="risk">Análisis de Riesgo</option>
          <option value="trends">Análisis de Tendencias</option>
        </select>
      </div>

      {analysisType === "completion" && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <h3 className="text-xl font-bold mb-4 dark:text-white">
              Predicción de Completitud de Indicadores
            </h3>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead className="bg-gray-50 dark:bg-gray-700">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      Código
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      Indicador
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      Progreso Actual
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      Predicción 2027
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                      Riesgo
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                  {predictiveData.completionPredictions.slice(0, 15).map((prediction) => (
                    <tr key={prediction.code}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                        {prediction.code}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-900 dark:text-white max-w-xs truncate">
                        {prediction.name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                        {formatNumberWithDecimals(prediction.currentProgress)}%
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                        {formatNumberWithDecimals(prediction.predictedCompletion)}%
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getRiskColor(prediction.risk)}`}>
                          {prediction.risk.toUpperCase()}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {analysisType === "risk" && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <h3 className="text-xl font-bold mb-4 dark:text-white">
              Análisis de Riesgo por Línea Estratégica
            </h3>
            <SimpleBarChart
              data={predictiveData.riskAnalysis.map(item => ({
                name: item.strategicLine.length > 30 ? item.strategicLine.substring(0, 27) + '...' : item.strategicLine,
                value: item.riskPercentage,
                color: item.riskPercentage > 50 ? '#EF4444' : item.riskPercentage > 25 ? '#F59E0B' : '#10B981'
              }))}
              height={400}
              xAxisLabel="Línea Estratégica"
              yAxisLabel="% Indicadores en Riesgo"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {predictiveData.riskAnalysis.map((risk) => (
              <div key={risk.strategicLine} className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4">
                <h4 className="font-medium text-gray-800 dark:text-white mb-2 truncate" title={risk.strategicLine}>
                  {risk.strategicLine}
                </h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Total:</span>
                    <span className="font-medium">{risk.totalIndicators}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-red-600 dark:text-red-400">En Riesgo:</span>
                    <span className="font-medium">{risk.atRisk}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-green-600 dark:text-green-400">En Tiempo:</span>
                    <span className="font-medium">{risk.onTrack}</span>
                  </div>
                  <div className="pt-2 border-t">
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">% Riesgo:</span>
                      <span className={`font-bold ${risk.riskPercentage > 50 ? 'text-red-600' : risk.riskPercentage > 25 ? 'text-amber-600' : 'text-green-600'}`}>
                        {formatNumberWithDecimals(risk.riskPercentage)}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {analysisType === "trends" && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <h3 className="text-xl font-bold mb-4 dark:text-white">
              Tendencias y Proyecciones
            </h3>
            <SimpleBarChart
              data={predictiveData.trendAnalysis.map(item => ({
                name: item.year,
                value: item.year <= "2025" ? item.actual : item.projected,
                color: item.year <= "2025" ? '#3B82F6' : '#8B5CF6'
              }))}
              height={400}
              xAxisLabel="Año"
              yAxisLabel="% Progreso Promedio"
            />
            <div className="mt-4 flex justify-center space-x-6 text-sm">
              <div className="flex items-center">
                <div className="w-3 h-3 bg-blue-500 rounded mr-2"></div>
                <span className="text-gray-600 dark:text-gray-400">Datos Reales</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 bg-purple-500 rounded mr-2"></div>
                <span className="text-gray-600 dark:text-gray-400">Proyecciones</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PredictionsView;
