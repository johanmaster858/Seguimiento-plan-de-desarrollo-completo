import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';

const ScrollToTop: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);

  // Detectar cuando el usuario ha hecho scroll
  useEffect(() => {
    const toggleVisibility = () => {
      if (window.pageYOffset > 300) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener('scroll', toggleVisibility);

    return () => window.removeEventListener('scroll', toggleVisibility);
  }, []);

  // Scroll a la parte superior
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <div className={`fixed bottom-5 right-5 transition-opacity duration-300 z-50 ${isVisible ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
      <Button
        className="rounded-full w-12 h-12 bg-green-600 hover:bg-green-700 text-white p-0 flex items-center justify-center shadow-lg"
        onClick={scrollToTop}
        aria-label="Volver arriba"
      >
        <span className="material-icons">keyboard_arrow_up</span>
      </Button>
    </div>
  );
};

export default ScrollToTop;