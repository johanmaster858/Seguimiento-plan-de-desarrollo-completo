import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Clock, User, FileText, TrendingUp, Database } from "lucide-react";

interface UpdateHistoryItem {
  id: number;
  indicatorCode: string;
  username: string;
  year?: string;
  field?: string;
  previousValue: number;
  newValue: number;
  observations?: string;
  description?: string;
  createdAt: string;
  timestamp?: string;
}

interface UpdateHistoryViewProps {
  className?: string;
}

const UpdateHistoryView: React.FC<UpdateHistoryViewProps> = ({ className }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [selectedIndicator, setSelectedIndicator] = useState('');
  const [limit, setLimit] = useState(50);

  // Fetch general update history
  const { data: generalHistory, isLoading: isGeneralLoading } = useQuery<UpdateHistoryItem[]>({
    queryKey: ['/api/history', limit],
    queryFn: async () => {
      const response = await fetch(`/api/history?limit=${limit}`, {
        credentials: 'include'
      });
      if (!response.ok) throw new Error('Failed to fetch history');
      return response.json();
    }
  });

  // Fetch indicator-specific history if an indicator is selected
  const { data: indicatorHistory, isLoading: isIndicatorLoading } = useQuery<UpdateHistoryItem[]>({
    queryKey: ['/api/history', selectedIndicator],
    queryFn: async () => {
      const response = await fetch(`/api/history/${selectedIndicator}`, {
        credentials: 'include'
      });
      if (!response.ok) throw new Error('Failed to fetch indicator history');
      return response.json();
    },
    enabled: !!selectedIndicator
  });

  // Fetch all indicators for filter dropdown
  const { data: indicators } = useQuery<any[]>({
    queryKey: ['/api/indicators'],
    queryFn: async () => {
      const response = await fetch('/api/indicators', {
        credentials: 'include'
      });
      if (!response.ok) throw new Error('Failed to fetch indicators');
      return response.json();
    }
  });

  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-ES', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatNumber = (num: number): string => {
    if (num === null || num === undefined) return '0';
    return num.toLocaleString('es-ES', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 2
    });
  };

  const getChangeType = (item: UpdateHistoryItem): string => {
    if (item.indicatorCode === 'BULK_IMPORT') return 'import';
    if (item.field === 'csv_import' || item.field === 'manual_import') return 'import';
    if (item.year) return 'progress';
    return 'other';
  };

  const getChangeIcon = (type: string) => {
    switch (type) {
      case 'import': return <Database className="h-4 w-4" />;
      case 'progress': return <TrendingUp className="h-4 w-4" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };

  const getChangeColor = (type: string) => {
    switch (type) {
      case 'import': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'progress': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
    }
  };

  const filteredHistory = (history: UpdateHistoryItem[] | undefined) => {
    if (!history) return [];
    
    return history.filter(item => {
      const matchesSearch = searchTerm === '' || 
        item.indicatorCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (item.observations && item.observations.toLowerCase().includes(searchTerm.toLowerCase()));
      
      const matchesType = filterType === 'all' || getChangeType(item) === filterType;
      
      return matchesSearch && matchesType;
    });
  };

  const HistoryTable = ({ history, isLoading }: { history: UpdateHistoryItem[] | undefined, isLoading: boolean }) => {
    if (isLoading) {
      return (
        <div className="flex items-center justify-center p-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="ml-2 text-gray-600 dark:text-gray-400">Cargando historial...</span>
        </div>
      );
    }

    const filtered = filteredHistory(history);

    if (filtered.length === 0) {
      return (
        <div className="text-center p-8 text-gray-500 dark:text-gray-400">
          <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
          <p>No se encontraron registros de historial</p>
        </div>
      );
    }

    return (
      <div className="space-y-4">
        {filtered.map((item) => {
          const changeType = getChangeType(item);
          return (
            <Card key={item.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3">
                    <div className={`p-2 rounded-full ${getChangeColor(changeType)}`}>
                      {getChangeIcon(changeType)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2 mb-1">
                        <Badge variant="outline" className="text-xs">
                          {item.indicatorCode}
                        </Badge>
                        <Badge className={`text-xs ${getChangeColor(changeType)}`}>
                          {changeType === 'import' ? 'Importación' : 
                           changeType === 'progress' ? 'Progreso' : 'Otro'}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-900 dark:text-gray-100">
                        {item.description || 
                         (item.indicatorCode === 'BULK_IMPORT' 
                          ? `Importación masiva de ${item.newValue} indicadores`
                          : `Actualización de ${item.year || 'campo'}: ${formatNumber(item.previousValue)} → ${formatNumber(item.newValue)}`)}
                      </p>
                      {item.observations && (
                        <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                          {item.observations}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="flex flex-col items-end text-xs text-gray-500 dark:text-gray-400">
                    <div className="flex items-center space-x-1">
                      <Clock className="h-3 w-3" />
                      <span>{formatDate(item.createdAt || item.timestamp || '')}</span>
                    </div>
                    <div className="flex items-center space-x-1 mt-1">
                      <User className="h-3 w-3" />
                      <span>{item.username}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    );
  };

  return (
    <div className={className}>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Clock className="h-5 w-5" />
            <span>Historial de Actualizaciones</span>
          </CardTitle>
          <CardDescription>
            Seguimiento completo de todas las modificaciones realizadas en el sistema
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Filters */}
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="flex-1">
              <Input
                placeholder="Buscar por código, usuario o observaciones..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
              />
            </div>
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="Filtrar por tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los tipos</SelectItem>
                <SelectItem value="import">Importaciones</SelectItem>
                <SelectItem value="progress">Actualizaciones</SelectItem>
              </SelectContent>
            </Select>
            <Select value={limit.toString()} onValueChange={(value) => setLimit(parseInt(value))}>
              <SelectTrigger className="w-full sm:w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="25">25</SelectItem>
                <SelectItem value="50">50</SelectItem>
                <SelectItem value="100">100</SelectItem>
                <SelectItem value="200">200</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Tabs defaultValue="general" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="general">Historial General</TabsTrigger>
              <TabsTrigger value="indicator">Por Indicador</TabsTrigger>
            </TabsList>
            
            <TabsContent value="general" className="mt-4">
              <HistoryTable history={generalHistory} isLoading={isGeneralLoading} />
            </TabsContent>
            
            <TabsContent value="indicator" className="mt-4">
              <div className="mb-4">
                <Select value={selectedIndicator} onValueChange={setSelectedIndicator}>
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar indicador específico..." />
                  </SelectTrigger>
                  <SelectContent>
                    {indicators?.map((indicator) => (
                      <SelectItem key={indicator.code} value={indicator.code}>
                        {indicator.code} - {indicator.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Separator className="my-4" />
              <HistoryTable history={indicatorHistory} isLoading={isIndicatorLoading} />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default UpdateHistoryView;