import React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Legend
} from "recharts";
import { getStrategicLineColor } from "@/lib/utils";

// Interfaces para los diferentes tipos de gráficos
interface BarChartProps {
  data: Array<{
    name: string;
    value: number;
    color?: string;
  }>;
  xAxisLabel?: string;
  yAxisLabel?: string;
  height?: number;
}

interface LineChartProps {
  data: Array<{
    name: string;
    actual: number;
    target: number;
  }>;
  xAxisLabel?: string;
  yAxisLabel?: string;
  height?: number;
}

interface PieChartProps {
  data: Array<{
    name: string;
    value: number;
    color: string;
  }>;
  height?: number;
}

interface HeatMapProps {
  data: Array<{
    strategicLine: string;
    program: string;
    value: number;
    count: number;
  }>;
  title?: string;
  description?: string;
  height?: number;
}

interface StrategicLineBarChartProps {
  data: Array<{
    name: string;
    percentage: number;
  }>;
  height?: number;
}

// Componentes de gráficos
export const SimpleBarChart: React.FC<BarChartProps> = ({
  data,
  xAxisLabel,
  yAxisLabel,
  height = 300
}) => {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart
        data={data}
        margin={{
          top: 5,
          right: 30,
          left: 20,
          bottom: 30,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis
          dataKey="name"
          label={{
            value: xAxisLabel,
            position: 'insideBottom',
            offset: -15
          }}
        />
        <YAxis
          label={{
            value: yAxisLabel,
            angle: -90,
            position: 'insideLeft'
          }}
        />
        <Tooltip
          formatter={(value: number) => [`${value.toFixed(1)}`, '']}
        />
        <Bar dataKey="value">
          {data.map((entry, index) => (
            <Cell
              key={`cell-${index}`}
              fill={entry.color || `#${Math.floor(Math.random()*16777215).toString(16)}`}
            />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
};

export const SimpleLineChart: React.FC<LineChartProps> = ({
  data,
  xAxisLabel,
  yAxisLabel,
  height = 300
}) => {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart
        data={data}
        margin={{
          top: 5,
          right: 30,
          left: 20,
          bottom: 30,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis
          dataKey="name"
          label={{
            value: xAxisLabel,
            position: 'insideBottom',
            offset: -15
          }}
        />
        <YAxis
          label={{
            value: yAxisLabel,
            angle: -90,
            position: 'insideLeft'
          }}
        />
        <Tooltip formatter={(value: number) => [`${value.toFixed(1)}%`, '']} />
        <Legend />
        <Line
          type="monotone"
          dataKey="actual"
          stroke="#2563EB"
          activeDot={{ r: 8 }}
          name="Avance"
        />
        <Line
          type="monotone"
          dataKey="target"
          stroke="#9CA3AF"
          strokeDasharray="5 5"
          name="Meta"
        />
      </LineChart>
    </ResponsiveContainer>
  );
};

export const SimplePieChart: React.FC<PieChartProps> = ({
  data,
  height = 300
}) => {
  const totalValue = data.reduce((sum, entry) => sum + entry.value, 0);

  return (
    <ResponsiveContainer width="100%" height={height}>
      <PieChart>
        <Pie
          data={data}
          cx="50%"
          cy="50%"
          labelLine={false}
          outerRadius={80}
          fill="#8884d8"
          dataKey="value"
          nameKey="name"
          label={({ name, percent }: any) => `${name}: ${(percent * 100).toFixed(1)}%`}
        >
          {data.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={entry.color} />
          ))}
        </Pie>
        <Tooltip
          formatter={(value: number) => [`${value} (${((value / totalValue) * 100).toFixed(1)}%)`, '']}
        />
      </PieChart>
    </ResponsiveContainer>
  );
};

export const StrategicLineBarChart: React.FC<StrategicLineBarChartProps> = ({
  data,
  height = 300
}) => {

  const formattedData = data.map(item => ({
    name: item.name.length > 25 ? `${item.name.substring(0, 22)}...` : item.name,
    value: item.percentage,
    fullName: item.name,
    color: getStrategicLineColor(item.name) // Usar la función importada
  }));

  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart
        data={formattedData}
        layout="vertical"
        margin={{
          top: 5,
          right: 30,
          left: 20,
          bottom: 5,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis type="number" domain={[0, 100]} />
        <YAxis dataKey="name" type="category" width={150} />
        <Tooltip
          formatter={(value: number, name: string, props: any) => {
            return [`${value.toFixed(1)}%`, props.payload.fullName];
          }}
        />
        <Bar dataKey="value">
          {formattedData.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={entry.color} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
};

// Gráfico específico para estados de indicadores
export const StatusPieChart: React.FC<{
  data: Array<{name: string; value: number; color: string}>;
  height?: number;
}> = ({ data, height = 300 }) => {
  return <SimplePieChart data={data} height={height} />;
};

// Gráfico específico para mostrar el progreso anual
export const YearlyProgressLineChart: React.FC<{
  data: Array<{name: string; actual: number; target: number}>;
  height?: number;
}> = ({ data, height = 300 }) => {
  return (
    <SimpleLineChart
      data={data}
      xAxisLabel="Año"
      yAxisLabel="Avance (%)"
      height={height}
    />
  );
};

// Componente de mapa de calor para avances por línea estratégica y programa
export const HeatMapChart: React.FC<HeatMapProps> = ({
  data,
  title = "Avances PDD por programa",
  description = "Visualización del porcentaje de avance por línea estratégica y programa",
  height = 600
}) => {
  const [selectedCard, setSelectedCard] = React.useState<string | null>(null);
  const [tooltipInfo, setTooltipInfo] = React.useState<{
    x: number;
    y: number;
    content: React.ReactNode;
  } | null>(null);

  // Ordenar los datos por línea estratégica
  const sortedData = [...data].sort((a, b) => {
    // Primero por línea estratégica
    if (a.strategicLine !== b.strategicLine) {
      return a.strategicLine.localeCompare(b.strategicLine);
    }
    // Luego por valor (para que los programas con más avance aparezcan primero)
    return b.value - a.value;
  });

  // Obtener colores según la línea estratégica
  const getBackgroundColor = (strategicLine: string) => {
    return getStrategicLineColor(strategicLine);
  };

  // Obtener el color del texto según el fondo (para asegurar contraste)
  const getTextColor = (bgColor: string) => {
    // Convertir color hex a RGB
    const r = parseInt(bgColor.slice(1, 3), 16);
    const g = parseInt(bgColor.slice(3, 5), 16);
    const b = parseInt(bgColor.slice(5, 7), 16);

    // Calcular luminosidad
    const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;

    // Retornar blanco para fondos oscuros y negro para fondos claros
    return luminance > 0.5 ? "#000000" : "#FFFFFF";
  };

  // Determinar el tamaño de cada celda en función del valor y cantidad de indicadores
  const getCellSize = (value: number, count: number) => {
    // Base size
    let baseSize = 120;

    // Ajustar según la cantidad de indicadores (para reflejar importancia)
    if (count > 10) baseSize += 60;
    else if (count > 5) baseSize += 30;

    return baseSize;
  };

  // Clasificar el avance en categorías
  const getProgressCategory = (value: number) => {
    if (value >= 90) return "Avanzado";
    if (value >= 70) return "En tiempo";
    if (value > 0) return "Retrasado";
    return "Sin avance";
  };

  // Obtener el color para la categoría de avance
  const getCategoryColor = (category: string) => {
    switch(category) {
      case "Avanzado": return "text-green-600 dark:text-green-500";
      case "En tiempo": return "text-amber-600 dark:text-amber-500";
      case "Retrasado": return "text-red-600 dark:text-red-500";
      case "Sin avance": return "text-gray-600 dark:text-gray-400";
      default: return "text-gray-600 dark:text-gray-400";
    }
  };

  // Agrupar por línea estratégica
  const groupedByLine = sortedData.reduce((acc, item) => {
    if (!acc[item.strategicLine]) {
      acc[item.strategicLine] = [];
    }
    acc[item.strategicLine].push(item);
    return acc;
  }, {} as Record<string, typeof data>);

  // Obtener las líneas estratégicas ordenadas
  const strategicLines = Object.keys(groupedByLine);

  // Manejar el hover sobre las tarjetas
  const handleMouseEnter = (
    e: React.MouseEvent<HTMLDivElement>,
    item: (typeof data)[0]
  ) => {
    const rect = e.currentTarget.getBoundingClientRect();

    setTooltipInfo({
      x: rect.left + window.scrollX,
      y: rect.top + window.scrollY,
      content: (
        <div className="p-3 max-w-sm">
          <div className="font-bold text-lg mb-1">{item.program}</div>
          <div className="flex justify-between mb-1 text-sm">
            <span className="text-gray-600 dark:text-gray-300">Línea estratégica:</span>
            <span className="font-medium">{item.strategicLine}</span>
          </div>
          <div className="flex justify-between mb-1 text-sm">
            <span className="text-gray-600 dark:text-gray-300">Avance promedio:</span>
            <span className="font-medium">{item.value.toFixed(1)}%</span>
          </div>
          <div className="flex justify-between mb-1 text-sm">
            <span className="text-gray-600 dark:text-gray-300">Indicadores:</span>
            <span className="font-medium">{item.count}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-600 dark:text-gray-300">Estado:</span>
            <span className={`font-medium ${getCategoryColor(getProgressCategory(item.value))}`}>
              {getProgressCategory(item.value)}
            </span>
          </div>
        </div>
      )
    });
  };

  const handleMouseLeave = () => {
    setTooltipInfo(null);
  };

  // Manejar click en las tarjetas
  const handleCardClick = (cardId: string) => {
    setSelectedCard(selectedCard === cardId ? null : cardId);
  };

  return (
    <div className="flex flex-col w-full h-full" style={{ height: height }}>
      <h2 className="text-xl text-center font-bold mb-2 dark:text-white">{title}</h2>
      {description && <p className="text-sm text-center text-gray-500 dark:text-gray-400 mb-4">{description}</p>}

      <div className="overflow-x-auto overflow-y-auto">
        <div className="flex flex-wrap w-full">
          {strategicLines.map((line) => (
            <div key={line} className="flex flex-col w-full mb-6">
              <div
                className="text-center font-bold py-2 px-4 mb-3 rounded-md shadow-sm transition-all"
                style={{
                  backgroundColor: getBackgroundColor(line),
                  color: getTextColor(getBackgroundColor(line))
                }}
              >
                {line}
              </div>
              <div className="flex flex-wrap justify-center">
                {groupedByLine[line].map((item, idx) => {
                  const bgColor = getBackgroundColor(item.strategicLine);
                  const textColor = getTextColor(bgColor);
                  const size = getCellSize(item.value, item.count);
                  const cardId = `${item.strategicLine}-${item.program}-${idx}`;
                  const isSelected = selectedCard === cardId;

                  // Ajustar la opacidad en función del valor (mayor valor = mayor opacidad)
                  const opacity = 0.3 + (item.value / 140);
                  const category = getProgressCategory(item.value);

                  return (
                    <div
                      key={cardId}
                      className={`m-2 p-3 flex flex-col justify-center items-center rounded-lg overflow-hidden cursor-pointer transition-all duration-200 shadow-md hover:shadow-lg
                        ${isSelected ? 'ring-2 ring-offset-2' : ''}`}
                      style={{
                        backgroundColor: bgColor,
                        color: textColor,
                        opacity: isSelected ? 1 : opacity,
                        width: isSelected ? size * 1.1 : size,
                        height: isSelected ? size * 1.1 : size,
                        transform: isSelected ? 'scale(1.05)' : 'scale(1)',
                        zIndex: isSelected ? 10 : 1,
                      }}
                      onClick={() => handleCardClick(cardId)}
                      onMouseEnter={(e) => handleMouseEnter(e, item)}
                      onMouseLeave={handleMouseLeave}
                    >
                      <div className="text-center font-medium mb-2 overflow-hidden text-ellipsis">
                        {item.program}
                      </div>
                      <div className="text-2xl font-bold flex items-center">
                        {item.value.toFixed(1)}%
                        {item.value >= 90 && <span className="material-icons ml-1 text-lg">star</span>}
                      </div>
                      <div className={`text-sm mt-2 font-medium ${getCategoryColor(category)}`}>
                        {category}
                      </div>
                      <div className="text-xs mt-1">({item.count} indicadores)</div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Tooltip detallado */}
      {tooltipInfo && (
        <div
          className="fixed bg-white dark:bg-gray-800 rounded-lg shadow-lg p-3 border border-gray-200 dark:border-gray-700 z-50"
          style={{
            left: `${tooltipInfo.x}px`,
            top: `${tooltipInfo.y - 150}px`,
            pointerEvents: 'none'
          }}
        >
          {tooltipInfo.content}
        </div>
      )}
    </div>
  );
};