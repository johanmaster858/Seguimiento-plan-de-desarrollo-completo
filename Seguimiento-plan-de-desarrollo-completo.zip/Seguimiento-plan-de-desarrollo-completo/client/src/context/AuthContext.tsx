import React, { createContext, useContext, useState, useCallback, useEffect } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface AuthContextType {
  isAuthenticated: boolean;
  isAdmin: boolean;
  user: User | null;
  login: (username: string, password: string, rememberMe: boolean) => Promise<void>;
  logout: () => Promise<void>;
  checkAuth: () => Promise<void>;
}

interface User {
  id: number;
  username: string;
  isAdmin: boolean;
}

const AuthContext = createContext<AuthContextType>({
  isAuthenticated: false,
  isAdmin: false,
  user: null,
  login: async () => {},
  logout: async () => {},
  checkAuth: async () => {},
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const { toast } = useToast();
  
  // Initialize auth on component mount
  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = useCallback(async () => {
    try {
      // Verificar con el servidor si hay sesión activa
      const response = await fetch('/api/auth/me', {
        credentials: 'include',
        headers: {
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache'
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        if (data.authenticated) {
          setIsAuthenticated(true);
          setUser(data.user);
          setIsAdmin(data.user.isAdmin);
          return;
        }
      }
      
      // Si no hay sesión del servidor, verificar localStorage
      const storedAuthData = localStorage.getItem('auth');
      if (storedAuthData) {
        const authData = JSON.parse(storedAuthData);
        setIsAuthenticated(true);
        setUser(authData);
        setIsAdmin(authData.isAdmin);
      } else {
        setIsAuthenticated(false);
        setIsAdmin(false);
        setUser(null);
      }
    } catch (error) {
      console.error('Error checking authentication:', error);
      setIsAuthenticated(false);
      setIsAdmin(false);
      setUser(null);
    }
  }, []);

  const login = async (username: string, password: string, rememberMe: boolean) => {
    try {
      // Hacer petición al servidor para autenticación
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
        credentials: 'include'
      });
      
      if (response.ok) {
        const userData = await response.json();
        
        setIsAuthenticated(true);
        setUser(userData);
        setIsAdmin(userData.isAdmin);
        
        // Si el usuario marcó "recordarme", guardar en localStorage
        if (rememberMe) {
          localStorage.setItem('auth', JSON.stringify(userData));
        }
        
        toast({
          title: "Inicio de sesión exitoso",
          description: `Bienvenido, ${userData.username}`,
        });
        
        return;
      } else {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Credenciales inválidas');
      }
    } catch (error) {
      console.error('Login error:', error);
      throw new Error('Credenciales inválidas. Por favor verifique su usuario y contraseña.');
    }
  };

  const logout = async () => {
    try {
      // Cerrar sesión en el servidor
      await fetch('/api/auth/logout', {
        method: 'POST',
        credentials: 'include'
      });
      
      // Limpiar el estado local y eliminar datos de localStorage
      setIsAuthenticated(false);
      setIsAdmin(false);
      setUser(null);
      
      // Eliminar los datos de sesión del localStorage
      localStorage.removeItem('auth');
      
      toast({
        title: "Sesión cerrada",
        description: "Ha cerrado sesión exitosamente.",
      });
    } catch (error) {
      console.error('Logout error:', error);
      toast({
        title: "Error",
        description: "No se pudo cerrar la sesión. Intente nuevamente.",
        variant: "destructive",
      });
    }
  };

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        isAdmin,
        user,
        login,
        logout,
        checkAuth,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
