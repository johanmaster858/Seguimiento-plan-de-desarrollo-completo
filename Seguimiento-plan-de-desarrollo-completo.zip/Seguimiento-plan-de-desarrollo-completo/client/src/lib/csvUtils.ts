
import { InsertIndicator } from "@shared/schema";

// Parse CSV data into indicators using the updated file format
export function parse(csvData: string): InsertIndicator[] {
  const indicators: InsertIndicator[] = [];

  if (!csvData || csvData.trim().length === 0) {
    throw new Error('El archivo CSV está vacío o no contiene datos válidos.');
  }

  // Parse CSV content properly handling quoted fields with line breaks
  const rows = parseCSVContent(csvData);
  
  if (rows.length < 2) {
    throw new Error('El archivo CSV debe contener al menos una fila de datos.');
  }

  // Get headers from first row for dynamic mapping
  const headers = rows[0];
  console.log('Headers detectados:', headers);

  // Create dynamic column mapping based on header names
  const findColumnIndex = (possibleNames: string[]): number => {
    for (const name of possibleNames) {
      const index = headers.findIndex(header => 
        header && header.toLowerCase().trim() === name.toLowerCase().trim()
      );
      if (index !== -1) return index;
    }
    return -1;
  };

  // Dynamic column mapping with multiple possible names - ACTUALIZADO PARA NUEVO FORMATO
  const columnIndices = {
    code: findColumnIndex(['Codigo', 'Code', 'Código']),
    bpim: findColumnIndex(['BPIM', 'Bpim', 'BPM']),
    responsible: findColumnIndex(['Responsable', 'Resposable', 'Responsible']),
    strategicLine: findColumnIndex(['Linea estrategica', 'Línea estratégica', 'Strategic Line']),
    program: findColumnIndex(['Programa', 'Program']),
    sector: findColumnIndex(['Sector', 'Sectors']),
    ods: findColumnIndex(['ODS', 'Ods', 'Objetivo de Desarrollo Sostenible']),
    name: findColumnIndex(['Indicadores', 'Indicators', 'Name', 'Nombre']),
    description: findColumnIndex(['Descripcion', 'Descripción', 'Description']),
    unit: findColumnIndex(['Unidad', 'Unit']),
    totalTarget: findColumnIndex(['Cantidad Cuatrenio', 'Cantidad Cuatrienio', 'Total Target']),
    target2024: findColumnIndex(['Meta 2024', 'Target 2024']),
    progress2024: findColumnIndex(['Avance 2024', 'Progress 2024']),
    target2025: findColumnIndex(['Meta 2025', 'Target 2025']),
    progress2025: findColumnIndex(['Avance 2025', 'Progress 2025']),
    target2026: findColumnIndex(['Meta 2026', 'Target 2026']),
    progress2026: findColumnIndex(['Avance 2026', 'Progress 2026']),
    target2027: findColumnIndex(['Meta 2027', 'Target 2027']),
    progress2027: findColumnIndex(['Avance 2027', 'Progress 2027']),
    totalProgress: findColumnIndex(['Avance acumulado', 'Avance Acumulado', 'Total Progress']),
    initialBudget2024: findColumnIndex(['Presupuesto inicial 2024', 'Presupuesto Inicial 2024', 'Initial Budget 2024']),
    finalBudget2024: findColumnIndex(['Presupuesto Final 2024', 'Final Budget 2024']),
    initialBudget2025: findColumnIndex(['Presupuesto inicial 2025', 'Presupuesto Inicial 2025', 'Initial Budget 2025']),
    finalBudget2025: findColumnIndex(['Presupuesto Final 2025', 'Final Budget 2025']),
    initialBudget2026: findColumnIndex(['Presupuesto inicial 2026', 'Presupuesto Inicial 2026', 'Initial Budget 2026']),
    finalBudget2026: findColumnIndex(['Presupuesto Final 2026', 'Final Budget 2026']),
    initialBudget2027: findColumnIndex(['Presupuesto inicial 2027', 'Presupuesto Inicial 2027', 'Initial Budget 2027']),
    finalBudget2027: findColumnIndex(['Presupuesto final 2027', 'Presupuesto Final 2027', 'Final Budget 2027']),
    totalInitialBudget: findColumnIndex(['Presupuesto Inicial Total', 'Total Initial Budget']),
    totalFinalBudget: findColumnIndex(['Presupuesto Final Total', 'Total Final Budget'])
  };

  // Log column mapping for debugging
  console.log('Mapeo de columnas:', columnIndices);

  // Enhanced function to determine responsible based on BPIM code with better mapping
  const getResponsibleFromBPIM = (bpimValue: string, originalResponsible: string): string => {
    // First try to use original responsible if it has meaningful data
    if (originalResponsible && originalResponsible.trim() && 
        originalResponsible.trim() !== '0' && 
        originalResponsible.trim().toLowerCase() !== 'null') {
      return originalResponsible.trim();
    }

    // Otherwise use BPIM mapping
    const bpim = bpimValue.trim();
    switch(bpim) {
      case '11111':
        return 'Desarrollo Economico';
      case '22222':
        return 'Proteccion Social';
      case '33333':
        return 'Educacion';
      case '44444':
        return 'Planeacion';
      case '55555':
        return 'Gobierno';
      default:
        return 'Administracion Municipal';
    }
  };

  console.log('Estructura de columnas mapeada correctamente');

  // Skip header row and process data
  for (let i = 1; i < rows.length; i++) {
    const row = rows[i];
    
    // Skip empty rows
    if (!row || row.length === 0 || row.every(cell => !cell || cell.trim() === '')) {
      continue;
    }

    try {
      // Helper function to safely get column value
      const getColumnValue = (index: number): string => {
        return index !== -1 && row[index] ? row[index].trim() : '';
      };

      // Extract values using dynamic column positions
      const code = getColumnValue(columnIndices.code);
      const bpimValue = getColumnValue(columnIndices.bpim);
      const originalResponsible = getColumnValue(columnIndices.responsible);
      const strategicLine = getColumnValue(columnIndices.strategicLine);
      const program = getColumnValue(columnIndices.program);
      const sector = getColumnValue(columnIndices.sector);
      const odsValue = getColumnValue(columnIndices.ods);
      const name = getColumnValue(columnIndices.name);
      
      // Determine responsible with enhanced logic
      const responsible = getResponsibleFromBPIM(bpimValue, originalResponsible);
      
      // Keep BPIM as string to handle large numbers correctly
      const bpim = bpimValue && bpimValue.trim() !== '' && bpimValue !== '0' ? bpimValue.trim() : undefined;
      
      // Parse ODS value more carefully
      let ods: number | undefined = undefined;
      if (odsValue && odsValue !== '' && odsValue !== '0' && !isNaN(Number(odsValue))) {
        const parsed = parseInt(odsValue, 10);
        if (parsed > 0) ods = parsed;
      }
      
      // Clean sector value
      const cleanSector = sector && sector !== '' && sector !== '0' ? sector : undefined;
      
      console.log(`Procesando indicador ${code}: BPIM=${bpim}, Sector="${cleanSector}", ODS=${ods}, Responsable="${responsible}"`);
      
      // Validate required fields - now responsible is always determined
      if (!code || !responsible || !strategicLine || !program || !name) {
        console.warn(`Row ${i + 1}: Missing required fields (code: "${code}", responsible: "${responsible}", strategicLine: "${strategicLine}", program: "${program}", name: "${name}"), skipping`);
        continue;
      }
      
      const indicator: InsertIndicator = {
        code,
        bpim: bpim,
        responsible,
        strategicLine,
        program,
        sector: cleanSector,
        ods: ods,
        name,
        description: getColumnValue(columnIndices.description),
        unit: getColumnValue(columnIndices.unit),
        
        // Quantity and targets with safe parsing
        totalTarget: parseNumericValue(getColumnValue(columnIndices.totalTarget)),
        target2024: parseNumericValue(getColumnValue(columnIndices.target2024)),
        progress2024: parseNumericValue(getColumnValue(columnIndices.progress2024)),
        target2025: parseNumericValue(getColumnValue(columnIndices.target2025)),
        progress2025: parseNumericValue(getColumnValue(columnIndices.progress2025)),
        target2026: parseNumericValue(getColumnValue(columnIndices.target2026)),
        progress2026: parseNumericValue(getColumnValue(columnIndices.progress2026)),
        target2027: parseNumericValue(getColumnValue(columnIndices.target2027)),
        progress2027: parseNumericValue(getColumnValue(columnIndices.progress2027)),
        totalProgress: parseNumericValue(getColumnValue(columnIndices.totalProgress)),
        
        // Budget data with safe parsing
        initialBudget2024: parseBudgetValue(getColumnValue(columnIndices.initialBudget2024)),
        finalBudget2024: parseBudgetValue(getColumnValue(columnIndices.finalBudget2024)),
        initialBudget2025: parseBudgetValue(getColumnValue(columnIndices.initialBudget2025)),
        finalBudget2025: parseBudgetValue(getColumnValue(columnIndices.finalBudget2025)),
        initialBudget2026: parseBudgetValue(getColumnValue(columnIndices.initialBudget2026)),
        finalBudget2026: parseBudgetValue(getColumnValue(columnIndices.finalBudget2026)),
        initialBudget2027: parseBudgetValue(getColumnValue(columnIndices.initialBudget2027)),
        finalBudget2027: parseBudgetValue(getColumnValue(columnIndices.finalBudget2027)),
        
        // Calculate totals from parsed values
        totalInitialBudget: parseBudgetValue(getColumnValue(columnIndices.totalInitialBudget)) || 
                           (parseBudgetValue(getColumnValue(columnIndices.initialBudget2024)) + 
                            parseBudgetValue(getColumnValue(columnIndices.initialBudget2025)) + 
                            parseBudgetValue(getColumnValue(columnIndices.initialBudget2026)) + 
                            parseBudgetValue(getColumnValue(columnIndices.initialBudget2027))),
        
        totalFinalBudget: parseBudgetValue(getColumnValue(columnIndices.totalFinalBudget)) ||
                         (parseBudgetValue(getColumnValue(columnIndices.finalBudget2024)) + 
                          parseBudgetValue(getColumnValue(columnIndices.finalBudget2025)) + 
                          parseBudgetValue(getColumnValue(columnIndices.finalBudget2026)) + 
                          parseBudgetValue(getColumnValue(columnIndices.finalBudget2027)))
      };

      indicators.push(indicator);
    } catch (error) {
      console.error(`Error parsing row ${i + 1}:`, error);
      continue;
    }
  }

  console.log(`Successfully parsed ${indicators.length} indicators`);
  return indicators;
}

export function stringify(indicators: any[]): string {
  const headers = [
    "Codigo", "BPIM", "Responsable", "Linea estrategica", "Programa", "Sector", "ODS", 
    "Indicadores", "Descripcion", "Unidad", "Cantidad Cuatrenio",
    "Meta 2024", "Avance 2024", "Meta 2025", "Avance 2025", 
    "Meta 2026", "Avance 2026", "Meta 2027", "Avance 2027", "Avance acumulado",
    "Presupuesto inicial 2024", "Presupuesto Final 2024",
    "Presupuesto inicial 2025", "Presupuesto Final 2025",
    "Presupuesto inicial 2026", "Presupuesto Final 2026",
    "Presupuesto inicial 2027", "Presupuesto final 2027", "Presupuesto Final Total"
  ].join(",");

  const rows = indicators.map(indicator => [
    escapeCSV(indicator.code),
    escapeCSV(indicator.bpim || ''),
    escapeCSV(indicator.responsible),
    escapeCSV(indicator.strategicLine),
    escapeCSV(indicator.program),
    escapeCSV(indicator.sector || ''),
    indicator.ods || '',
    escapeCSV(indicator.name),
    escapeCSV(indicator.description || ''),
    escapeCSV(indicator.unit || ''),
    indicator.totalTarget || 0,
    indicator.target2024 || 0,
    indicator.progress2024 || 0,
    indicator.target2025 || 0,
    indicator.progress2025 || 0,
    indicator.target2026 || 0,
    indicator.progress2026 || 0,
    indicator.target2027 || 0,
    indicator.progress2027 || 0,
    indicator.totalProgress || 0,
    formatBudgetForCSV(indicator.initialBudget2024),
    formatBudgetForCSV(indicator.finalBudget2024),
    formatBudgetForCSV(indicator.initialBudget2025),
    formatBudgetForCSV(indicator.finalBudget2025),
    formatBudgetForCSV(indicator.initialBudget2026),
    formatBudgetForCSV(indicator.finalBudget2026),
    formatBudgetForCSV(indicator.initialBudget2027),
    formatBudgetForCSV(indicator.finalBudget2027),
    formatBudgetForCSV(indicator.totalFinalBudget)
  ].join(","));

  const csv = [headers, ...rows].join("\n");
  
  return csv;
}

// Helper function to format budget values for CSV output
function formatBudgetForCSV(value: number | undefined | null): string {
  if (!value || value === 0) return '$0';
  return `"$${value.toLocaleString()}"`;
}

// Helper function to parse budget values (removes currency formatting)
function parseBudgetValue(value: string): number {
  if (!value || value === '' || value === '$0' || value === '0') return 0;
  
  // Remove currency symbols, commas, quotes, spaces, dollar signs, and any other non-numeric chars except decimal points
  const cleanValue = value.replace(/[^0-9.-]/g, '');
  
  if (cleanValue === '' || cleanValue === '-') return 0;
  
  const numericValue = parseFloat(cleanValue);
  
  return isNaN(numericValue) ? 0 : Math.abs(numericValue); // Ensure positive values
}

function escapeCSV(value: string): string {
  if (value.includes(',') || value.includes('"') || value.includes('\n')) {
    return '"' + value.replace(/"/g, '""') + '"';
  }
  return value;
}

// Enhanced CSV parsing that handles multi-line fields properly
function parseCSVContent(csvData: string): string[][] {
  const rows: string[][] = [];
  const lines = csvData.split('\n');
  let currentRow: string[] = [];
  let currentField = '';
  let inQuotes = false;
  let rowStarted = false;
  
  for (let lineIndex = 0; lineIndex < lines.length; lineIndex++) {
    const line = lines[lineIndex];
    
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      
      if (char === '"') {
        if (inQuotes && i + 1 < line.length && line[i + 1] === '"') {
          // Escaped quote
          currentField += '"';
          i++; // Skip next quote
        } else {
          inQuotes = !inQuotes;
        }
      } else if (char === ',' && !inQuotes) {
        // End of field
        currentRow.push(currentField.trim());
        currentField = '';
        rowStarted = true;
      } else {
        currentField += char;
      }
    }
    
    if (inQuotes) {
      // Multi-line field continues
      currentField += '\n';
    } else {
      // End of row
      if (rowStarted || currentField.trim()) {
        currentRow.push(currentField.trim());
        rows.push(currentRow);
        currentRow = [];
        currentField = '';
        rowStarted = false;
      }
    }
  }
  
  // Handle last row if not processed
  if (currentRow.length > 0 || currentField.trim()) {
    currentRow.push(currentField.trim());
    rows.push(currentRow);
  }
  
  return rows;
}

// Safe numeric value parsing
function parseNumericValue(value: string | undefined): number {
  if (!value || value.trim() === '') return 0;
  
  const cleanValue = value.replace(/[^\d.-]/g, '');
  const numericValue = parseFloat(cleanValue);
  
  return isNaN(numericValue) ? 0 : numericValue;
}
