import { Indicator } from "@shared/schema";
import { getStatusForIndicator } from "./utils";

/**
 * Calculate aggregate statistics for strategic lines
 */
export function calculateStrategicLineStats(indicators: Indicator[], year: string) {
  // Group indicators by strategic line
  const lineStats: Record<string, { 
    count: number; 
    progress: number; 
    target: number;
    advanced: number;
    onTime: number;
    delayed: number;
  }> = {};

  indicators.forEach(indicator => {
    const strategicLine = indicator.strategicLine;
    
    if (!lineStats[strategicLine]) {
      lineStats[strategicLine] = { 
        count: 0, 
        progress: 0, 
        target: 0,
        advanced: 0,
        onTime: 0,
        delayed: 0
      };
    }
    
    let targetValue = 0;
    let progressValue = 0;
    
    // Get values based on selected year
    switch(year) {
      case "2024":
        targetValue = indicator.target2024;
        progressValue = indicator.progress2024;
        break;
      case "2025":
        targetValue = indicator.target2025;
        progressValue = indicator.progress2025;
        break;
      case "2026":
        targetValue = indicator.target2026;
        progressValue = indicator.progress2026;
        break;
      case "2027":
        targetValue = indicator.target2027;
        progressValue = indicator.progress2027;
        break;
      default:
        targetValue = indicator.totalTarget;
        progressValue = indicator.totalProgress;
    }
    
    // Update statistics
    lineStats[strategicLine].count++;
    lineStats[strategicLine].target += targetValue;
    lineStats[strategicLine].progress += progressValue;
    
    // Classify by status
    const status = getStatusForIndicator(indicator, year);
    if (status === "avanzado") {
      lineStats[strategicLine].advanced++;
    } else if (status === "en-tiempo") {
      lineStats[strategicLine].onTime++;
    } else {
      lineStats[strategicLine].delayed++;
    }
  });
  
  return lineStats;
}

/**
 * Calculate yearly progress and projects
 */
export function calculateYearlyProgress(indicators: Indicator[]) {
  // Initialize yearly totals
  const yearlyData = {
    "2024": { target: 0, actual: 0 },
    "2025": { target: 0, actual: 0 },
    "2026": { target: 0, actual: 0 },
    "2027": { target: 0, actual: 0 }
  };
  
  indicators.forEach(indicator => {
    // Add up yearly targets and actuals
    yearlyData["2024"].target += indicator.target2024;
    yearlyData["2024"].actual += indicator.progress2024;
    
    yearlyData["2025"].target += indicator.target2025;
    yearlyData["2025"].actual += indicator.progress2025;
    
    yearlyData["2026"].target += indicator.target2026;
    yearlyData["2026"].actual += indicator.progress2026;
    
    yearlyData["2027"].target += indicator.target2027;
    yearlyData["2027"].actual += indicator.progress2027;
  });
  
  // Convert to percentages for visualization
  const yearlyProgress = [
    { 
      name: "2024", 
      actual: yearlyData["2024"].target > 0 
        ? (yearlyData["2024"].actual / yearlyData["2024"].target) * 100 
        : 0,
      target: 25
    },
    { 
      name: "2025", 
      actual: yearlyData["2025"].target > 0 
        ? (yearlyData["2025"].actual / yearlyData["2025"].target) * 100 
        : 0, 
      target: 50 
    },
    { 
      name: "2026", 
      actual: yearlyData["2026"].target > 0 
        ? (yearlyData["2026"].actual / yearlyData["2026"].target) * 100 
        : 0, 
      target: 75 
    },
    { 
      name: "2027", 
      actual: yearlyData["2027"].target > 0 
        ? (yearlyData["2027"].actual / yearlyData["2027"].target) * 100 
        : 0, 
      target: 100 
    }
  ];
  
  return yearlyProgress;
}

/**
 * Get all unique values for a specific field from indicators
 */
export function getUniqueValues(indicators: Indicator[], field: keyof Indicator): string[] {
  const values = new Set<string>();
  
  indicators.forEach(indicator => {
    const value = indicator[field];
    if (typeof value === 'string') {
      values.add(value);
    }
  });
  
  return Array.from(values).sort();
}

/**
 * Calculate indicator status counts
 */
export function calculateStatusCounts(indicators: Indicator[], year: string) {
  let advancedCount = 0;
  let onTimeCount = 0;
  let delayedCount = 0;
  
  indicators.forEach(indicator => {
    const status = getStatusForIndicator(indicator, year);
    
    if (status === "avanzado") {
      advancedCount++;
    } else if (status === "en-tiempo") {
      onTimeCount++;
    } else {
      delayedCount++;
    }
  });
  
  return { advancedCount, onTimeCount, delayedCount };
}

/**
 * Filter indicators based on search criteria
 */
export function searchIndicators(indicators: Indicator[], searchTerm: string): Indicator[] {
  if (!searchTerm) return indicators;
  
  const lowerSearchTerm = searchTerm.toLowerCase();
  
  return indicators.filter(indicator => 
    indicator.code.toLowerCase().includes(lowerSearchTerm) ||
    indicator.name.toLowerCase().includes(lowerSearchTerm) ||
    indicator.responsible.toLowerCase().includes(lowerSearchTerm) ||
    indicator.program.toLowerCase().includes(lowerSearchTerm) ||
    indicator.strategicLine.toLowerCase().includes(lowerSearchTerm) ||
    indicator.description.toLowerCase().includes(lowerSearchTerm)
  );
}

/**
 * Format indicator data for CSV export
 */
export function formatIndicatorsForCSV(indicators: Indicator[], year: string) {
  return indicators.map(indicator => {
    let targetValue = 0;
    let progressValue = 0;
    
    switch(year) {
      case "2024":
        targetValue = indicator.target2024;
        progressValue = indicator.progress2024;
        break;
      case "2025":
        targetValue = indicator.target2025;
        progressValue = indicator.progress2025;
        break;
      case "2026":
        targetValue = indicator.target2026;
        progressValue = indicator.progress2026;
        break;
      case "2027":
        targetValue = indicator.target2027;
        progressValue = indicator.progress2027;
        break;
      default:
        targetValue = indicator.totalTarget;
        progressValue = indicator.totalProgress;
    }
    
    const percentage = targetValue > 0 ? (progressValue / targetValue) * 100 : 0;
    const status = getStatusForIndicator(indicator, year);
    
    return {
      code: indicator.code,
      name: indicator.name,
      strategicLine: indicator.strategicLine,
      program: indicator.program,
      responsible: indicator.responsible,
      target: targetValue,
      progress: progressValue,
      percentage: percentage.toFixed(1) + '%',
      status: status === "avanzado" ? "Avanzado" : status === "en-tiempo" ? "En tiempo" : "Retrasado"
    };
  });
}
