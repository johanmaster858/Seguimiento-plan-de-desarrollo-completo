import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { Indicator } from "@shared/schema";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const STRATEGIC_LINES = {
  "Dinamizacion y transformacion productiva": {
    color: "#FFD700",
    shortName: "Dinamización",
    className: "text-yellow-500 dark:text-yellow-400"
  },
  "Movilidad social y bienestar": {
    color: "#0066CC",
    shortName: "Movilidad social",
    className: "text-blue-600 dark:text-blue-400"
  },
  "Formacion para la transformacion": {
    color: "#FF8C00",
    shortName: "Formación",
    className: "text-orange-500 dark:text-orange-400"
  },
  "Ambiente sostenible. bienestar sustentable y orden en el territorio": {
    color: "#22C55E",
    shortName: "Ambiente",
    className: "text-green-500 dark:text-green-400"
  },
  "Seguridad. gobernabilidad ciudadana y gobierno de calidad": {
    color: "#EF4444",
    shortName: "Seguridad",
    className: "text-red-500 dark:text-red-400"
  }
};

export const STATUS_COLORS = {
  avanzado: {
    color: "#4CAF50",
    bgColor: "#E8F5E9",
    className: "text-green-600 bg-green-100"
  },
  "en-tiempo": {
    color: "#FFC107",
    bgColor: "#FFF8E1",
    className: "text-amber-600 bg-amber-100"
  },
  retrasado: {
    color: "#F44336",
    bgColor: "#FFEBEE",
    className: "text-red-600 bg-red-100"
  }
};

export function getStatusClass(status: string): string {
  return STATUS_COLORS[status as keyof typeof STATUS_COLORS]?.className || "";
}

export function getStrategicLineColor(line: string): string {
  // Retornar el color específico de la línea estratégica
  return STRATEGIC_LINES[line as keyof typeof STRATEGIC_LINES]?.color || "#6B7280";
}

export function getStrategicLineShortName(strategicLine: string): string {
  return STRATEGIC_LINES[strategicLine as keyof typeof STRATEGIC_LINES]?.shortName || strategicLine;
}

export function getStrategicLineClass(strategicLine: string): string {
  return STRATEGIC_LINES[strategicLine as keyof typeof STRATEGIC_LINES]?.className || "text-gray-700";
}

export function getStatusForIndicator(indicator: Indicator, year: string): string {
  let target = 0;
  let progress = 0;

  switch(year) {
    case "2024":
      target = indicator.target2024 || 0;
      progress = indicator.progress2024 || 0;
      break;
    case "2025":
      target = indicator.target2025 || 0;
      progress = indicator.progress2025 || 0;
      break;
    case "2026":
      target = indicator.target2026 || 0;
      progress = indicator.progress2026 || 0;
      break;
    case "2027":
      target = indicator.target2027 || 0;
      progress = indicator.progress2027 || 0;
      break;
    case "cuatrienio":
      target = indicator.totalTarget || 0;
      progress = (indicator.progress2024 || 0) + 
                 (indicator.progress2025 || 0) + 
                 (indicator.progress2026 || 0) + 
                 (indicator.progress2027 || 0);
      break;
    default:
      target = indicator.totalTarget || 0;
      progress = (indicator.progress2024 || 0) + 
                 (indicator.progress2025 || 0) + 
                 (indicator.progress2026 || 0) + 
                 (indicator.progress2027 || 0);
  }

  if (target === 0) return "en-tiempo";

  // Calcular el porcentaje real sin limitar
  const percentage = (progress / target) * 100;

  // Ajustar los umbrales según lo solicitado
  if (percentage >= 90) return "avanzado";
  if (percentage >= 70) return "en-tiempo";
  return "retrasado";
}

export function formatNumberWithDecimals(value: number): string {
  if (Number.isInteger(value)) {
    return value.toString();
  }
  return value.toFixed(1);
}

export function formatDate(date: Date): string {
  return new Intl.DateTimeFormat('es-CO', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  }).format(date);
}

/**
 * Calcula el porcentaje de avance de un indicador
 * @param current El valor actual del progreso
 * @param target El valor objetivo o meta 
 * @param applyLimit Si es true, limita el porcentaje a un máximo del 100%
 * @returns El porcentaje calculado
 */
export function getProgressPercentage(progress: number, target: number): number {
  if (target === 0) return 0;
  const percentage = (progress / target) * 100;
  // Para cálculos de promedio, limitar al 100% máximo
  return Math.min(percentage, 100);
}

export function getProgressPercentageRaw(progress: number, target: number): number {
  if (target === 0) return 0;
  return (progress / target) * 100;
}

export function calculateStrategicLineStats(indicators: Indicator[], year: string) {
  const lineStats: Record<string, { 
    count: number,
    percentages: number[],
    totalProgress: number,
    totalTarget: number,
    progress2024: number,
    target2024: number,
    progress2025: number,
    target2025: number,
    progress2026: number,
    target2026: number,
    progress2027: number,
    target2027: number
  }> = {};

  // Inicializar estadísticas para cada línea
  indicators.forEach(indicator => {
    if (!lineStats[indicator.strategicLine]) {
      lineStats[indicator.strategicLine] = {
        count: 0,
        percentages: [],
        totalProgress: 0,
        totalTarget: 0,
        progress2024: 0,
        target2024: 0,
        progress2025: 0,
        target2025: 0,
        progress2026: 0,
        target2026: 0,
        progress2027: 0,
        target2027: 0
      };
    }

    // Incrementar contador y sumar progreso/meta del año seleccionado
    lineStats[indicator.strategicLine].count++;

    let progress = 0;
    let target = 0;

    switch(year) {
      case "2024":
        progress = indicator.progress2024 || 0;
        target = indicator.target2024 || 0;
        break;
      case "2025":
        progress = indicator.progress2025 || 0;
        target = indicator.target2025 || 0;
        break;
      case "2026":
        progress = indicator.progress2026 || 0;
        target = indicator.target2026 || 0;
        break;
      case "2027":
        progress = indicator.progress2027 || 0;
        target = indicator.target2027 || 0;
        break;
      case "cuatrienio":
      default:
        target = indicator.totalTarget || 0;
        progress = (indicator.progress2024 || 0) + 
                   (indicator.progress2025 || 0) + 
                   (indicator.progress2026 || 0) + 
                   (indicator.progress2027 || 0);
        break;
    }

    const percentage = getProgressPercentage(progress, target);

    // Solo agregar porcentaje si hay meta
    if (target > 0) {
      lineStats[indicator.strategicLine].percentages.push(percentage);
    }

    // Acumular progreso por años para gráficos anuales
    lineStats[indicator.strategicLine].totalProgress += progress;
    lineStats[indicator.strategicLine].totalTarget += target;
    lineStats[indicator.strategicLine].progress2024 += indicator.progress2024 || 0;
    lineStats[indicator.strategicLine].target2024 += indicator.target2024 || 0;
    lineStats[indicator.strategicLine].progress2025 += indicator.progress2025 || 0;
    lineStats[indicator.strategicLine].target2025 += indicator.target2025 || 0;
    lineStats[indicator.strategicLine].progress2026 += indicator.progress2026 || 0;
    lineStats[indicator.strategicLine].target2026 += indicator.target2026 || 0;
    lineStats[indicator.strategicLine].progress2027 += indicator.progress2027 || 0;
    lineStats[indicator.strategicLine].target2027 += indicator.target2027 || 0;
  });

  // Convertir a array y calcular porcentajes
  const lineStatsArray = Object.entries(lineStats).map(([line, stats]) => {
    // Calcular el porcentaje promedio para la línea (dando peso igual a cada indicador)
    const percentage = stats.percentages.length > 0
      ? stats.percentages.reduce((sum, p) => sum + Math.min(p, 100), 0) / stats.percentages.length
      : 0;

    // Calcular porcentajes anuales
    const progress2024Pct = stats.target2024 > 0 
      ? (stats.progress2024 / stats.target2024) * 100 
      : 0;

    const progress2025Pct = stats.target2025 > 0 
      ? (stats.progress2025 / stats.target2025) * 100 
      : 0;

    const progress2026Pct = stats.target2026 > 0 
      ? (stats.progress2026 / stats.target2026) * 100 
      : 0;

    const progress2027Pct = stats.target2027 > 0 
      ? (stats.progress2027 / stats.target2027) * 100 
      : 0;

    return {
      name: line,
      shortName: getStrategicLineShortName(line),
      color: getStrategicLineColor(line),
      count: stats.count,
      percentage: percentage,
      progress2024: progress2024Pct,
      target2024: 100,
      progress2025: progress2025Pct,
      target2025: 100,
      progress2026: progress2026Pct,
      target2026: 100,
      progress2027: progress2027Pct,
      target2027: 100
    };
  }).sort((a, b) => b.percentage - a.percentage);

  return lineStatsArray;
}

/**
 * Calculate yearly progress and projects
 */
export function calculateYearlyProgress(indicators: Indicator[]) {
  const totalByYear = {
    "2024": { progress: 0, target: 0, count: 0 },
    "2025": { progress: 0, target: 0, count: 0 },
    "2026": { progress: 0, target: 0, count: 0 },
    "2027": { progress: 0, target: 0, count: 0 }
  };

  indicators.forEach(indicator => {
    // 2024
    if (indicator.target2024 && indicator.target2024 > 0) {
      totalByYear["2024"].count++;
      totalByYear["2024"].progress += indicator.progress2024 || 0;
      totalByYear["2024"].target += indicator.target2024;
    }

    // 2025
    if (indicator.target2025 && indicator.target2025 > 0) {
      totalByYear["2025"].count++;
      totalByYear["2025"].progress += indicator.progress2025 || 0;
      totalByYear["2025"].target += indicator.target2025;
    }

    // 2026
    if (indicator.target2026 && indicator.target2026 > 0) {
      totalByYear["2026"].count++;
      totalByYear["2026"].progress += indicator.progress2026 || 0;
      totalByYear["2026"].target += indicator.target2026;
    }

    // 2027
    if (indicator.target2027 && indicator.target2027 > 0) {
      totalByYear["2027"].count++;
      totalByYear["2027"].progress += indicator.progress2027 || 0;
      totalByYear["2027"].target += indicator.target2027;
    }
  });

  // Formatear para gráfico
  return [
    {
      name: "2024",
      actual: totalByYear["2024"].target > 0 
        ? (totalByYear["2024"].progress / totalByYear["2024"].target) * 100 
        : 0,
      target: 100
    },
    {
      name: "2025",
      actual: totalByYear["2025"].target > 0 
        ? (totalByYear["2025"].progress / totalByYear["2025"].target) * 100 
        : 0,
      target: 100
    },
    {
      name: "2026",
      actual: totalByYear["2026"].target > 0 
        ? (totalByYear["2026"].progress / totalByYear["2026"].target) * 100 
        : 0,
      target: 100
    },
    {
      name: "2027",
      actual: totalByYear["2027"].target > 0 
        ? (totalByYear["2027"].progress / totalByYear["2027"].target) * 100 
        : 0,
      target: 100
    }
  ];
}

// Función auxiliar para inicializar pdfMake
export function initPdfMake() {
  try {
    // Importaciones dinámicas
    const pdfMake = require('pdfmake/build/pdfmake');
    const pdfFonts = require('pdfmake/build/vfs_fonts');

    // Asignar las fuentes al objeto pdfMake
    pdfMake.vfs = pdfFonts.pdfMake ? pdfFonts.pdfMake.vfs : pdfFonts;

    return pdfMake;
  } catch (error) {
    console.error('Error inicializando pdfMake:', error);
    throw new Error('No se pudo inicializar la biblioteca para generar PDFs.');
  }
}

export function calculateSummaryStats(indicators: Indicator[], year: string) {
  let totalProgressSum = 0;
  let indicatorCount = 0;
  let advancedCount = 0;
  let onTimeCount = 0;
  let delayedCount = 0;
  let noDataCount = 0;
  const lineStats: Record<string, { progressSum: number; count: number }> = {};
  
  // Debug: verificar nombres únicos de líneas estratégicas
  const uniqueLines = new Set(indicators.map(ind => ind.strategicLine));
  console.log('🔍 Líneas estratégicas encontradas en datos:', Array.from(uniqueLines));

  indicators.forEach(indicator => {
    let progress = 0;
    let target = 0;

    switch(year) {
      case "2024":
        progress = indicator.progress2024 || 0;
        target = indicator.target2024 || 0;
        break;
      case "2025":
        progress = indicator.progress2025 || 0;
        target = indicator.target2025 || 0;
        break;
      case "2026":
        progress = indicator.progress2026 || 0;
        target = indicator.target2026 || 0;
        break;
      case "2027":
        progress = indicator.progress2027 || 0;
        target = indicator.target2027 || 0;
        break;
      case "cuatrienio":
      default:
        progress = indicator.totalProgress || 0;
        target = indicator.totalTarget || 0;
        break;
    }

    const percentage = target > 0 ? Math.min((progress / target) * 100, 100) : 0;

    if (target > 0) {
      totalProgressSum += percentage;
      indicatorCount++;
    }
    
    // Determinar estado del indicador
    const status = getStatusForIndicator(indicator, year);
    if (status === "avanzado") advancedCount++;
    else if (status === "en-tiempo") onTimeCount++;
    else delayedCount++;

    // Estadísticas por línea estratégica
    if (!lineStats[indicator.strategicLine]) {
      lineStats[indicator.strategicLine] = { progressSum: 0, count: 0 };
    }

    if (target > 0) {
      lineStats[indicator.strategicLine].progressSum += percentage;
      lineStats[indicator.strategicLine].count += 1;
    }
  });

  // Calcular el promedio de avance general
  const averageProgress = indicatorCount > 0 ? totalProgressSum / indicatorCount : 0;

  // Crear array de estadísticas por línea ordenado por porcentaje
  const lineStatsArray = Object.entries(lineStats).map(([name, stats]) => {
    const percentage = stats.count > 0 ? stats.progressSum / stats.count : 0;
    return {
      name,
      percentage,
      progress: 0, // These are not directly used in the summary stats return anymore
      target: 0,   // These are not directly used in the summary stats return anymore
      count: stats.count
    };
  }).sort((a, b) => b.percentage - a.percentage);

  // Encontrar la línea estratégica con mayor avance (basado en el promedio de la línea)
  let lineWithHighestProgress = {
    name: "",
    percentage: 0,
    color: "#6B7280"
  };

  if (lineStatsArray.length > 0) {
    const topLine = lineStatsArray[0];
    // Usar el color directamente del objeto STRATEGIC_LINES
    const lineColor = STRATEGIC_LINES[topLine.name as keyof typeof STRATEGIC_LINES]?.color || "#6B7280";
    lineWithHighestProgress = {
      name: topLine.name,
      percentage: topLine.percentage,
      color: lineColor
    };
  }

  return {
    indicatorsCount: indicators.length, // Total number of indicators
    advancedCount,
    onTimeCount,
    delayedCount,
    averageProgress,
    lineWithHighestProgress,
    lineStatsArray,
    exceedingIndicators: indicators.filter(indicator => { // Filter for indicators exceeding 100%
      let progress = 0;
      let target = 0;
      switch(year) {
        case "2024": progress = indicator.progress2024 || 0; target = indicator.target2024 || 0; break;
        case "2025": progress = indicator.progress2025 || 0; target = indicator.target2025 || 0; break;
        case "2026": progress = indicator.progress2026 || 0; target = indicator.target2026 || 0; break;
        case "2027": progress = indicator.progress2027 || 0; target = indicator.target2027 || 0; break;
        case "cuatrienio":
        default: progress = indicator.totalProgress || 0; target = indicator.totalTarget || 0; break;
      }
      return target > 0 && (progress / target) * 100 > 100;
    })
  };
}