import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { AuthProvider } from "./context/AuthContext";

// Script para inicializar el tema oscuro/claro
const initTheme = () => {
  const theme = localStorage.getItem("theme") || "system";
  
  if (theme === "dark" || (theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches)) {
    document.documentElement.classList.add("dark");
  } else {
    document.documentElement.classList.remove("dark");
  }
};

// Ejecutar script de inicialización de tema
initTheme();

document.addEventListener('DOMContentLoaded', () => {
  const root = document.getElementById("root");
  if (root) {
    createRoot(root).render(
      <AuthProvider>
        <App />
      </AuthProvider>
    );
  }
});
