import React from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/context/AuthContext";
import { Redirect } from "wouter";
import AdminPanel from "@/components/AdminPanel";
import UpdateHistoryView from "@/components/UpdateHistoryView";
import BudgetAnalysisView from "@/components/BudgetAnalysisView";
import PredictionsView from "@/components/PredictionsView";
import MainLayout from "@/components/MainLayout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Settings, Clock } from "lucide-react";
import { Indicator } from "@shared/schema";

const AdminPage: React.FC = () => {
  const { isAuthenticated, isAdmin } = useAuth();
  
  // Fetch indicators data
  const { data: indicators = [], isLoading } = useQuery<Indicator[]>({
    queryKey: ['/api/indicators'],
  });

  // If not authenticated or not admin, redirect to home page
  if (!isAuthenticated || !isAdmin) {
    return <Redirect to="/" />;
  }

  if (isLoading) {
    return (
      <MainLayout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="flex flex-col items-center">
            <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
            <p className="text-lg text-gray-600 dark:text-gray-400">Cargando panel de administración...</p>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold text-gray-800 dark:text-white">
            Panel de Administración - San Jerónimo Plan de Desarrollo
          </h1>
        </div>
        
        <Tabs defaultValue="admin" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="admin" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Administración
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Historial
            </TabsTrigger>
            <TabsTrigger value="budget" className="flex items-center gap-2">
              <span className="material-icons h-4 w-4">account_balance</span>
              Presupuesto
            </TabsTrigger>
            <TabsTrigger value="predictions" className="flex items-center gap-2">
              <span className="material-icons h-4 w-4">trending_up</span>
              Predicciones
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="admin" className="mt-6">
            <AdminPanel indicators={indicators} isVisible={true} />
          </TabsContent>
          
          <TabsContent value="history" className="mt-6">
            <UpdateHistoryView />
          </TabsContent>
          
          <TabsContent value="budget" className="mt-6">
            <BudgetAnalysisView indicators={indicators} />
          </TabsContent>
          
          <TabsContent value="predictions" className="mt-6">
            <PredictionsView indicators={indicators} />
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
};

export default AdminPage;