import React, { useState, useMemo, useEffect, lazy, Suspense } from "react";
import { useQuery } from "@tanstack/react-query";
import DashboardFilters from "@/components/DashboardFilters";
import DashboardSummary from "@/components/DashboardSummary";
import IndicatorsList from "@/components/IndicatorsList";
import PerformanceMetrics from "@/components/PerformanceMetrics";
import ExportWordButton from "@/components/ExportWordButton";
import MainLayout from "@/components/MainLayout";
import LoginModal from "@/components/LoginModal";
import { Link, useLocation } from "wouter";
import { useSearch } from "wouter";
import { Indicator } from "@shared/schema";
import { useAuth } from "@/context/AuthContext";

// Lazy load heavy components for better performance
const HeatMapVisualizations = lazy(() => import("@/components/HeatMapVisualizations"));
const BarChartsVisualizations = lazy(() => import("@/components/BarChartsVisualizations"));
const AdvancedAnalyticsCharts = lazy(() => import("@/components/AdvancedAnalyticsCharts"));

const Dashboard: React.FC = () => {
  const { isAuthenticated, isAdmin } = useAuth();
  const searchString = useSearch();
  const [location] = useLocation();
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  
  // Automatically show login modal if route is /auth
  useEffect(() => {
    if (location === "/auth") {
      setIsLoginModalOpen(true);
    }
  }, [location]);
  
  // Parse search parameters from URL
  const searchParams = useMemo(() => {
    return new URLSearchParams(searchString);
  }, [searchString]);
  
  // Get filters from URL or use defaults
  const initialFilters = {
    strategicLine: searchParams.get("strategicLine") || "",
    program: searchParams.get("program") || "",
    responsible: searchParams.get("responsible") || "",
    sector: searchParams.get("sector") || "",
    ods: searchParams.get("ods") || "",
    bpim: searchParams.get("bpim") || "",
    year: searchParams.get("year") || "cuatrienio",
    status: (searchParams.get("status") || "").split(",").filter(Boolean)
  };
  
  const [filters, setFilters] = useState(initialFilters);
  
  // Load indicators
  const { data: indicators = [], isLoading } = useQuery<Indicator[]>({
    queryKey: ['/api/indicators'],
  });
  
  // Apply filters to indicators
  const filteredIndicators = useMemo(() => {
    if (!Array.isArray(indicators) || indicators.length === 0) return [];
    
    // Build API query parameters
    const params = new URLSearchParams();
    if (filters.strategicLine) params.append("strategicLine", filters.strategicLine);
    if (filters.program) params.append("program", filters.program);
    if (filters.responsible) params.append("responsible", filters.responsible);
    if (filters.year) params.append("year", filters.year);
    if (filters.status && filters.status.length > 0) params.append("status", filters.status.join(","));
    
    // Filter indicators based on selected criteria
    return indicators.filter((indicator: any) => {
      if (filters.strategicLine && indicator.strategicLine !== filters.strategicLine) return false;
      if (filters.program && indicator.program !== filters.program) return false;
      if (filters.responsible && indicator.responsible !== filters.responsible) return false;
      if (filters.sector && indicator.sector !== filters.sector) return false;
      if (filters.ods && indicator.ods !== parseInt(filters.ods)) return false;
      if (filters.bpim && String(indicator.bpim) !== String(filters.bpim)) return false;
      return true;
    });
  }, [indicators, filters]);
  
  // Extract unique values for filter dropdowns
  const uniqueResponsibles = useMemo(() => {
    if (!Array.isArray(indicators)) return [];
    return Array.from(new Set(indicators.map((i: any) => i.responsible)))
      .filter(Boolean)
      .sort() as string[];
  }, [indicators]);
  
  const uniquePrograms = useMemo(() => {
    if (!Array.isArray(indicators)) return [];
    return Array.from(new Set(indicators.map((i: any) => i.program)))
      .filter(Boolean)
      .sort() as string[];
  }, [indicators]);
  
  // Handle filter changes
  const handleFilterChange = (newFilters: any) => {
    setFilters(newFilters);
  };
  
  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-6">
        <div className="mb-6 flex justify-between items-center">
          <div className="flex space-x-2">
            <ExportWordButton 
              indicators={filteredIndicators}
              year={filters.year}
              filters={{
                strategicLine: filters.strategicLine,
                program: filters.program,
                responsible: filters.responsible,
                status: filters.status
              }}
            />
            
            <Link href="/analysis" className="inline-flex items-center bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition">
              <span className="material-icons mr-2 text-sm">analytics</span>
              Análisis Avanzado
            </Link>
          </div>
          
          {isAdmin && (
            <div>
              <Link href="/admin" className="inline-flex items-center bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition">
                <span className="material-icons mr-2 text-sm">admin_panel_settings</span>
                Panel de Administración
              </Link>
            </div>
          )}
        </div>
        
        {/* Filtros con mejor diseño */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 mb-6">
          <h2 className="text-xl font-bold text-gray-800 dark:text-white mb-4 flex items-center">
            <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.707A1 1 0 013 7V4z" />
            </svg>
            Filtros de Búsqueda
          </h2>
          <DashboardFilters 
            onFilterChange={handleFilterChange} 
            responsibles={uniqueResponsibles}
            programs={uniquePrograms}
            indicators={filteredIndicators}
          />
        </div>
        
        {/* Resumen ejecutivo con mejor visualización */}
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-gray-800 dark:to-gray-700 rounded-lg shadow-lg p-6 mb-6">
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4 flex items-center">
            <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
            Resumen Ejecutivo del Plan de Desarrollo
          </h2>
          <DashboardSummary 
            indicators={filteredIndicators} 
            year={filters.year}
            lastUpdated={new Date()}
          />
        </div>
        
        {/* Métricas de rendimiento */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 mb-6">
          <h2 className="text-xl font-bold text-gray-800 dark:text-white mb-4 flex items-center">
            <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
            </svg>
            Métricas de Rendimiento
          </h2>
          <PerformanceMetrics 
            indicators={filteredIndicators}
            year={filters.year}
          />
        </div>
        
        {/* Visualizaciones */}
        <div className="space-y-6">
          <Suspense fallback={
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 mb-6">
              <div className="animate-pulse">
                <div className="h-4 bg-gray-200 rounded w-1/4 mb-4"></div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="h-32 bg-gray-200 rounded"></div>
                  <div className="h-32 bg-gray-200 rounded"></div>
                </div>
              </div>
            </div>
          }>
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
              <h2 className="text-xl font-bold text-gray-800 dark:text-white mb-4 flex items-center">
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                </svg>
                Gráficos de Barras y Análisis Comparativo
              </h2>
              <BarChartsVisualizations
                indicators={filteredIndicators}
                year={filters.year}
              />
            </div>
          </Suspense>
          
          <Suspense fallback={
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 mb-6">
              <div className="animate-pulse">
                <div className="h-4 bg-gray-200 rounded w-1/4 mb-4"></div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="h-32 bg-gray-200 rounded"></div>
                  <div className="h-32 bg-gray-200 rounded"></div>
                </div>
              </div>
            </div>
          }>
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
              <h2 className="text-xl font-bold text-gray-800 dark:text-white mb-4 flex items-center">
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                </svg>
                Análisis Avanzados y Correlaciones
              </h2>
              <AdvancedAnalyticsCharts
                indicators={filteredIndicators}
                year={filters.year}
              />
            </div>
          </Suspense>
        </div>
        
        {/* Lista detallada de indicadores */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 mt-6">
          <h2 className="text-xl font-bold text-gray-800 dark:text-white mb-4 flex items-center">
            <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
            </svg>
            Lista Detallada de Indicadores
          </h2>
          <IndicatorsList 
            indicators={filteredIndicators}
            year={filters.year}
            isLoading={isLoading}
          />
        </div>
      </div>
      
      {/* Login Modal that opens automatically when at /auth route */}
      <LoginModal 
        isOpen={isLoginModalOpen} 
        onClose={() => setIsLoginModalOpen(false)}
      />
    </MainLayout>
  );
};

export default Dashboard;
