import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import BudgetAnalysisView from "@/components/BudgetAnalysisView";
import BudgetAnalysisCharts from "@/components/BudgetAnalysisCharts"; // Assuming this is the new component
import PredictionsView from "@/components/PredictionsView";
import MainLayout from "@/components/MainLayout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2 } from "lucide-react";
import { Indicator } from "@shared/schema";

const PublicAnalysisPage: React.FC = () => {
  // Load indicators
  const { data: indicators = [], isLoading } = useQuery<Indicator[]>({
    queryKey: ['/api/indicators'],
  });

  // State for the selected year for BudgetAnalysisCharts (assuming it's needed)
  const [selectedYear, setSelectedYear] = useState<number>(new Date().getFullYear());
  // State to manage the active view (budget or predictions)
  const [activeView, setActiveView] = useState<'budget' | 'predictions'>('budget');
  // Placeholder for filtered indicators, assuming it might be needed for BudgetAnalysisCharts
  const filteredIndicators = indicators; // Replace with actual filtering logic if necessary

  if (isLoading) {
    return (
      <MainLayout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="flex flex-col items-center">
            <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
            <p className="text-lg text-gray-600 dark:text-gray-400">Cargando análisis...</p>
          </div>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold text-gray-800 dark:text-white">
            Análisis Avanzado - Plan de Desarrollo San Jerónimo
          </h1>
        </div>

        <Tabs defaultValue="budget" className="w-full" onValueChange={(value) => setActiveView(value as 'budget' | 'predictions')}>
          <TabsList className="grid grid-cols-2">
            <TabsTrigger value="budget" className="flex items-center gap-2">
              <span className="material-icons h-4 w-4">account_balance</span>
              Análisis Presupuestal
            </TabsTrigger>
            <TabsTrigger value="predictions" className="flex items-center gap-2">
              <span className="material-icons h-4 w-4">trending_up</span>
              Predicciones y Tendencias
            </TabsTrigger>
          </TabsList>

          <TabsContent value="budget" className="mt-6">
            {activeView === 'budget' && (
              <BudgetAnalysisCharts indicators={filteredIndicators} year={selectedYear} />
            )}
          </TabsContent>

          <TabsContent value="predictions" className="mt-6">
            {activeView === 'predictions' && (
              <PredictionsView indicators={indicators} />
            )}
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
};

export default PublicAnalysisPage;