# San Jerónimo Development Plan Dashboard

## Overview
This project is a comprehensive dashboard application designed to track the development plan (Plan de Desarrollo) for the San Jerónimo municipality from 2024 to 2027. It offers a web-based interface for monitoring key performance indicators (KPIs), strategic lines, programs, and budget allocations. The application aims to provide a clear, real-time overview of the municipality's progress, facilitating informed decision-making and transparency in governmental operations.

## User Preferences
Preferred communication style: Simple, everyday language.

## System Architecture
The application features a modern full-stack architecture. The frontend is built with React 18 and TypeScript, utilizing Vite for development, Wouter for routing, shadcn/ui for UI components, Tailwind CSS for styling, TanStack Query for state management, React Hook Form with Zod for forms, Recharts for data visualizations, and Framer Motion for animations. The backend is powered by Node.js with Express.js and TypeScript, providing a RESTful API. Authentication is handled using Passport.js. Data is stored in a PostgreSQL database (Neon serverless) and managed with Drizzle ORM and Drizzle Kit for migrations.

Key features include:
- **Dashboard**: Multi-year, strategic line, program, responsible party, and status-based filtering (advanced, on-time, delayed). Includes data visualizations such as heat maps, bar charts, and progress indicators. Supports PDF and Word document exports.
- **Admin Panel**: Functionality for bulk CSV import and individual updates of indicators, budget management (initial and final budget per year), and an audit history for all changes.
- **Data Models**: Core tables for Users (authentication, roles), Indicators (KPI tracking with targets and progress), and Update History (audit trail).
- **Authentication**: Session-based authentication with Passport.js and role-based access control.

## External Dependencies
- **Database**: PostgreSQL (via @neondatabase/serverless for connection)
- **ORM**: Drizzle ORM
- **UI Components**: Radix UI (via shadcn/ui)
- **Charts**: Recharts
- **Document Generation**: `docx` for Word exports, `html2canvas` for PDF generation
- **Authentication**: `passport` and `express-session`
- **File Processing**: `csv-parser`
- **Build Tools**: Vite (frontend), esbuild (backend production build)