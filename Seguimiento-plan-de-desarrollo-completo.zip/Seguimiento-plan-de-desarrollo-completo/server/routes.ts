import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertIndicatorSchema, 
  updateIndicatorProgressSchema,
  insertUserSchema,
  insertFinancingSourceSchema,
  insertBudgetFinancingSchema,
  chatRequestSchema
} from "@shared/schema";
import OpenAI from "openai";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import session from "express-session";
import * as fs from 'fs';
import * as path from 'path';
import csv from 'csv-parser';
import * as z from 'zod';
import { fromZodError } from "zod-validation-error";
import bcrypt from "bcrypt";
import dotenv from "dotenv";
import multer from "multer";
import { stringify } from 'csv-stringify/sync';

// Load environment variables
dotenv.config();

  // Setup authentication middleware
  async function setupAuth(app: Express) {
    // Session configuration with enhanced security
    app.use(session({
      secret: process.env.SESSION_SECRET || 'san-jeronimo-secret-key-2025',
      resave: true,
      saveUninitialized: true,
      rolling: true,
      cookie: { 
        secure: false, 
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000, 
        sameSite: 'lax'
      },
      name: 'san-jeronimo-session'
    }));

    app.use(passport.initialize());
    app.use(passport.session());

  // Passport local strategy for username/password auth
  passport.use(new LocalStrategy(
    { usernameField: 'username', passwordField: 'password' },
    async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);

        if (!user) {
          return done(null, false, { message: 'Usuario no encontrado' });
        }

        // Use bcrypt to compare passwords securely
        const isValidPassword = await bcrypt.compare(password, user.password);

        if (!isValidPassword) {
          return done(null, false, { message: 'Contraseña incorrecta' });
        }

        return done(null, user);
      } catch (error) {
        console.error('Error en authenticación:', error);
        return done(error);
      }
    }
  ));

  // Serialize and deserialize user
  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  // Auth middleware
  const isAuthenticated = (req: Request, res: Response, next: any) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: 'No autorizado', authenticated: false });
  };

  const isAdmin = (req: Request, res: Response, next: any) => {
    // Solo verificar autenticación por sesión con privilegios de admin
    if (req.isAuthenticated() && req.user && (req.user as any).isAdmin) {
      return next();
    }

    res.status(403).json({ message: 'Acceso prohibido' });
  };

  return { isAuthenticated, isAdmin };
}

export async function registerRoutes(app: Express): Promise<Server> {
  const { isAuthenticated, isAdmin } = await setupAuth(app);

  // Initialize database and create default admin user
  try {
    await storage.createDefaultAdminUser();
    console.log('✅ Sistema de autenticación inicializado correctamente');
  } catch (error) {
    console.error('❌ Error inicializando sistema de autenticación:', error);
  }

  // Authentication routes
  app.post('/api/auth/login', (req, res, next) => {
    passport.authenticate('local', (err, user, info) => {
      if (err) {
        return next(err);
      }
      if (!user) {
        return res.status(401).json({ message: info.message || 'Credenciales inválidas' });
      }
      req.logIn(user, (err) => {
        if (err) {
          return next(err);
        }
        return res.json({ 
          id: user.id, 
          username: user.username,
          isAdmin: user.isAdmin
        });
      });
    })(req, res, next);
  });

  app.post('/api/auth/logout', (req, res) => {
    req.logout(() => {
      res.json({ message: 'Sesión cerrada exitosamente' });
    });
  });

  app.get('/api/auth/me', (req, res) => {
    if (!req.user) {
      return res.status(401).json({ authenticated: false });
    }

    const user = req.user as any;
    res.json({
      authenticated: true,
      user: {
        id: user.id,
        username: user.username,
        isAdmin: user.isAdmin
      }
    });
  });

  // Indicators routes
  app.get('/api/indicators', async (req, res) => {
    try {
      // Get filter parameters including new BPIM, sector, and ODS filters
      const filters = {
        strategicLine: req.query.strategicLine as string | undefined,
        program: req.query.program as string | undefined,
        responsible: req.query.responsible as string | undefined,
        bpim: req.query.bpim as string | undefined,
        sector: req.query.sector as string | undefined,
        ods: req.query.ods as string | undefined,
        year: req.query.year as string | undefined,
        status: req.query.status ? (req.query.status as string).split(',') : undefined
      };

      // Apply filters if provided, otherwise get all indicators
      const indicators = Object.keys(filters).some(k => filters[k as keyof typeof filters] !== undefined)
        ? await storage.getIndicatorsByFilters(filters)
        : await storage.getAllIndicators();

      res.json(indicators);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching indicators', error: (error as Error).message });
    }
  });

  app.get('/api/indicators/:code', async (req, res) => {
    try {
      const indicator = await storage.getIndicatorByCode(req.params.code);

      if (!indicator) {
        return res.status(404).json({ message: 'Indicator not found' });
      }

      res.json(indicator);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching indicator', error: (error as Error).message });
    }
  });

  // Update indicator progress (requires auth)
  app.patch('/api/indicators/:code/progress', isAuthenticated, async (req, res) => {
    try {
      const updateData = updateIndicatorProgressSchema.parse({
        code: req.params.code,
        ...req.body
      });

      const username = (req.user as any).username;
      const updatedIndicator = await storage.updateIndicatorProgress(updateData, username);

      res.json(updatedIndicator);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: 'Validation error', error: validationError.message });
      }
      res.status(500).json({ message: 'Error updating indicator', error: (error as Error).message });
    }
  });

  // Ruta POST alternativa para actualizaciones de indicadores (compatible con tests anteriores)
  app.post('/api/indicators/update', async (req, res) => {
    try {
      console.log("POST /api/indicators/update recibido:", req.body);

      // Validar datos
      const updateData = updateIndicatorProgressSchema.parse(req.body);

      // Usar un nombre de usuario predeterminado para pruebas o usar admin si está autenticado
      const username = req.user ? (req.user as any).username : "sistema";

      // Realizar la actualización
      const updatedIndicator = await storage.updateIndicatorProgress(updateData, username);

      console.log("Indicador actualizado correctamente:", updateData.code);
      res.json(updatedIndicator);
    } catch (error) {
      console.error("Error en actualización de indicador:", error);
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: 'Error de validación', error: validationError.message });
      }
      res.status(500).json({ message: 'Error al actualizar indicador', error: (error as Error).message });
    }
  });

  // Create indicator (admin only)
  app.post('/api/indicators', isAdmin, async (req, res) => {
    try {
      const indicatorData = insertIndicatorSchema.parse(req.body);
      const indicator = await storage.createIndicator(indicatorData);
      res.status(201).json(indicator);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: 'Validation error', error: validationError.message });
      }
      res.status(500).json({ message: 'Error creating indicator', error: (error as Error).message });
    }
  });

  // Get update history
  app.get('/api/history', isAuthenticated, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const history = await storage.getUpdateHistory(limit);
      res.json(history);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching history', error: (error as Error).message });
    }
  });

  // Get history for specific indicator
  app.get('/api/history/:code', isAuthenticated, async (req, res) => {
    try {
      const history = await storage.getUpdateHistoryByIndicator(req.params.code);
      res.json(history);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching indicator history', error: (error as Error).message });
    }
  });

  // Ruta para verificar el estado de persistencia de datos
  app.get('/api/system/persistence-status', isAdmin, async (req, res) => {
    try {
      const status = await storage.verifyDataPersistence();
      res.json({
        message: 'Data persistence verification completed',
        data: status,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      res.status(500).json({ 
        message: 'Error verifying data persistence', 
        error: (error as Error).message 
      });
    }
  });

  // Enhanced CSV import with guaranteed persistence
  app.post('/api/import/indicators', isAdmin, async (req, res) => {
    try {
      // Usar usuario por defecto para importación temporal
      const username = req.user ? (req.user as any).username : 'sistema_importacion';

      console.log('📥 IMPORTACIÓN MASIVA CSV INICIADA CON SISTEMA DE PERSISTENCIA');
      console.log('✅ Los datos importados persistirán después de reinicios del servidor');

      // Validate that the indicators array exists and meets the schema
      if (!Array.isArray(req.body)) {
        return res.status(400).json({ message: 'Expected an array of indicators' });
      }

      // Parse and validate each indicator
      const indicators = [];
      for (const item of req.body) {
        try {
          const indicator = insertIndicatorSchema.parse(item);
          indicators.push(indicator);
        } catch (error) {
          if (error instanceof z.ZodError) {
            return res.status(400).json({
              message: 'Invalid indicator data',
              error: `Row ${indicators.length + 1}: ${fromZodError(error).message}`,
              data: item
            });
          }
          throw error;
        }
      }

      // Save all validated indicators with persistence guarantee
      const savedIndicators = await storage.bulkCreateIndicators(indicators);

      // Crear registro de auditoría para la importación
      try {
        await storage.createUpdateHistory({
          indicatorCode: 'BULK_IMPORT_PERSISTENT',
          username: username,
          year: 'bulk_import',
          previousValue: 0,
          newValue: savedIndicators.length,
          observations: `Importación masiva persistente de ${savedIndicators.length} indicadores desde CSV - datos garantizados contra reinicios`
        });
      } catch (histError) {
        console.log('Nota: No se pudo crear registro de auditoría (tabla podría no existir)');
      }

      console.log(`✅ IMPORTACIÓN COMPLETADA: ${savedIndicators.length} indicadores importados con persistencia garantizada`);

      res.status(201).json({ 
        message: `✅ Importación exitosa: ${savedIndicators.length} indicadores importados con persistencia garantizada`,
        indicators: savedIndicators,
        persistenceGuaranteed: true
      });

    } catch (error) {
      console.error('Error en importación masiva:', error);
      res.status(500).json({ message: 'Error importing indicators', error: (error as Error).message });
    }
  });

  // Export template CSV
  app.get('/api/export/template', async (req, res) => {
    try {
      const csvContent = stringify([]);

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename="plantilla_indicadores.csv"');
      res.send(csvContent);
    } catch (error) {
      console.error('Error generating template:', error);
      res.status(500).json({ message: 'Error al generar la plantilla' });
    }
  });

  // Custom CSV export with selected columns
  app.post('/api/export/custom-csv', async (req, res) => {
    if (!req.isAuthenticated() || !req.user?.isAdmin) {
      return res.status(403).json({ message: 'No autorizado' });
    }

    try {
      const { indicators: indicatorCodes, columns, includeFinancingDetail, year } = req.body;

      // Get indicators
      const indicators = await storage.getIndicators();
      const filteredIndicators = indicators.filter(ind => 
        indicatorCodes.includes(ind.code)
      );

      // Build CSV headers
      const headers = columns.map((col: string) => {
        const columnLabels: Record<string, string> = {
          code: "Código",
          bpim: "BPIM",
          responsible: "Responsable",
          strategicLine: "Línea Estratégica",
          program: "Programa",
          sector: "Sector",
          ods: "ODS",
          name: "Nombre",
          description: "Descripción",
          unit: "Unidad",
          totalTarget: "Meta Total",
          totalProgress: "Avance Total",
          target2024: "Meta 2024",
          progress2024: "Avance 2024",
          target2025: "Meta 2025",
          progress2025: "Avance 2025",
          target2026: "Meta 2026",
          progress2026: "Avance 2026",
          target2027: "Meta 2027",
          progress2027: "Avance 2027",
          initialBudget2024: "Presupuesto Inicial 2024",
          finalBudget2024: "Presupuesto Final 2024",
          initialBudget2025: "Presupuesto Inicial 2025",
          finalBudget2025: "Presupuesto Final 2025",
          initialBudget2026: "Presupuesto Inicial 2026",
          finalBudget2026: "Presupuesto Final 2026",
          initialBudget2027: "Presupuesto Inicial 2027",
          finalBudget2027: "Presupuesto Final 2027",
          totalInitialBudget: "Presupuesto Inicial Total",
          totalFinalBudget: "Presupuesto Final Total"
        };
        return columnLabels[col] || col;
      });

      if (includeFinancingDetail) {
        headers.push("Fuentes de Financiación - Detalle");
      }

      const csvRows = [headers.join(",")];

      // Build CSV rows
      for (const indicator of filteredIndicators) {
        const row = columns.map((col: string) => {
          const value = (indicator as any)[col];
          if (value === null || value === undefined) return "";
          if (typeof value === "string" && (value.includes(",") || value.includes('"'))) {
            return `"${value.replace(/"/g, '""')}"`;
          }
          return value;
        });

        if (includeFinancingDetail) {
          const budgetDist = await storage.getBudgetDistribution(indicator.code, year);
          const financingDetail = budgetDist.map(bd => 
            `${bd.financingSourceName}: $${bd.amount.toLocaleString()}`
          ).join("; ");
          row.push(`"${financingDetail}"`);
        }

        csvRows.push(row.join(","));
      }

      const csvContent = csvRows.join("\n");

      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="reporte_personalizado_${new Date().toISOString().split('T')[0]}.csv"`);
      res.send('\ufeff' + csvContent); // UTF-8 BOM for Excel compatibility
    } catch (error) {
      console.error('Error generating custom CSV:', error);
      res.status(500).json({ message: 'Error al generar el CSV personalizado' });
    }
  });


  // Enhanced predefined data import with guaranteed persistence  
  app.post('/api/import/predefined-data', isAdmin, async (req, res) => {
    try {
      // Usar usuario por defecto para importación temporal
      const username = req.user ? (req.user as any).username : 'sistema_importacion';

      console.log('📥 IMPORTACIÓN DE DATOS PREDEFINIDOS CON SISTEMA DE PERSISTENCIA');
      console.log('✅ Los datos importados persistirán después de reinicios del servidor');

      // Buscar archivos CSV disponibles en orden de prioridad
      const possiblePaths = [
        './attached_assets/Extenso 02 Septiembre 2025_1758743520005.csv', // ARCHIVO MÁS ACTUALIZADO
        './attached_assets/Formato extenso Nuevo Septiembre2025_1758743225568.csv', // Segunda opción
        './attached_assets/Formato extenso Nuevo Septiembre2025_1758733116795.csv', // Tercera opción
        './attached_assets/version web julio_1750788761799.csv',
        './attached_assets/version web junio_1750730242099.csv',
        './attached_assets/Listado Indicadores Junio 2025_1750706542262.csv',
        './attached_assets/App listado codigos indicadores abril 2025.csv',
        './attached_assets/App abril 2025.csv',
        './attached_assets/App Listado codigo indicadores.csv'
      ];

      let csvPath = null;
      for (const possiblePath of possiblePaths) {
        const fullPath = path.resolve(possiblePath);
        if (fs.existsSync(fullPath)) {
          csvPath = fullPath;
          console.log(`   - Usando archivo CSV: ${fullPath}`);
          break;
        }
      }

      if (!csvPath) {
        return res.status(404).json({ message: 'No se encontró ningún archivo CSV predefinido' });
      }

      const indicators: any[] = [];

      // Procesar el archivo CSV con manejo mejorado de columnas
      await new Promise<void>((resolve, reject) => {
        fs.createReadStream(csvPath)
          .pipe(csv())
          .on('data', (row) => {
            try {
              // Función helper para obtener valor de columna con variaciones de nombre
              const getColumnValue = (possibleNames: string[]): string => {
                for (const name of possibleNames) {
                  if (row[name] !== undefined && row[name] !== null && row[name] !== '') {
                    return String(row[name]).trim();
                  }
                }
                return '';
              };

              // Función helper para parsear valores enteros
              function parseIntegerValue(value: string): number | undefined {
                if (!value || value.trim() === '' || value === '0') return undefined;
                const parsed = parseInt(value.trim(), 10);
                return isNaN(parsed) ? undefined : parsed;
              }

              const indicator: any = {
                code: getColumnValue(['Codigo', 'Code']),
                responsible: getColumnValue(['Responsable', 'Responsables', 'Resposable']),
                strategicLine: getColumnValue(['Linea estrategica', 'Strategic Line']),
                program: getColumnValue(['Programa', 'Program']),
                name: getColumnValue(['Indicadores', 'Indicators', 'Name']),
                description: getColumnValue(['Descripcion', 'Description']) || '',
                unit: getColumnValue(['Unidad', 'Unit']) || '',
                totalTarget: parseFloat(getColumnValue(['Cantidad Cuatrenio', 'Total Target'])) || 0,

                // New fields from CSV with better parsing
                bpim: parseIntegerValue(getColumnValue(['BPM', 'BPIM', 'Bpim'])),
                sector: getColumnValue(['Sector', 'Sectors']) || undefined,
                ods: parseIntegerValue(getColumnValue(['ODS', 'Ods', 'Objetivo de Desarrollo Sostenible'])),

                target2024: parseFloat(getColumnValue(['Meta 2024', 'Target 2024'])) || 0,
                progress2024: parseFloat(getColumnValue(['Avance 2024', 'Progress 2024'])) || 0,

                target2025: parseFloat(getColumnValue(['Meta 2025', 'Target 2025'])) || 0,
                progress2025: parseFloat(getColumnValue(['Avance 2025', 'Progress 2025'])) || 0,

                target2026: parseFloat(getColumnValue(['Meta 2026', 'Target 2026'])) || 0,
                progress2026: parseFloat(getColumnValue(['Avance 2026', 'Progress 2026'])) || 0,

                target2027: parseFloat(getColumnValue(['Meta 2027', 'Target 2027'])) || 0,
                progress2027: parseFloat(getColumnValue(['Avance 2027', 'Progress 2027'])) || 0,

                totalProgress: parseFloat(getColumnValue(['Avance acumulado', 'Total Progress'])) || 0
              };

              // Añadir campos de presupuesto con manejo flexible de nombres de columna
              const budgetColumns = [
                { field: 'initialBudget2024', possibleNames: ['Presupuesto inicial 2024', 'Presupuesto Inicial 2024', 'Initial Budget 2024'] },
                { field: 'finalBudget2024', possibleNames: ['Presupuesto Final 2024', 'Final Budget 2024'] },
                { field: 'initialBudget2025', possibleNames: ['Presupuesto inicial 2025', 'Presupuesto Inicial 2025', 'Initial Budget 2025'] },
                { field: 'finalBudget2025', possibleNames: ['Presupuesto Final 2025', 'Final Budget 2025'] },
                { field: 'initialBudget2026', possibleNames: ['Presupuesto inicial 2026', 'Presupuesto Inicial 2026', 'Initial Budget 2026'] },
                { field: 'finalBudget2026', possibleNames: ['Presupuesto Final 2026', 'Final Budget 2026'] },
                { field: 'initialBudget2027', possibleNames: ['Presupuesto inicial 2027', 'Presupuesto Inicial 2027', 'Initial Budget 2027'] },
                { field: 'finalBudget2027', possibleNames: ['Presupuesto final 2027', 'Presupuesto Final 2027', 'Final Budget 2027'] },
                { field: 'totalInitialBudget', possibleNames: ['Presupuesto Inicial Total', 'Total Initial Budget'] },
                { field: 'totalFinalBudget', possibleNames: ['Presupuesto Final Total', 'Total Final Budget'] }
              ];

              budgetColumns.forEach(({ field, possibleNames }) => {
                const value = getColumnValue(possibleNames);
                if (value) {
                  // Parse currency values - remove $ and commas
                  const cleaned = value.replace(/[$,]/g, '');
                  indicator[field] = parseFloat(cleaned) || 0;
                }
              });

              // Validar que el indicador tenga los campos mínimos requeridos
              if (indicator.code && indicator.responsible && indicator.strategicLine && 
                  indicator.program && indicator.name && indicator.bpim !== undefined && // BPIM is now required
                  indicator.ods !== undefined) { // ODS is now required
                indicators.push(indicator);
              } else {
                console.warn(`Fila omitida por falta de datos requeridos (code, responsible, strategicLine, program, name, bpim, ods):`, row);
              }
            } catch (error) {
              console.error('Error procesando fila CSV:', row, error);
            }
          })
          .on('end', () => {
            console.log(`Procesadas ${indicators.length} filas válidas del CSV.`);
            resolve();
          })
          .on('error', (error) => {
            console.error('Error en el stream del CSV:', error);
            reject(error);
          });
      });

      // Importar todos los indicadores desde CSV con persistencia garantizada
      if (indicators.length > 0) {
        const savedIndicators = await storage.bulkCreateIndicators(indicators);
        console.log(`✅ DATOS PREDEFINIDOS IMPORTADOS: ${indicators.length} indicadores con persistencia garantizada`);

        // Crear registro de auditoría para la importación masiva
        try {
          await storage.createUpdateHistory({
            indicatorCode: 'PREDEFINED_IMPORT_PERSISTENT',
            username: username,
            year: 'bulk_import',
            previousValue: 0,
            newValue: savedIndicators.length,
            observations: `Importación persistente de datos predefinidos: ${savedIndicators.length} indicadores - datos garantizados contra reinicios`
          });
        } catch (histError) {
          console.log('Nota: No se pudo crear registro de auditoría (tabla podría no existir)');
        }

        return res.status(200).json({ 
          message: `✅ Importación exitosa: ${savedIndicators.length} indicadores predefinidos importados con persistencia garantizada`,
          count: savedIndicators.length,
          source: 'Datos predefinidos con persistencia',
          persistenceGuaranteed: true
        });
      } else {
        return res.status(400).json({ message: 'No se encontraron indicadores válidos para importar en el archivo o faltan campos requeridos (code, responsible, strategicLine, program, name, bpim, ods)' });
      }

    } catch (error) {
      console.error('Error al importar datos predefinidos:', error);
      return res.status(500).json({ 
        message: 'Error al importar los datos predefinidos', 
        error: (error as Error).message
      });
    }
  });

  // Export indicators CSV template
  app.get('/api/export/template', (req, res) => {
    const csvHeader = "Codigo,Responsable,Linea estrategica,Programa,Indicadores,Descripcion,Unidad,Cantidad Cuatrenio,Meta 2024,Avance 2024,Meta 2025,Avance 2025,Meta 2026,Avance 2026,Meta 2027,Avance 2027,Avance acumulado,Presupuesto Inicial 2024,Presupuesto Final 2024,Presupuesto Inicial 2025,Presupuesto Final 2025,Presupuesto Inicial 2026,Presupuesto Final 2026,Presupuesto Inicial 2027,Presupuesto Final 2027,Presupuesto Inicial Total,Presupuesto Final Total,BPIM,Sector,ODS\n";
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename=plantilla_indicadores.csv');
    res.send(csvHeader);
  });

  // DESHABILITADO: Initialize sample data from CSV file if available
  // FUNCIÓN PERMANENTEMENTE DESHABILITADA PARA GARANTIZAR PERSISTENCIA DE DATOS
  /*
  try {
    // All automatic CSV import code has been permanently disabled
    // to prevent data loss and ensure persistence
  } catch (error) {
    console.error('Error initializing indicators from CSV:', error);
  }
  */

  // Registrar que la importación automática está deshabilitada para proteger los datos
  console.log('🚫 IMPORTACIÓN AUTOMÁTICA DE CSV DESHABILITADA - Protegiendo persistencia de datos');
  console.log('✓ Los datos existentes en la base de datos se mantendrán sin modificaciones');
  console.log('ℹ️  Para importar nuevos datos, use el panel de administración CSV import');

  // Verificar persistencia de datos al inicio del servidor
  try {
    const persistenceStatus = await storage.verifyDataPersistence();
    console.log(`✅ VERIFICACIÓN DE PERSISTENCIA COMPLETADA:`);
    console.log(`   - Indicadores: ${persistenceStatus.indicators}`);
    console.log(`   - Actualizaciones: ${persistenceStatus.updates}`);
    console.log(`   - Estado: ${persistenceStatus.status}`);
  } catch (error) {
    console.error('Error verificando persistencia de datos:', error);
  }

  // Database optimization endpoints (admin only)
  app.post('/api/optimize-database', isAdmin, async (req, res) => {
    try {
      await storage.optimizeDatabase();
      res.json({ message: 'Database optimization completed successfully' });
    } catch (error) {
      console.error('Error optimizing database:', error);
      res.status(500).json({ message: 'Error optimizing database', error: (error as Error).message });
    }
  });

  app.post('/api/cleanup-data', isAdmin, async (req, res) => {
    try {
      await storage.cleanupObsoleteData();
      res.json({ message: 'Data cleanup completed successfully' });
    } catch (error) {
      console.error('Error cleaning up data:', error);
      res.status(500).json({ message: 'Error cleaning up data', error: (error as Error).message });
    }
  });

  // Financing Sources routes
  app.get('/api/financing-sources', async (req, res) => {
    try {
      const financingSources = await storage.getAllFinancingSources();
      res.json(financingSources);
    } catch (error) {
      console.error('Error getting financing sources:', error);
      res.status(500).json({ message: 'Error retrieving financing sources', error: (error as Error).message });
    }
  });

  app.get('/api/financing-sources/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const financingSource = await storage.getFinancingSourceById(id);
      if (!financingSource) {
        return res.status(404).json({ message: 'Financing source not found' });
      }
      res.json(financingSource);
    } catch (error) {
      console.error('Error getting financing source:', error);
      res.status(500).json({ message: 'Error retrieving financing source', error: (error as Error).message });
    }
  });

  app.post('/api/financing-sources', isAdmin, async (req, res) => {
    try {
      const validatedData = insertFinancingSourceSchema.parse(req.body);
      const newFinancingSource = await storage.createFinancingSource(validatedData);
      res.status(201).json(newFinancingSource);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: 'Validation error', error: validationError.toString() });
      }
      console.error('Error creating financing source:', error);
      res.status(500).json({ message: 'Error creating financing source', error: (error as Error).message });
    }
  });

  // Update financing source
  app.patch('/api/financing-sources/:id', isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertFinancingSourceSchema.partial().parse(req.body);
      const updatedFinancingSource = await storage.updateFinancingSource(id, validatedData);
      if (!updatedFinancingSource) {
        return res.status(404).json({ message: 'Financing source not found' });
      }
      res.json(updatedFinancingSource);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: 'Validation error', error: validationError.toString() });
      }
      console.error('Error updating financing source:', error);
      res.status(500).json({ message: 'Error updating financing source', error: (error as Error).message });
    }
  });

  // Budget financing routes
  app.get('/api/budget-financing', async (req, res) => {
    try {
      const { indicatorCode, year } = req.query;
      const budgetFinancing = await storage.getBudgetFinancingByIndicatorAndYear(
        indicatorCode as string,
        year as string
      );
      res.json(budgetFinancing);
    } catch (error) {
      console.error('Error getting budget financing:', error);
      res.status(500).json({ message: 'Error retrieving budget financing', error: (error as Error).message });
    }
  });

  app.post('/api/budget-financing', isAdmin, async (req, res) => {
    try {
      const validatedData = insertBudgetFinancingSchema.parse(req.body);
      const newBudgetFinancing = await storage.createBudgetFinancing(validatedData);
      res.status(201).json(newBudgetFinancing);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: 'Validation error', error: validationError.toString() });
      }
      console.error('Error creating budget financing:', error);
      res.status(500).json({ message: 'Error creating budget financing', error: (error as Error).message });
    }
  });

  app.patch('/api/budget-financing/:id', isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertBudgetFinancingSchema.partial().parse(req.body);
      const updatedBudgetFinancing = await storage.updateBudgetFinancing(id, validatedData);
      if (!updatedBudgetFinancing) {
        return res.status(404).json({ message: 'Budget financing not found' });
      }
      res.json(updatedBudgetFinancing);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: 'Validation error', error: validationError.toString() });
      }
      console.error('Error updating budget financing:', error);
      res.status(500).json({ message: 'Error updating budget financing', error: (error as Error).message });
    }
  });

  app.delete('/api/budget-financing/:id', isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteBudgetFinancing(id);
      if (!deleted) {
        return res.status(404).json({ message: 'Budget financing not found' });
      }
      res.json({ message: 'Budget financing deleted successfully' });
    } catch (error) {
      console.error('Error deleting budget financing:', error);
      res.status(500).json({ message: 'Error deleting budget financing', error: (error as Error).message });
    }
  });

  // Budget financing distribution routes
  app.get('/api/indicators/:code/budget-distribution', async (req, res) => {
    try {
      const { code } = req.params;
      const { year, budgetType } = req.query;

      let distributions = await storage.getIndicatorBudgetDistributions(code);

      // Filter by year and budgetType if provided
      if (year) {
        distributions = distributions.filter(d => d.year === year);
      }
      if (budgetType) {
        distributions = distributions.filter(d => d.budgetType === budgetType);
      }

      res.json(distributions);
    } catch (error) {
      res.status(500).json({ 
        message: 'Error fetching budget distributions', 
        error: (error as Error).message 
      });
    }
  });

  app.post('/api/indicators/:code/budget-distribution', isAdmin, async (req, res) => {
    try {
      const { code } = req.params;
      const distribution = { ...req.body, indicatorCode: code };
      await storage.saveBudgetDistribution(distribution);
      res.json({ message: 'Budget distribution saved successfully' });
    } catch (error) {
      res.status(500).json({ 
        message: 'Error saving budget distribution', 
        error: (error as Error).message 
      });
    }
  });

  app.get('/api/budget-financing/:indicatorCode/:year', async (req, res) => {
    try {
      const { indicatorCode, year } = req.params;
      const financing = await storage.getBudgetFinancing(indicatorCode, year);
      res.json(financing);
    } catch (error) {
      res.status(500).json({ 
        message: 'Error fetching budget financing', 
        error: (error as Error).message 
      });
    }
  });

  // Ruta para obtener análisis de fuentes de financiación
  app.get('/api/budget-analysis/financing-sources', async (req, res) => {
    try {
      const { year } = req.query;

      // Obtener todas las fuentes de financiación
      const financingSources = await storage.getAllFinancingSources();

      // Obtener indicadores con presupuesto
      const indicators = await storage.getAllIndicators();

      // Calcular distribución por fuente de financiación
      const financingAnalysis = financingSources.map(source => ({
        id: source.id,
        name: source.name,
        totalAmount: 0, // Será calculado basado en las asignaciones
        indicators: [] as string[]
      }));

      res.json(financingAnalysis);
    } catch (error) {
      res.status(500).json({ 
        message: 'Error fetching financing sources analysis', 
        error: (error as Error).message 
      });
    }
  });

  // ====== CHAT AI ROUTES ======
  
  // Configure OpenAI client for OpenRouter
  const openai = new OpenAI({
    baseURL: "https://openrouter.ai/api/v1",
    apiKey: process.env.OPEN_ROUTER,
  });

  // Chat management methods
  const getUserConversations = async (userId: number): Promise<any[]> => {
    return await storage.getUserConversations(userId);
  };

  const getConversationMessages = async (conversationId: number): Promise<any[]> => {
    return await storage.getConversationMessages(conversationId);
  };

  // POST /api/chat - Send message and get AI response
  app.post('/api/chat', async (req, res) => {
    try {
      // Check if user is authenticated manually if needed or use session
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'No autorizado', authenticated: false });
      }

      const validatedData = chatRequestSchema.parse(req.body);
      const user = req.user as any;

      // Get or create conversation
      let conversationId = validatedData.conversationId;
      
      if (!conversationId) {
        // Create new conversation with first message preview as title
        const title = validatedData.message.substring(0, 50) + (validatedData.message.length > 50 ? '...' : '');
        const conversation = await storage.createConversation(user.id, title);
        conversationId = conversation.id;
      }

      // Save user message
      await storage.createMessage(conversationId!, 'user', validatedData.message);

      // Get conversation history for context
      const messages = await storage.getConversationMessages(conversationId!);
      
      // Get ALL data from database for comprehensive context
      const indicators = await storage.getAllIndicators();
      const financingSources = await storage.getAllFinancingSources();
      const updateHistory = await storage.getUpdateHistory(50);

      // Build comprehensive statistics
      const strategicLines = Array.from(new Set(indicators.map(i => i.strategicLine)));
      const programs = Array.from(new Set(indicators.map(i => i.program)));
      const responsibles = Array.from(new Set(indicators.map(i => i.responsible)));
      const sectors = Array.from(new Set(indicators.map(i => i.sector).filter(Boolean)));
      const bpims = Array.from(new Set(indicators.map(i => i.bpim).filter(Boolean)));
      const odsValues = Array.from(new Set(indicators.map(i => i.ods).filter(Boolean)));

      // Calculate progress statistics
      const totalBudget2024 = indicators.reduce((sum, ind) => sum + (ind.finalBudget2024 || 0), 0);
      const totalBudget2025 = indicators.reduce((sum, ind) => sum + (ind.finalBudget2025 || 0), 0);
      const totalBudgetCuatrienio = indicators.reduce((sum, ind) => sum + (ind.totalFinalBudget || 0), 0);
      
      const avgProgress2024 = indicators.length > 0 
        ? indicators.reduce((sum, ind) => sum + (ind.progress2024 / ind.target2024 * 100 || 0), 0) / indicators.length 
        : 0;
      const avgProgress2025 = indicators.length > 0 
        ? indicators.reduce((sum, ind) => sum + (ind.progress2025 / ind.target2025 * 100 || 0), 0) / indicators.length 
        : 0;

      // Build detailed context with all indicators data
      const detailedIndicators = indicators.map(ind => ({
        code: ind.code,
        name: ind.name,
        description: ind.description,
        strategicLine: ind.strategicLine,
        program: ind.program,
        responsible: ind.responsible,
        sector: ind.sector,
        bpim: ind.bpim,
        ods: ind.ods,
        target2024: ind.target2024,
        progress2024: ind.progress2024,
        progress2024Percent: ind.target2024 > 0 ? ((ind.progress2024 / ind.target2024) * 100).toFixed(1) : '0',
        target2025: ind.target2025,
        progress2025: ind.progress2025,
        progress2025Percent: ind.target2025 > 0 ? ((ind.progress2025 / ind.target2025) * 100).toFixed(1) : '0',
        target2026: ind.target2026,
        progress2026: ind.progress2026,
        target2027: ind.target2027,
        progress2027: ind.progress2027,
        totalTarget: ind.totalTarget,
        totalProgress: ind.totalProgress,
        totalProgressPercent: ind.totalTarget > 0 ? ((ind.totalProgress / ind.totalTarget) * 100).toFixed(1) : '0',
        budget2024: ind.finalBudget2024 || ind.initialBudget2024,
        budget2025: ind.finalBudget2025 || ind.initialBudget2025,
        totalBudget: ind.totalFinalBudget || ind.totalInitialBudget
      }));

      // Build system prompt with comprehensive data
      const systemPrompt = `Eres un asistente experto en análisis del Plan de Desarrollo Municipal "San Jerónimo, Antioquia 2024-2027".

## TU FUNCIÓN PRINCIPAL
Analizar indicadores del plan de desarrollo con datos actualizados en tiempo real y proporcionar ideas prácticas, contextualizadas y realizables. También puedes explicar sobre presupuestos, fuentes de financiación y avances del plan.

## FORMATO DE RESPUESTA - MUY IMPORTANTE
Utiliza SIEMPRE formato Markdown para estructurar tus respuestas de forma clara y visual:

### Estructura tu respuesta así:
1. **Título principal** con ##
2. **Secciones** con ###
3. **Negrita** para conceptos clave
4. *Cursiva* para énfasis
5. Listas numeradas o con viñetas
6. Tablas cuando presentes múltiples datos
7. Separadores visuales con ---
8. Bloques de código o resaltado con \`backticks\`

### Ejemplo de formato ideal:
\`\`\`
## 📊 Análisis del Indicador

**Código:** L1P3-05
**Meta 2025:** 100 beneficiarios
**Avance actual:** 45 beneficiarios (45%)

### 🎯 Situación Actual
El indicador presenta un avance moderado...

### 💡 Recomendaciones
1. **Acción inmediata:**
   - Implementar estrategia X
   - Contactar con entidad Y

2. **Alianzas estratégicas:**
   - Gobernación de Antioquia
   - SENA regional

### 💰 Presupuesto Requerido
| Actividad | Costo Estimado |
|-----------|----------------|
| Capacitación | $5,000,000 |
| Materiales | $3,000,000 |

---
**Total:** $8,000,000 COP
\`\`\`

## CONTEXTO DEL MUNICIPIO
- **Ubicación**: San Jerónimo, Antioquia, Colombia (Occidente antioqueño)
- **Características**: Municipio de vocación agropecuaria con potencial turístico
- **Economía**: Agricultura (café, plátano), ganadería, comercio local, turismo rural
- **Población**: Aproximadamente 15,000 habitantes
- **Período del plan**: 2024-2027 (cuatrienio actual)

## DATOS ACTUALIZADOS DEL PLAN DE DESARROLLO

### Estadísticas Generales:
- **Total de indicadores:** ${indicators.length}
- **Líneas estratégicas:** ${strategicLines.length}
- **Programas:** ${programs.length}
- **Responsables:** ${responsibles.length}
- **Sectores:** ${sectors.length}
- **BPIM únicos:** ${bpims.length}
- **ODS representados:** ${odsValues.length}

### Presupuesto Total:
- **2024:** $${totalBudget2024.toLocaleString('es-CO')} COP
- **2025:** $${totalBudget2025.toLocaleString('es-CO')} COP
- **Cuatrienio:** $${totalBudgetCuatrienio.toLocaleString('es-CO')} COP

### Avance Promedio:
- **2024:** ${avgProgress2024.toFixed(1)}%
- **2025:** ${avgProgress2025.toFixed(1)}%

### Líneas Estratégicas:
${strategicLines.map((line, i) => `${i + 1}. ${line}`).join('\n')}

### Fuentes de Financiación Disponibles:
${financingSources.map(fs => `- ${fs.name}${fs.description ? ': ' + fs.description : ''}`).join('\n')}

### Actualizaciones Recientes (últimas 50):
${updateHistory.slice(0, 10).map(h => `- ${h.indicatorCode}: ${h.observations || 'Actualización'} (${new Date(h.createdAt).toLocaleDateString('es-CO')})`).join('\n')}

## BASE DE DATOS COMPLETA DE INDICADORES
Tienes acceso a todos los ${indicators.length} indicadores con sus datos completos:

${JSON.stringify(detailedIndicators, null, 2)}

## INSTRUCCIONES DE ANÁLISIS

Cuando analices indicadores:

1. **Usa los datos reales** de la base de datos
2. **Presenta datos en tablas** cuando sea apropiado
3. **Calcula porcentajes** de avance
4. **Identifica brechas** entre metas y avances
5. **Propón soluciones específicas** para San Jerónimo

### Formato de análisis de indicador:
\`\`\`
## 📈 [Nombre del Indicador]

### 📋 Información General
- **Código:** [código]
- **Línea Estratégica:** [línea]
- **Programa:** [programa]
- **Responsable:** [responsable]
- **Sector:** [sector]
- **BPIM:** [bpim]
- **ODS:** [ods]

### 🎯 Metas y Avances

| Año | Meta | Avance | % Cumplimiento | Estado |
|-----|------|--------|----------------|--------|
| 2024 | X | Y | Z% | ✅/⚠️/❌ |
| 2025 | X | Y | Z% | ✅/⚠️/❌ |

### 💰 Presupuesto Asignado
- **2024:** $X COP
- **2025:** $Y COP
- **Total:** $Z COP

### 💡 Análisis y Recomendaciones
[Análisis detallado con acciones concretas]
\`\`\`

## REGLAS DE FORMATO OBLIGATORIAS
1. SIEMPRE usa emojis relevantes (📊, 💡, ⚠️, ✅, etc.)
2. SIEMPRE estructura con encabezados ##, ###
3. SIEMPRE usa **negrita** para datos clave
4. SIEMPRE usa tablas para comparaciones
5. SIEMPRE usa listas numeradas o con viñetas
6. SIEMPRE separa secciones con líneas ---
7. SIEMPRE incluye datos numéricos concretos
8. SIEMPRE formatea montos: $X,XXX,XXX COP

Recuerda: Tu objetivo es ayudar al municipio a cumplir sus metas con información precisa, actualizada y presentada de forma clara y profesional.`;

      // Build messages for OpenRouter
      const chatMessages = [
        { role: 'system', content: systemPrompt },
        ...messages.map((msg: any) => ({
          role: msg.role,
          content: msg.content
        }))
      ];

      // Call OpenRouter API with Gemini
      const completion = await openai.chat.completions.create({
        model: 'google/gemini-2.5-flash-lite-preview-09-2025',
        messages: chatMessages as any,
        temperature: 0.7,
        max_tokens: 3000,
      });

      const assistantMessage = completion.choices[0]?.message?.content || 'Lo siento, no pude generar una respuesta.';

      // Save assistant message
      await storage.createMessage(conversationId!, 'assistant', assistantMessage);

      res.json({
        conversationId,
        message: assistantMessage,
      });

    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: 'Validation error', error: validationError.toString() });
      }
      console.error('Error in chat:', error);
      res.status(500).json({ 
        message: 'Error processing chat message', 
        error: (error as Error).message 
      });
    }
  });

  // GET /api/chat/conversations - Get user's conversations
  app.get('/api/chat/conversations', async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ authenticated: false });
      }
      const user = req.user as any;
      const conversations = await storage.getUserConversations(user.id);
      res.json(conversations);
    } catch (error) {
      console.error('Error fetching conversations:', error);
      res.status(500).json({ 
        message: 'Error fetching conversations', 
        error: (error as Error).message 
      });
    }
  });

  // GET /api/chat/conversations/:id/messages - Get conversation messages
  app.get('/api/chat/conversations/:id/messages', async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ authenticated: false });
      }
      const conversationId = parseInt(req.params.id);
      const messages = await storage.getConversationMessages(conversationId);
      res.json(messages);
    } catch (error) {
      console.error('Error fetching messages:', error);
      res.status(500).json({ 
        message: 'Error fetching messages', 
        error: (error as Error).message 
      });
    }
  });

  // DELETE /api/chat/conversations/:id - Delete conversation
  app.delete('/api/chat/conversations/:id', async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ authenticated: false });
      }
      const conversationId = parseInt(req.params.id);
      await storage.deleteConversation(conversationId);
      res.json({ message: 'Conversation deleted successfully' });
    } catch (error) {
      console.error('Error deleting conversation:', error);
      res.status(500).json({ 
        message: 'Error deleting conversation', 
        error: (error as Error).message 
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}