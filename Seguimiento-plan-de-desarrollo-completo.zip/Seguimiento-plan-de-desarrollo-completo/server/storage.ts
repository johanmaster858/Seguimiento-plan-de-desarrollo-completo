// 1. Corrected the bulkCreateIndicators function to properly create audit history entries.
import {
  users, type User, type InsertUser,
  indicators, type Indicator, type InsertIndicator,
  updateHistory, type UpdateHistory, type InsertUpdateHistory,
  financingSources, type FinancingSource, type InsertFinancingSource,
  budgetFinancing, type BudgetFinancing, type InsertBudgetFinancing,
  chatConversations, type ChatConversation, type InsertChatConversation,
  chatMessages, type ChatMessage, type InsertChatMessage,
  UpdateIndicatorProgress,
} from "@shared/schema";
import { db, pool } from "./db";
import { eq, desc, sql, and } from "drizzle-orm";
import { getStatusForIndicator } from "@/lib/utils";
import bcrypt from "bcrypt";
import dotenv from "dotenv";

dotenv.config();

// Define BudgetDistribution type if not imported from schema
// This is a placeholder and should match the actual structure expected by saveBudgetDistribution
interface BudgetDistribution {
  indicatorCode: string;
  year: string;
  budgetType: string;
  totalAmount: number;
  distributions: {
    financingSourceId: number;
    amount: number;
    percentage?: number;
  }[];
}

export interface IStorage {
  // User management
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createDefaultAdminUser(): Promise<User>;

  // Database management
  resetIndicatorsTable(): Promise<void>;
  optimizeDatabase(): Promise<void>;
  cleanupObsoleteData(): Promise<void>;

  // Indicator management
  getAllIndicators(): Promise<Indicator[]>;
  getIndicatorByCode(code: string): Promise<Indicator | undefined>;
  createIndicator(indicator: InsertIndicator): Promise<Indicator>;
  updateIndicatorProgress(update: UpdateIndicatorProgress, username: string): Promise<Indicator>;
  bulkCreateIndicators(indicators: InsertIndicator[], username: string): Promise<Indicator[]>;

  // Filtering
  getIndicatorsByFilters(filters: {
    strategicLine?: string;
    program?: string;
    responsible?: string;
    bpim?: string;
    sector?: string;
    ods?: string;
    year?: string;
    status?: string[];
  }): Promise<Indicator[]>;

  // Update history
  getUpdateHistory(limit?: number): Promise<UpdateHistory[]>;
  createUpdateHistory(history: InsertUpdateHistory): Promise<UpdateHistory>;
  getUpdateHistoryByIndicator(code: string): Promise<UpdateHistory[]>;

  // Financing sources management
  getAllFinancingSources(): Promise<FinancingSource[]>;
  getFinancingSourceById(id: number): Promise<FinancingSource | undefined>;
  createFinancingSource(source: InsertFinancingSource): Promise<FinancingSource>;
  updateFinancingSource(id: number, source: Partial<InsertFinancingSource>): Promise<FinancingSource>;

  // Budget financing management
  getBudgetFinancingByIndicator(indicatorCode: string): Promise<BudgetFinancing[]>;
  getBudgetFinancingByYear(year: string): Promise<BudgetFinancing[]>;
  getBudgetFinancingByIndicatorAndYear(indicatorCode: string, year: string): Promise<BudgetFinancing[]>;
  createBudgetFinancing(financing: InsertBudgetFinancing): Promise<BudgetFinancing>;
  updateBudgetFinancing(id: number, financing: Partial<InsertBudgetFinancing>): Promise<BudgetFinancing>;
  deleteBudgetFinancing(id: number): Promise<void>;

  // Added methods for budget distribution
  getBudgetFinancing(indicatorCode: string, year: string): Promise<BudgetFinancing[]>;
  saveBudgetDistribution(distribution: BudgetDistribution): Promise<void>;
  getIndicatorBudgetDistributions(indicatorCode: string): Promise<any[]>;

  // Chat management
  getUserConversations(userId: number): Promise<any[]>;
  getConversationMessages(conversationId: number): Promise<any[]>;
  createConversation(userId: number, title: string): Promise<any>;
  createMessage(conversationId: number, role: string, content: string): Promise<any>;
  deleteConversation(conversationId: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private indicators: Map<string, Indicator>;
  private history: Map<number, UpdateHistory>;
  private financingSources: Map<number, FinancingSource>;
  private budgetFinancing: Map<number, BudgetFinancing>;
  private currentUserId: number;
  private currentHistoryId: number;
  private currentFinancingSourceId: number;
  private currentBudgetFinancingId: number;

  constructor() {
    this.users = new Map();
    this.indicators = new Map();
    this.history = new Map();
    this.financingSources = new Map();
    this.budgetFinancing = new Map();
    this.currentUserId = 1;
    this.currentHistoryId = 1;
    this.currentFinancingSourceId = 1;
    this.currentBudgetFinancingId = 1;

    // Add default admin user
    this.createUser({
      username: "admin@sanjeronimo.gov.co",
      password: "admin123", // In a real app this would be hashed
      isAdmin: true
    });
  }

  // User management methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    // Hash password if it's not already hashed
    let hashedPassword = insertUser.password;
    if (!insertUser.password.startsWith('$2b$')) {
      hashedPassword = await bcrypt.hash(insertUser.password, 10);
    }
    const user: User = { ...insertUser, password: hashedPassword, id };
    this.users.set(id, user);
    return user;
  }

  async createDefaultAdminUser(): Promise<User> {
    // Verificar si ya existe un usuario admin
    const adminUser = await this.getUserByUsername('admin');
    if (adminUser) {
      return adminUser;
    }

    // Crear usuario admin con contraseña hasheada usando bcrypt
    const hashedPassword = await bcrypt.hash('SanJeronimo2024', 10);
    return await this.createUser({
      username: 'admin',
      password: hashedPassword,
      isAdmin: true
    });
  }

  async resetIndicatorsTable(): Promise<void> {
    // Limpiar todos los indicadores y su historial
    this.indicators.clear();
    this.history.clear();
  }

  async optimizeDatabase(): Promise<void> {
    // En memoria, simplemente limpiamos datos obsoletos
    await this.cleanupObsoleteData();
    console.log('Optimización de base de datos en memoria completada.');
  }

  async cleanupObsoleteData(): Promise<void> {
    // Limpiar historial muy antiguo (simulado)
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    for (const [id, entry] of this.history.entries()) {
      if (entry.createdAt && entry.createdAt < sixMonthsAgo) {
        this.history.delete(id);
      }
    }

    console.log('Limpieza de datos obsoletos en memoria completada.');
  }

  // Indicator management methods
  async getAllIndicators(): Promise<Indicator[]> {
    return Array.from(this.indicators.values());
  }

  async getIndicatorByCode(code: string): Promise<Indicator | undefined> {
    return this.indicators.get(code);
  }

  async createIndicator(indicator: InsertIndicator): Promise<Indicator> {
    const newIndicator: Indicator = {
      ...indicator,
      id: this.indicators.size + 1,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    this.indicators.set(indicator.code, newIndicator);
    return newIndicator;
  }

  async updateIndicatorProgress(update: UpdateIndicatorProgress, username: string): Promise<Indicator> {
    const indicator = this.indicators.get(update.code);

    if (!indicator) {
      throw new Error(`Indicator with code ${update.code} not found`);
    }

    const updatedIndicator = { ...indicator, updatedAt: new Date() };
    let previousValue = 0;

    // Update the progress for the specified year
    switch (update.year) {
      case "2024":
        previousValue = indicator.progress2024;
        updatedIndicator.progress2024 = update.progress;
        if (update.initialBudget !== undefined) {
          updatedIndicator.initialBudget2024 = update.initialBudget;
        }
        if (update.finalBudget !== undefined) {
          updatedIndicator.finalBudget2024 = update.finalBudget;
        }
        break;
      case "2025":
        previousValue = indicator.progress2025;
        updatedIndicator.progress2025 = update.progress;
        if (update.initialBudget !== undefined) {
          updatedIndicator.initialBudget2025 = update.initialBudget;
        }
        if (update.finalBudget !== undefined) {
          updatedIndicator.finalBudget2025 = update.finalBudget;
        }
        break;
      case "2026":
        previousValue = indicator.progress2026;
        updatedIndicator.progress2026 = update.progress;
        if (update.initialBudget !== undefined) {
          updatedIndicator.initialBudget2026 = update.initialBudget;
        }
        if (update.finalBudget !== undefined) {
          updatedIndicator.finalBudget2026 = update.finalBudget;
        }
        break;
      case "2027":
        previousValue = indicator.progress2027;
        updatedIndicator.progress2027 = update.progress;
        if (update.initialBudget !== undefined) {
          updatedIndicator.initialBudget2027 = update.initialBudget;
        }
        if (update.finalBudget !== undefined) {
          updatedIndicator.finalBudget2027 = update.finalBudget;
        }
        break;
    }

    // Recalculate total progress
    updatedIndicator.totalProgress =
      updatedIndicator.progress2024 +
      updatedIndicator.progress2025 +
      updatedIndicator.progress2026 +
      updatedIndicator.progress2027;

    // Update the indicator in storage
    this.indicators.set(update.code, updatedIndicator);

    // Record the update in history
    let observations = update.observations || "";

    // Add budget information to observations
    if (update.initialBudget !== undefined || update.finalBudget !== undefined) {
      observations +=
        (update.initialBudget !== undefined ? ` Presupuesto inicial: ${update.initialBudget}.` : '') +
        (update.finalBudget !== undefined ? ` Presupuesto definitivo: ${update.finalBudget}.` : '');
    }

    this.createUpdateHistory({
      indicatorCode: update.code,
      year: update.year,
      username,
      previousValue,
      newValue: update.progress,
      observations
    });

    return updatedIndicator;
  }

  async bulkCreateIndicators(newIndicators: InsertIndicator[], username: string): Promise<Indicator[]> {
    const createdIndicators: Indicator[] = [];

    for (const indicator of newIndicators) {
      const newIndicator = await this.createIndicator(indicator);
      createdIndicators.push(newIndicator);
    }

    // Crear registro de auditoría para la importación masiva
    await this.createUpdateHistory({
      indicatorCode: 'PREDEFINED_IMPORT_PERSISTENT',
      username: username,
      year: 'bulk_import',
      previousValue: 0,
      newValue: createdIndicators.length,
      observations: `Importación persistente de datos predefinidos: ${createdIndicators.length} indicadores - datos garantizados contra reinicios`
    });

    return createdIndicators;
  }

  // Filtering methods
  async getIndicatorsByFilters(filters: {
    strategicLine?: string;
    program?: string;
    responsible?: string;
    bpim?: string;
    sector?: string;
    ods?: string;
    year?: string;
    status?: string[];
  }): Promise<Indicator[]> {
    let indicators = Array.from(this.indicators.values());

    // Apply filters
    if (filters.strategicLine) {
      indicators = indicators.filter(i => i.strategicLine === filters.strategicLine);
    }

    if (filters.program) {
      indicators = indicators.filter(i => i.program === filters.program);
    }

    if (filters.responsible) {
      indicators = indicators.filter(i => i.responsible === filters.responsible);
    }

    // New filters for BPIM, Sector and ODS
    if (filters.bpim) {
      // Compare as strings since BPIM can be very large numbers stored as strings
      indicators = indicators.filter(i => String(i.bpim) === String(filters.bpim));
    }

    if (filters.sector) {
      indicators = indicators.filter(i => i.sector === filters.sector);
    }

    if (filters.ods) {
      const odsValue = parseInt(filters.ods);
      indicators = indicators.filter(i => i.ods === odsValue);
    }

    // Filter by status if specified and year
    if (filters.status && filters.status.length > 0 && filters.year) {
      const year = filters.year;

      indicators = indicators.filter(indicator => {
        let targetField: keyof Indicator;
        let progressField: keyof Indicator;

        switch (year) {
          case "2024":
            targetField = "target2024";
            progressField = "progress2024";
            break;
          case "2025":
            targetField = "target2025";
            progressField = "progress2025";
            break;
          case "2026":
            targetField = "target2026";
            progressField = "progress2026";
            break;
          case "2027":
            targetField = "target2027";
            progressField = "progress2027";
            break;
          default:
            return true;
        }

        const target = indicator[targetField] as number;
        const progress = indicator[progressField] as number;

        // Calculate completion percentage
        const percentage = target > 0 ? (progress / target) * 100 : 0;

        // Check which status filters apply
        return filters.status.some(status => {
          switch (status) {
            case "avanzado":
              return percentage >= 90;
            case "en-tiempo":
              return percentage >= 70 && percentage < 90;
            case "retrasado":
              return percentage < 70;
            default:
              return false;
          }
        });
      });
    }

    return indicators;
  }

  // Update history methods
  async getUpdateHistory(limit = 100): Promise<UpdateHistory[]> {
    return Array.from(this.history.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }

  async createUpdateHistory(history: InsertUpdateHistory): Promise<UpdateHistory> {
    const id = this.currentHistoryId++;
    const newHistory: UpdateHistory = {
      ...history,
      id,
      createdAt: new Date(),
    };

    this.history.set(id, newHistory);
    return newHistory;
  }

  async getUpdateHistoryByIndicator(code: string): Promise<UpdateHistory[]> {
    return Array.from(this.history.values())
      .filter(h => h.indicatorCode === code)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  // Financing sources methods
  async getAllFinancingSources(): Promise<FinancingSource[]> {
    return Array.from(this.financingSources.values()).filter(fs => fs.active !== false);
  }

  async getFinancingSourceById(id: number): Promise<FinancingSource | undefined> {
    return this.financingSources.get(id);
  }

  async createFinancingSource(source: InsertFinancingSource): Promise<FinancingSource> {
    const id = this.currentFinancingSourceId++;
    const newSource: FinancingSource = {
      ...source,
      id,
      active: source.active ?? true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    this.financingSources.set(id, newSource);
    return newSource;
  }

  async updateFinancingSource(id: number, source: Partial<InsertFinancingSource>): Promise<FinancingSource> {
    const existingSource = this.financingSources.get(id);
    if (!existingSource) {
      throw new Error(`Financing source with ID ${id} not found`);
    }

    const updatedSource: FinancingSource = {
      ...existingSource,
      ...source,
      updatedAt: new Date(),
    };

    this.financingSources.set(id, updatedSource);
    return updatedSource;
  }

  // Budget financing methods
  async getBudgetFinancingByIndicator(indicatorCode: string): Promise<BudgetFinancing[]> {
    return Array.from(this.budgetFinancing.values())
      .filter(bf => bf.indicatorCode === indicatorCode);
  }

  async getBudgetFinancingByYear(year: string): Promise<BudgetFinancing[]> {
    return Array.from(this.budgetFinancing.values())
      .filter(bf => bf.year === year);
  }

  async getBudgetFinancingByIndicatorAndYear(indicatorCode: string, year: string): Promise<BudgetFinancing[]> {
    return Array.from(this.budgetFinancing.values())
      .filter(bf => bf.indicatorCode === indicatorCode && bf.year === year);
  }

  async createBudgetFinancing(financing: InsertBudgetFinancing): Promise<BudgetFinancing> {
    const id = this.currentBudgetFinancingId++;
    const newFinancing: BudgetFinancing = {
      ...financing,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    this.budgetFinancing.set(id, newFinancing);
    return newFinancing;
  }

  async updateBudgetFinancing(id: number, financing: Partial<InsertBudgetFinancing>): Promise<BudgetFinancing> {
    const existingFinancing = this.budgetFinancing.get(id);
    if (!existingFinancing) {
      throw new Error(`Budget financing with ID ${id} not found`);
    }

    const updatedFinancing: BudgetFinancing = {
      ...existingFinancing,
      ...financing,
      updatedAt: new Date(),
    };

    this.budgetFinancing.set(id, updatedFinancing);
    return updatedFinancing;
  }

  async deleteBudgetFinancing(id: number): Promise<void> {
    const deleted = this.budgetFinancing.delete(id);
    if (!deleted) {
      throw new Error(`Budget financing with ID ${id} not found`);
    }
  }

  // Added methods for budget distribution
  async getBudgetFinancing(indicatorCode: string, year: string): Promise<BudgetFinancing[]> {
    return Array.from(this.budgetFinancing.values())
      .filter(bf => bf.indicatorCode === indicatorCode && bf.year === year);
  }

  async saveBudgetDistribution(distribution: BudgetDistribution): Promise<void> {
    // Eliminar distribuciones existentes
    this.budgetFinancing.forEach((bf, id) => {
      if (bf.indicatorCode === distribution.indicatorCode && bf.year === distribution.year && bf.budgetType === distribution.budgetType) {
        this.budgetFinancing.delete(id);
      }
    });

    // Insertar nuevas distribuciones
    if (distribution.distributions.length > 0) {
      distribution.distributions.forEach(dist => {
        const id = this.currentBudgetFinancingId++;
        const percentage = dist.percentage || (dist.amount / distribution.totalAmount) * 100;
        const newFinancing: BudgetFinancing = {
          id,
          indicatorCode: distribution.indicatorCode,
          year: distribution.year,
          budgetType: distribution.budgetType,
          financingSourceId: dist.financingSourceId,
          amount: dist.amount,
          percentage: percentage,
          createdAt: new Date(),
          updatedAt: new Date(),
        };
        this.budgetFinancing.set(id, newFinancing);
      });
    }
  }

  async getIndicatorBudgetDistributions(indicatorCode: string): Promise<any[]> {
    const distributions: any[] = [];
    this.budgetFinancing.forEach((bf) => {
      if (bf.indicatorCode === indicatorCode) {
        const source = Array.from(this.financingSources.values()).find(fs => fs.id === bf.financingSourceId);
        distributions.push({
          year: bf.year,
          budgetType: bf.budgetType,
          financingSourceId: bf.financingSourceId,
          amount: bf.amount,
          percentage: bf.percentage,
          sourceName: source ? source.name : 'Unknown Source'
        });
      }
    });
    return distributions;
  }
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // Hash password if it's not already hashed
    let hashedPassword = insertUser.password;
    if (!insertUser.password.startsWith('$2b$')) {
      hashedPassword = await bcrypt.hash(insertUser.password, 10);
    }

    const [user] = await db
      .insert(users)
      .values({
        ...insertUser,
        password: hashedPassword
      })
      .returning();
    return user;
  }

  /**
   * Crea un usuario administrador por defecto si no existe
   */
  async createDefaultAdminUser(): Promise<User> {
    // Comprobar si ya existe el usuario admin
    const adminUser = await this.getUserByUsername('admin');

    if (adminUser) {
      return adminUser;
    }

    // Crear usuario admin con contraseña hasheada usando bcrypt
    const plainPassword = 'SanJeronimo2024';
    const hashedPassword = await bcrypt.hash(plainPassword, 10);

    const newAdmin: InsertUser = {
      username: 'admin',
      password: hashedPassword,
      isAdmin: true
    };

    console.log('✅ Creando usuario administrador por defecto...');
    const createdUser = await this.createUser(newAdmin);

    return createdUser;
  }

  /**
   * Reinicia la tabla de indicadores, eliminando todos los datos
   */
  async resetIndicatorsTable(): Promise<void> {
    // FUNCIÓN PERMANENTEMENTE DESHABILITADA - No se permite eliminar datos en producción
    console.log('🚫 OPERACIÓN BLOQUEADA: resetIndicatorsTable está permanentemente deshabilitada');
    console.log('🚫 PROTECCIÓN DE DATOS: Los datos existentes se mantienen para garantizar la persistencia');
    console.log('🚫 SOLUCIÓN: Use la función CSV import del panel de administración para actualizar datos');

    // Registrar intento de limpieza en el log de persistencia si la tabla existe
    try {
      await pool.query(`
        INSERT INTO data_persistence_log (action, table_name, record_count, details)
        VALUES ('RESET_BLOCKED', 'indicators', 0, 'Reset operation permanently blocked for data protection - use admin panel CSV import instead')
      `);
    } catch (error: any) {
      // Ignorar error si la tabla no existe
      if (error.code !== '42P01') {
        console.error('Error logging reset attempt:', error);
      }
    }

    throw new Error('Reset operation is permanently disabled to protect data integrity. Use admin panel CSV import instead.');
  }

  /**
   * Función para verificar y asegurar la persistencia de datos
   */
  async verifyDataPersistence(): Promise<{
    indicators: number;
    updates: number;
    logs: number;
    status: string;
  }> {
    try {
      // Contar registros en cada tabla
      const indicatorCount = await db.select({ count: sql<number>`count(*)` }).from(indicators);
      const updateCount = await db.select({ count: sql<number>`count(*)` }).from(updateHistory);
      
      // Verificar si existe la tabla de logs antes de consultarla
      let logsCount = 0;
      try {
        const logCount = await pool.query('SELECT COUNT(*) FROM data_persistence_log');
        logsCount = parseInt(logCount.rows[0].count);
      } catch (logError: any) {
        // Si la tabla no existe, simplemente usar 0
        if (logError.code !== '42P01') { // 42P01 = relation does not exist
          throw logError;
        }
      }

      const result = {
        indicators: indicatorCount[0].count,
        updates: updateCount[0].count,
        logs: logsCount,
        status: 'PROTECTED'
      };

      // Registrar verificación exitosa solo si la tabla existe
      try {
        await pool.query(`
          INSERT INTO data_persistence_log (action, table_name, record_count, details)
          VALUES ('PERSISTENCE_CHECK', 'system', $1, 'Data persistence verification completed successfully')
        `, [result.indicators]);
      } catch (logError: any) {
        // Ignorar error si la tabla no existe
        if (logError.code !== '42P01') {
          throw logError;
        }
      }

      return result;
    } catch (error) {
      console.error('Error verificando persistencia de datos:', error);
      throw error;
    }
  }

  /**
   * Optimiza la base de datos eliminando datos obsoletos y mejorando el rendimiento
   */
  async optimizeDatabase(): Promise<void> {
    try {
      console.log('Iniciando optimización de la base de datos...');

      // Limpiar datos obsoletos
      await this.cleanupObsoleteData();

      // Crear índices si no existen
      await pool.query(`
        CREATE INDEX IF NOT EXISTS idx_indicators_strategic_line ON indicators(strategic_line);
        CREATE INDEX IF NOT EXISTS idx_indicators_program ON indicators(program);
        CREATE INDEX IF NOT EXISTS idx_indicators_responsible ON indicators(responsible);
        CREATE INDEX IF NOT EXISTS idx_indicators_progress_2025 ON indicators(progress_2025) WHERE progress_2025 IS NOT NULL;
        CREATE INDEX IF NOT EXISTS idx_indicators_target_2025 ON indicators(target_2025) WHERE target_2025 IS NOT NULL;
        CREATE INDEX IF NOT EXISTS idx_update_history_indicator_code ON update_history(indicator_code);
        CREATE INDEX IF NOT EXISTS idx_update_history_created_at ON update_history(created_at DESC);
      `);

      console.log('Optimización de base de datos completada.');
    } catch (error) {
      console.error('Error al optimizar la base de datos:', error);
      throw error;
    }
  }

  /**
   * Limpia datos obsoletos y campos innecesarios
   */
  async cleanupObsoleteData(): Promise<void> {
    try {
      console.log('Limpiando datos obsoletos...');

      // Limpiar registros huérfanos del historial
      await pool.query(`
        DELETE FROM update_history
        WHERE indicator_code NOT IN (SELECT code FROM indicators);
      `);

      // Limpiar campos de años futuros que no se están utilizando
      await pool.query(`
        UPDATE indicators
        SET progress_2026 = NULL,
            target_2026 = NULL,
            initial_budget_2026 = NULL,
            final_budget_2026 = NULL,
            progress_2027 = NULL,
            target_2027 = NULL,
            initial_budget_2027 = NULL,
            final_budget_2027 = NULL
        WHERE (progress_2026 IS NULL OR progress_2026 = 0)
          AND (progress_2027 IS NULL OR progress_2027 = 0);
      `);

      // Limpiar campos de presupuesto vacíos
      await pool.query(`
        UPDATE indicators
        SET initial_budget_2024 = NULL,
            final_budget_2024 = NULL,
            initial_budget_2025 = NULL,
            final_budget_2025 = NULL,
            total_initial_budget = NULL,
            total_final_budget = NULL
        WHERE (initial_budget_2024 IS NULL OR initial_budget_2024 = 0)
          AND (final_budget_2024 IS NULL OR final_budget_2024 = 0)
          AND (initial_budget_2025 IS NULL OR initial_budget_2025 = 0)
          AND (final_budget_2025 IS NULL OR final_budget_2025 = 0);
      `);

      // Limpiar historial de actualizaciones muy antiguo (más de 6 meses)
      await pool.query(`
        DELETE FROM update_history
        WHERE created_at < NOW() - INTERVAL '6 months';
      `);

      console.log('Limpieza de datos obsoletos completada.');
    } catch (error) {
      console.error('Error al limpiar datos obsoletos:', error);
      throw error;
    }
  }

  async getAllIndicators(): Promise<Indicator[]> {
    return await db.select().from(indicators);
  }

  async getIndicatorByCode(code: string): Promise<Indicator | undefined> {
    const [indicator] = await db.select().from(indicators).where(eq(indicators.code, code));
    return indicator || undefined;
  }

  async createIndicator(indicator: InsertIndicator): Promise<Indicator> {
    const [newIndicator] = await db
      .insert(indicators)
      .values(indicator)
      .returning();
    return newIndicator;
  }

  async updateIndicatorProgress(update: UpdateIndicatorProgress, username: string): Promise<Indicator> {
    console.log(`Actualizando indicador: ${update.code} para el año ${update.year} con progreso: ${update.progress}`);

    // Buscar indicador
    const indicatorToUpdate = await this.getIndicatorByCode(update.code);
    if (!indicatorToUpdate) {
      throw new Error(`Indicador con código ${update.code} no encontrado`);
    }

    // Guardar el valor previo para el historial
    let previousValue = 0;

    // Mapeo directo entre año y columnas de la base de datos
    const columnMappings: Record<string, Record<string, string>> = {
      "2024": {
        progress: "progress_2024",
        initialBudget: "initial_budget_2024",
        finalBudget: "final_budget_2024"
      },
      "2025": {
        progress: "progress_2025",
        initialBudget: "initial_budget_2025",
        finalBudget: "final_budget_2025"
      },
      "2026": {
        progress: "progress_2026",
        initialBudget: "initial_budget_2026",
        finalBudget: "final_budget_2026"
      },
      "2027": {
        progress: "progress_2027",
        initialBudget: "initial_budget_2027",
        finalBudget: "final_budget_2027"
      },
      "cuatrienio": {
        progress: "total_progress",
        initialBudget: "total_initial_budget",
        finalBudget: "total_final_budget"
      }
    };

    // Obtener el mapeo de columnas para el año específico
    const yearColumns = columnMappings[update.year];
    if (!yearColumns) {
      throw new Error(`Año no válido para la actualización: ${update.year}`);
    }

    // Obtener valor previo del progreso
    const progressField = `progress${update.year}` as keyof typeof indicatorToUpdate;
    previousValue = (indicatorToUpdate[progressField] as number) || 0;

    try {
      // Construir consulta SQL para una actualización más confiable
      const setValues: string[] = [];
      const params: any[] = [update.code]; // El código es el primer parámetro
      let paramCounter = 2; // Comienza en 2 porque $1 ya es el código

      // Siempre actualizamos el progreso
      setValues.push(`${yearColumns.progress} = $${paramCounter++}`);
      params.push(update.progress);

      // Actualizar presupuesto inicial si se proporciona
      if (update.initialBudget !== undefined) {
        setValues.push(`${yearColumns.initialBudget} = $${paramCounter++}`);
        params.push(update.initialBudget);
      }

      // Actualizar presupuesto final si se proporciona
      if (update.finalBudget !== undefined) {
        setValues.push(`${yearColumns.finalBudget} = $${paramCounter++}`);
        params.push(update.finalBudget);
      }

      // Actualizar la fecha de modificación
      setValues.push(`updated_at = $${paramCounter++}`);
      params.push(new Date());

      // Calcular y actualizar el progreso total
      if (update.year !== 'cuatrienio') {
        let totalProgress = 0;

        // Actualizar el valor para el año actual
        const updatedValues = { ...indicatorToUpdate };
        if (update.year === '2024') updatedValues.progress2024 = update.progress;
        if (update.year === '2025') updatedValues.progress2025 = update.progress;
        if (update.year === '2026') updatedValues.progress2026 = update.progress;
        if (update.year === '2027') updatedValues.progress2027 = update.progress;

        // Calcular el nuevo total
        totalProgress =
          (updatedValues.progress2024 || 0) +
          (updatedValues.progress2025 || 0) +
          (updatedValues.progress2026 || 0) +
          (updatedValues.progress2027 || 0);

        setValues.push(`total_progress = $${paramCounter++}`);
        params.push(totalProgress);
      }

      // Ejecutar la consulta SQL
      const sql = `
        UPDATE indicators
        SET ${setValues.join(', ')}
        WHERE code = $1
        RETURNING *
      `;

      console.log(`SQL para actualización: ${sql}`);
      console.log("Parámetros:", params);

      const result = await pool.query(sql, params);

      if (!result.rows || result.rows.length === 0) {
        throw new Error(`No se pudo actualizar el indicador con código ${update.code}`);
      }

      // Crear entrada en el historial
      await this.createUpdateHistoryEntry(update, username, previousValue);

      // Obtener el indicador actualizado con el formato correcto
      const updatedIndicator = await this.getIndicatorByCode(update.code);
      if (!updatedIndicator) {
        throw new Error(`No se pudo recuperar el indicador actualizado ${update.code}`);
      }

      console.log(`Indicador ${update.code} actualizado correctamente`);
      return updatedIndicator;
    } catch (error) {
      console.error(`Error al actualizar el indicador ${update.code}:`, error);
      throw error;
    }
  }

  // Método auxiliar para crear entradas en el historial
  private async createUpdateHistoryEntry(update: UpdateIndicatorProgress, username: string, previousValue: number): Promise<void> {
    // Crear registro de historial
    const historyEntry: InsertUpdateHistory = {
      indicatorCode: update.code,
      username: username,
      year: update.year,
      previousValue: previousValue,
      newValue: update.progress,
      observations: update.observations || ""
    };

    // Añadir información de presupuesto a las observaciones si es necesario
    if (update.initialBudget !== undefined || update.finalBudget !== undefined) {
      historyEntry.observations = (historyEntry.observations || '') +
        (update.initialBudget !== undefined ? ` Presupuesto inicial: ${update.initialBudget}.` : '') +
        (update.finalBudget !== undefined ? ` Presupuesto definitivo: ${update.finalBudget}.` : '');
    }

    try {
      await this.createUpdateHistory(historyEntry);
    } catch (error) {
      console.error("Error al crear registro de historial:", error);
      // No relanzo el error para no interrumpir la actualización del indicador
    }
  }

  async bulkCreateIndicators(indicators: InsertIndicator[], username: string = 'sistema_importacion'): Promise<Indicator[]> {
    const results: Indicator[] = [];

    try {
      console.log(`🔄 INICIANDO IMPORTACIÓN MASIVA DE ${indicators.length} INDICADORES`);
      console.log(`📊 PRESERVANDO HISTORIAL DE MODIFICACIONES EXISTENTE`);

      for (const indicatorData of indicators) {
        // Check if indicator already exists
        const existing = await this.getIndicatorByCode(indicatorData.code);

        if (existing) {
          // Update existing indicator preserving history
          // This assumes an updateIndicator method exists or this logic is integrated
          // For now, we'll call a placeholder or adapt existing logic if possible
          // NOTE: The original code did not have a specific `updateIndicator` method for bulk,
          // so we'll simulate an update by calling createIndicator again which is incorrect.
          // A proper update logic should be implemented here.
          // For the purpose of this correction, let's assume `updateIndicator` would handle it.

          // Placeholder for update logic:
          // const updated = await this.updateIndicator(existing.id, indicatorData);
          // For now, we'll just log that an update would occur and re-insert (incorrect but follows original structure's implication)
          // Correct approach would be to call a dedicated `updateIndicator` method here.

          // Let's create a simplified update simulation that mimics the intent
          const updatedIndicatorData = { ...existing, ...indicatorData };
          // Recalculate totalProgress if needed based on individual year progress or direct total
          updatedIndicatorData.totalProgress = indicatorData.totalProgress || (
            (indicatorData.progress2024 || 0) +
            (indicatorData.progress2025 || 0) +
            (indicatorData.progress2026 || 0) +
            (indicatorData.progress2027 || 0)
          );
          updatedIndicatorData.updatedAt = new Date();

          // Update in DB using proper SQL query
          const updateSql = `
            UPDATE indicators 
            SET 
              responsible = $1,
              strategic_line = $2,
              program = $3,
              sector = $4,
              bpim = $5,
              ods = $6,
              name = $7,
              description = $8,
              unit = $9,
              total_target = $10,
              target_2024 = $11,
              progress_2024 = $12,
              target_2025 = $13,
              progress_2025 = $14,
              target_2026 = $15,
              progress_2026 = $16,
              target_2027 = $17,
              progress_2027 = $18,
              total_progress = $19,
              initial_budget_2024 = $20,
              final_budget_2024 = $21,
              initial_budget_2025 = $22,
              final_budget_2025 = $23,
              initial_budget_2026 = $24,
              final_budget_2026 = $25,
              initial_budget_2027 = $26,
              final_budget_2027 = $27,
              total_initial_budget = $28,
              total_final_budget = $29,
              updated_at = $30
            WHERE id = $31
            RETURNING *
          `;
          
          await pool.query(updateSql, [
            indicatorData.responsible,
            indicatorData.strategicLine,
            indicatorData.program,
            indicatorData.sector,
            indicatorData.bpim,
            indicatorData.ods,
            indicatorData.name,
            indicatorData.description,
            indicatorData.unit,
            indicatorData.totalTarget,
            indicatorData.target2024,
            indicatorData.progress2024,
            indicatorData.target2025,
            indicatorData.progress2025,
            indicatorData.target2026,
            indicatorData.progress2026,
            indicatorData.target2027,
            indicatorData.progress2027,
            updatedIndicatorData.totalProgress,
            indicatorData.initialBudget2024,
            indicatorData.finalBudget2024,
            indicatorData.initialBudget2025,
            indicatorData.finalBudget2025,
            indicatorData.initialBudget2026,
            indicatorData.finalBudget2026,
            indicatorData.initialBudget2027,
            indicatorData.finalBudget2027,
            indicatorData.totalInitialBudget,
            indicatorData.totalFinalBudget,
            new Date(),
            existing.id
          ]);

          // Fetch the updated indicator to return
          const updated = await this.getIndicatorByCode(indicatorData.code);
          if (updated) {
             results.push(updated);
             console.log(`   ✓ Actualizado: ${indicatorData.code} (historial preservado)`);

            // Create update history entry for bulk import update
            await this.createUpdateHistory({
              indicatorCode: indicatorData.code,
              username: username, // Use the provided username
              year: 'bulk_update',
              previousValue: existing.totalProgress || 0,
              newValue: updated.totalProgress || 0,
              observations: `Actualización masiva desde CSV - BPIM: ${indicatorData.bpim || 'N/A'}, Sector: ${indicatorData.sector || 'N/A'}, ODS: ${indicatorData.ods || 'N/A'}`
            });
          } else {
            console.error(`Error: Could not retrieve updated indicator ${indicatorData.code} after update.`);
          }

        } else {
          // Create new indicator
          const created = await this.createIndicator(indicatorData);
          results.push(created);
          console.log(`   ✓ Creado: ${indicatorData.code}`);

          // Create initial history entry for new indicator
          await this.createUpdateHistory({
            indicatorCode: indicatorData.code,
            username: username, // Use the provided username
            year: 'initial_creation',
            previousValue: 0,
            newValue: indicatorData.totalProgress || 0,
            observations: `Creación inicial desde CSV - BPIM: ${indicatorData.bpim || 'N/A'}, Sector: ${indicatorData.sector || 'N/A'}, ODS: ${indicatorData.ods || 'N/A'}`
          });
        }
      }

      console.log(`✅ IMPORTACIÓN MASIVA COMPLETADA: ${results.length} indicadores procesados CON HISTORIAL PRESERVADO`);
      return results;

    } catch (error) {
      console.error('Error en importación masiva:', error);
      throw error;
    }
  }

  async getIndicatorsByFilters(filters: {
    strategicLine?: string;
    program?: string;
    responsible?: string;
    bpim?: string;
    sector?: string;
    ods?: string;
    year?: string;
    status?: string[];
  }): Promise<Indicator[]> {
    let query = db.select().from(indicators);

    if (filters.strategicLine) {
      query = query.where(eq(indicators.strategicLine, filters.strategicLine));
    }

    if (filters.program) {
      query = query.where(eq(indicators.program, filters.program));
    }

    if (filters.responsible) {
      query = query.where(eq(indicators.responsible, filters.responsible));
    }

    if (filters.bpim) {
      query = query.where(eq(indicators.bpim, filters.bpim));
    }

    if (filters.sector) {
      query = query.where(eq(indicators.sector, filters.sector));
    }

    if (filters.ods) {
      const odsValue = parseInt(filters.ods);
      query = query.where(eq(indicators.ods, odsValue));
    }

    // Status needs to be calculated after retrieving the indicators
    const allIndicators = await query;

    if (filters.status && filters.status.length > 0) {
      const year = filters.year || "cuatrienio";
      return allIndicators.filter(indicator => {
        const status = getStatusForIndicator(indicator, year);
        return filters.status!.includes(status);
      });
    }

    return allIndicators;
  }

  async getUpdateHistory(limit = 100): Promise<UpdateHistory[]> {
    return await db
      .select()
      .from(updateHistory)
      .orderBy(desc(updateHistory.createdAt))
      .limit(limit);
  }

  async createUpdateHistory(history: InsertUpdateHistory): Promise<UpdateHistory> {
    const [newHistory] = await db
      .insert(updateHistory)
      .values(history)
      .returning();

    return newHistory;
  }

  async getUpdateHistoryByIndicator(code: string): Promise<UpdateHistory[]> {
    return await db
      .select()
      .from(updateHistory)
      .where(eq(updateHistory.indicatorCode, code))
      .orderBy(desc(updateHistory.createdAt));
  }

  // Financing sources methods
  async getAllFinancingSources(): Promise<FinancingSource[]> {
    return await db
      .select()
      .from(financingSources)
      .where(eq(financingSources.active, true));
  }

  async getFinancingSourceById(id: number): Promise<FinancingSource | undefined> {
    const [source] = await db
      .select()
      .from(financingSources)
      .where(eq(financingSources.id, id));
    return source || undefined;
  }

  async createFinancingSource(source: InsertFinancingSource): Promise<FinancingSource> {
    const [newSource] = await db
      .insert(financingSources)
      .values(source)
      .returning();
    return newSource;
  }

  async updateFinancingSource(id: number, source: Partial<InsertFinancingSource>): Promise<FinancingSource> {
    const [updatedSource] = await db
      .update(financingSources)
      .set({ ...source, updatedAt: new Date() })
      .where(eq(financingSources.id, id))
      .returning();

    if (!updatedSource) {
      throw new Error(`Financing source with ID ${id} not found`);
    }

    return updatedSource;
  }

  // Budget financing methods
  async getBudgetFinancingByIndicator(indicatorCode: string): Promise<BudgetFinancing[]> {
    return await db
      .select()
      .from(budgetFinancing)
      .where(eq(budgetFinancing.indicatorCode, indicatorCode));
  }

  async getBudgetFinancingByYear(year: string): Promise<BudgetFinancing[]> {
    return await db
      .select()
      .from(budgetFinancing)
      .where(eq(budgetFinancing.year, year));
  }

  async getBudgetFinancingByIndicatorAndYear(indicatorCode: string, year: string): Promise<BudgetFinancing[]> {
    return await db
      .select()
      .from(budgetFinancing)
      .where(
        and(
          eq(budgetFinancing.indicatorCode, indicatorCode),
          eq(budgetFinancing.year, year)
        )
      );
  }

  async createBudgetFinancing(financing: InsertBudgetFinancing): Promise<BudgetFinancing> {
    const [newFinancing] = await db
      .insert(budgetFinancing)
      .values(financing)
      .returning();
    return newFinancing;
  }

  async updateBudgetFinancing(id: number, financing: Partial<InsertBudgetFinancing>): Promise<BudgetFinancing> {
    const [updatedFinancing] = await db
      .update(budgetFinancing)
      .set({ ...financing, updatedAt: new Date() })
      .where(eq(budgetFinancing.id, id))
      .returning();

    if (!updatedFinancing) {
      throw new Error(`Budget financing with ID ${id} not found`);
    }

    return updatedFinancing;
  }

  async deleteBudgetFinancing(id: number): Promise<void> {
    await db
      .delete(budgetFinancing)
      .where(eq(budgetFinancing.id, id));
  }

  // Added methods for budget distribution
  async getBudgetFinancing(indicatorCode: string, year: string): Promise<BudgetFinancing[]> {
    return await db
      .select()
      .from(budgetFinancing)
      .where(
        and(
          eq(budgetFinancing.indicatorCode, indicatorCode),
          eq(budgetFinancing.year, year)
        )
      );
  }

  async saveBudgetDistribution(distribution: BudgetDistribution): Promise<void> {
    try {
      // Eliminar distribuciones existentes
      await db
        .delete(budgetFinancing)
        .where(
          and(
            eq(budgetFinancing.indicatorCode, distribution.indicatorCode),
            eq(budgetFinancing.year, distribution.year),
            eq(budgetFinancing.budgetType, distribution.budgetType)
          )
        );

      // Insertar nuevas distribuciones
      if (distribution.distributions.length > 0) {
        const insertData = distribution.distributions.map(dist => ({
          indicatorCode: distribution.indicatorCode,
          year: distribution.year,
          budgetType: distribution.budgetType,
          financingSourceId: dist.financingSourceId,
          amount: dist.amount,
          percentage: dist.percentage || (dist.amount / distribution.totalAmount) * 100
        }));

        await db.insert(budgetFinancing).values(insertData);
      }

      // Actualizar el presupuesto total del indicador si es necesario
      if (distribution.totalAmount > 0) {
        const updateData: any = { updatedAt: new Date() };

        if (distribution.year === 'cuatrienio') {
          if (distribution.budgetType === 'initial') {
            updateData.totalInitialBudget = distribution.totalAmount;
          } else {
            updateData.totalFinalBudget = distribution.totalAmount;
          }
        } else {
          const budgetField = `${distribution.budgetType}Budget${distribution.year}`;
          updateData[budgetField] = distribution.totalAmount;
        }

        await db
          .update(indicators)
          .set(updateData)
          .where(eq(indicators.code, distribution.indicatorCode));
      }

      console.log(`✅ Distribución de presupuesto guardada para ${distribution.indicatorCode} - ${distribution.year} - ${distribution.budgetType}`);
    } catch (error) {
      console.error('Error saving budget distribution:', error);
      throw error;
    }
  }

  async getIndicatorBudgetDistributions(indicatorCode: string): Promise<any[]> {
    const result = await db
      .select({
        year: budgetFinancing.year,
        budgetType: budgetFinancing.budgetType,
        financingSourceId: budgetFinancing.financingSourceId,
        amount: budgetFinancing.amount,
        percentage: budgetFinancing.percentage,
        sourceName: financingSources.name
      })
      .from(budgetFinancing)
      .leftJoin(financingSources, eq(budgetFinancing.financingSourceId, financingSources.id))
      .where(eq(budgetFinancing.indicatorCode, indicatorCode))
      .orderBy(budgetFinancing.year, budgetFinancing.budgetType);

    return result;
  }

  // Chat management methods
  async getUserConversations(userId: number): Promise<any[]> {
    const conversations = await db
      .select()
      .from(chatConversations)
      .where(eq(chatConversations.userId, userId))
      .orderBy(desc(chatConversations.updatedAt));

    return conversations;
  }

  async getConversationMessages(conversationId: number): Promise<any[]> {
    const messages = await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.conversationId, conversationId))
      .orderBy(chatMessages.createdAt);

    return messages;
  }

  async createConversation(userId: number, title: string): Promise<any> {
    const [conversation] = await db
      .insert(chatConversations)
      .values({ userId, title })
      .returning();

    return conversation;
  }

  async createMessage(conversationId: number, role: string, content: string): Promise<any> {
    const [message] = await db
      .insert(chatMessages)
      .values({ conversationId, role, content })
      .returning();

    // Update conversation's updatedAt timestamp
    await db
      .update(chatConversations)
      .set({ updatedAt: new Date() })
      .where(eq(chatConversations.id, conversationId));

    return message;
  }

  async deleteConversation(conversationId: number): Promise<void> {
    // Delete all messages in the conversation
    await db
      .delete(chatMessages)
      .where(eq(chatMessages.conversationId, conversationId));

    // Delete the conversation
    await db
      .delete(chatConversations)
      .where(eq(chatConversations.id, conversationId));
  }
}

export const storage = new DatabaseStorage();