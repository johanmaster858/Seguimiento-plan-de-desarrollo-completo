import { pgTable, text, serial, integer, boolean, timestamp, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema for authentication
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  isAdmin: boolean("is_admin").default(false),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  isAdmin: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Indicator schema
export const indicators = pgTable("indicators", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  bpim: text("bpim"), // BPIM como texto para valores largos (soporta números grandes)
  responsible: text("responsible").notNull(),
  strategicLine: text("strategic_line").notNull(),
  program: text("program").notNull(),
  sector: text("sector"), // Nueva columna Sector (string)
  ods: integer("ods"), // Nueva columna ODS (dato numérico)
  name: text("name").notNull(),
  description: text("description").notNull(),
  unit: text("unit").notNull(),
  totalTarget: real("total_target").notNull(),
  
  // Yearly goals and progress
  target2024: real("target_2024").default(0),
  progress2024: real("progress_2024").default(0),
  initialBudget2024: real("initial_budget_2024").default(0),
  finalBudget2024: real("final_budget_2024").default(0),
  
  target2025: real("target_2025").default(0),
  progress2025: real("progress_2025").default(0),
  initialBudget2025: real("initial_budget_2025").default(0),
  finalBudget2025: real("final_budget_2025").default(0),
  
  target2026: real("target_2026").default(0),
  progress2026: real("progress_2026").default(0),
  initialBudget2026: real("initial_budget_2026").default(0),
  finalBudget2026: real("final_budget_2026").default(0),
  
  target2027: real("target_2027").default(0),
  progress2027: real("progress_2027").default(0),
  initialBudget2027: real("initial_budget_2027").default(0),
  finalBudget2027: real("final_budget_2027").default(0),
  
  totalProgress: real("total_progress").default(0),
  totalInitialBudget: real("total_initial_budget").default(0),
  totalFinalBudget: real("total_final_budget").default(0),
  
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertIndicatorSchema = createInsertSchema(indicators).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  // Make description and unit optional for better CSV compatibility
  description: z.string().optional().default(''),
  unit: z.string().optional().default(''),
  // New fields for BPIM, Sector and ODS
  bpim: z.string().optional(),
  sector: z.string().optional().default(''),
  ods: z.number().optional(),
  // Ensure numeric fields have proper defaults
  totalTarget: z.number().default(0),
  target2024: z.number().optional().default(0),
  progress2024: z.number().optional().default(0),
  target2025: z.number().optional().default(0),
  progress2025: z.number().optional().default(0),
  target2026: z.number().optional().default(0),
  progress2026: z.number().optional().default(0),
  target2027: z.number().optional().default(0),
  progress2027: z.number().optional().default(0),
  totalProgress: z.number().optional().default(0),
  initialBudget2024: z.number().optional().default(0),
  finalBudget2024: z.number().optional().default(0),
  initialBudget2025: z.number().optional().default(0),
  finalBudget2025: z.number().optional().default(0),
  initialBudget2026: z.number().optional().default(0),
  finalBudget2026: z.number().optional().default(0),
  initialBudget2027: z.number().optional().default(0),
  finalBudget2027: z.number().optional().default(0),
  totalInitialBudget: z.number().optional().default(0),
  totalFinalBudget: z.number().optional().default(0),
});

export type InsertIndicator = z.infer<typeof insertIndicatorSchema>;
export type Indicator = typeof indicators.$inferSelect;

// Update schemas for partial updates
export const updateIndicatorProgressSchema = z.object({
  code: z.string(),
  year: z.enum(["2024", "2025", "2026", "2027"]),
  progress: z.number(),
  initialBudget: z.number().optional(),
  finalBudget: z.number().optional(),
  observations: z.string().optional(),
});

export type UpdateIndicatorProgress = z.infer<typeof updateIndicatorProgressSchema>;

// Schema for update history
export const updateHistory = pgTable("update_history", {
  id: serial("id").primaryKey(),
  indicatorCode: text("indicator_code").notNull(),
  year: text("year"), // Made nullable to allow bulk operations
  username: text("username").notNull(),
  previousValue: real("previous_value"),
  newValue: real("new_value").notNull(),
  observations: text("observations"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUpdateHistorySchema = createInsertSchema(updateHistory).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertUpdateHistory = z.infer<typeof insertUpdateHistorySchema>;
export type UpdateHistory = typeof updateHistory.$inferSelect;

// Financing sources schema
export const financingSources = pgTable("financing_sources", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  active: boolean("active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertFinancingSourceSchema = createInsertSchema(financingSources).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertFinancingSource = z.infer<typeof insertFinancingSourceSchema>;
export type FinancingSource = typeof financingSources.$inferSelect;

// Budget financing distribution schema - vinculado a presupuestos anuales
export const budgetFinancing = pgTable("budget_financing", {
  id: serial("id").primaryKey(),
  indicatorCode: text("indicator_code").notNull(),
  year: text("year").notNull(), // "2024", "2025", "2026", "2027"
  financingSourceId: integer("financing_source_id").notNull(),
  amount: real("amount").notNull(),
  percentage: real("percentage"), // Porcentaje del presupuesto total
  budgetType: text("budget_type").notNull(), // "initial" o "final"
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertBudgetFinancingSchema = createInsertSchema(budgetFinancing).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertBudgetFinancing = z.infer<typeof insertBudgetFinancingSchema>;
export type BudgetFinancing = typeof budgetFinancing.$inferSelect;

// Schema para manejo de presupuestos distribuidos por fuente
export const budgetDistributionSchema = z.object({
  indicatorCode: z.string(),
  year: z.enum(["2024", "2025", "2026", "2027"]),
  budgetType: z.enum(["initial", "final"]),
  distributions: z.array(z.object({
    financingSourceId: z.number(),
    amount: z.number(),
    percentage: z.number().optional()
  })),
  totalAmount: z.number()
});

export type BudgetDistribution = z.infer<typeof budgetDistributionSchema>;

// Chat conversations schema
export const chatConversations = pgTable("chat_conversations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertChatConversationSchema = createInsertSchema(chatConversations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertChatConversation = z.infer<typeof insertChatConversationSchema>;
export type ChatConversation = typeof chatConversations.$inferSelect;

// Chat messages schema
export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").notNull(),
  role: text("role").notNull(), // "user" or "assistant"
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  createdAt: true,
});

export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;

// Schema for chat request
export const chatRequestSchema = z.object({
  message: z.string(),
  conversationId: z.number().optional(),
});

export type ChatRequest = z.infer<typeof chatRequestSchema>;
